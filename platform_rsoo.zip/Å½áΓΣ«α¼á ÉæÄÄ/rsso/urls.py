"""URL Configuration
"""
from contents.ajax_conflicts import AjaxConflicts
from contents.ajax_view import AjaxMethods
from contents.csv import orders_to_csv, orders_to_csv2, orders_to_csv3, platforms
from contents.upload import multiuploader
from django.conf.urls import patterns, include, url
from django.contrib import admin
from rsso import settings
from django.conf.urls.static import static
from contents.views import FrontView, Login, ManageOrganizations, ManagePlatform, \
    ManageConflicts, ManageScheme, ManageGarbage, ManageObject, ManageContracts, RegistrationView, RegistrationMicroView, \
    XMLData, SubDocument, LocustView, ManageGarbageContracts, ManageGarbageContractsBuildings, ManageBuldingsUK, \
    ManageFirmWastes, Statistic


urlpatterns = patterns('',
                       url(r'^admin/', include(admin.site.urls)),
                       url(r'^adminactions/', include('adminactions.urls')),
                       url(r'^ajax/$', AjaxMethods.as_view(), name='ajax'),
                       url(r'^ajax/conflicts/$', AjaxConflicts.as_view(), name='api_conflicts'),
                       url(r'^login/$', Login.as_view(), name='login'),
                       url(r'^registration/$', RegistrationView.as_view(), name='registration'),
                       url(r'^registration/micro/$', RegistrationMicroView.as_view(), name='micro_registration'),
                       url(r'^logout/$', 'django.contrib.auth.views.logout', name='logout', kwargs={'next_page': '/'}),
                       url(r'^manager/organizations/$', ManageOrganizations.as_view(), name='manage_organizations'),
                       url(r'^manager/transport/$', ManageObject.as_view(template_name='universal/bases/cars.html', menu='item5'), name='manage_transport'),
                       url(r'^manager/staff/$', ManageObject.as_view(template_name='universal/bases/staff.html', menu='item6'), name='manage_staff'),
                       url(r'^manager/platform/$', ManagePlatform.as_view(), name='manage_platform'),
                       url(r'^manager/bases/$', ManageObject.as_view(template_name='universal/bases/bases.html', menu='item8'), name='manage_bases'),
                       url(r'^manager/points/$', ManageObject.as_view(template_name='universal/bases/points.html', menu='item9'), name='manage_points'),
                       url(r'^manager/conflicts/$', ManageConflicts.as_view(), name='manage_conflicts'),
                       url(r'^stat/$', Statistic.as_view(), name='stat'),
                       url(r'^manager/scheme/$', ManageScheme.as_view(), name='manage_scheme'),
                       url(r'^manager/garbage/$', ManageGarbage.as_view(), name='manage_garbage'),
                       url(r'^manager/treatment/$', ManageObject.as_view(), name='manage_treatment'),
                       url(r'^manager/transporters/$', ManageObject.as_view(template_name='universal/bases/transporters.html', menu='item14'), name='manage_transporters'),
                       url(r'^manager/settlement/$', ManageObject.as_view(template_name='universal/bases/settlements.html', menu='item15'), name='manage_settlement'),
                       url(r'^manager/waste/$', ManageObject.as_view(template_name='universal/bases/waste.html', menu='item16'), name='manage_waste'),
                       url(r'^manager/buildings/$', ManageObject.as_view(template_name='universal/bases/buildings.html', menu='item17'), name='manage_buildings'),
                       url(r'^manager/buildings/uk/$', ManageBuldingsUK.as_view(template_name='universal/bases/buildings_uk.html', menu='item22'), name='manage_buildings_uk'),
                       url(r'^manager/houses/$', ManageObject.as_view(template_name='universal/bases/houses.html', menu='item24'), name='manage_houses'),
                       url(r'^manager/contracts/$', ManageContracts.as_view(template_name='universal/bases/contract.html', menu='item18'), name='manage_contracts'),
                       url(r'^manager/garbage-contracts/$', ManageGarbageContracts.as_view(template_name='universal/bases/g-contract.html', menu='item21'), name='manage_garbage_contracts'),
                       url(r'^manager/garbage-contracts/uk/$', ManageGarbageContractsBuildings.as_view(template_name='universal/bases/g-contract-uk.html', menu='item23'), name='manage_garbage_contracts_uk'),
                       url(r'^manager/wastes/$', ManageObject.as_view(template_name='universal/bases/wastes.html', menu='item19'), name='manage_wastes'),
                       url(r'^manager/microbuildings/$', ManageObject.as_view(template_name='universal/bases/micro-buildings.html', menu='item20'), name='manage_microbuildings'),
                       url(r'^manager/firmwastes/$', ManageFirmWastes.as_view(template_name='universal/bases/firm-wastes.html', menu='item25'), name='manage_firmwastes'),
                       url(r'^xml/data/$', XMLData.as_view(), name='xml_data'),
                       url(r'^locust/$', LocustView.as_view(), name='locust'),
                       url(r'^docs/subscribe/$', SubDocument.as_view(), name='subscribe_data'),
                       url(r'^report/$', orders_to_csv, name='report'),
                       url(r'^upload/$', multiuploader, name='upload'),
                       url(r'^$', FrontView.as_view(), name='front'),
                       ) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    urlpatterns = patterns('',
                           url(r'^media/(?P<path>.*)$', 'django.views.static.serve',
                               {'document_root': settings.MEDIA_ROOT, 'show_indexes': True}),
                           url(r'', include('django.contrib.staticfiles.urls')),
                           ) + urlpatterns