"""
Django settings for rsso project.
"""

import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

gettext = lambda s: s
DEBUG = True
PROJECT_PATH = os.path.abspath(os.path.dirname(__file__))
THUMBNAIL_DEBUG = DEBUG


SECRET_KEY = 'fk4ejpmhxg#8e_r)uvj#nc4q3cd=w(*f$w@-94%0ro_^h5o9n6'


ALLOWED_HOSTS = []




INSTALLED_APPS = (
    'adminactions',
    'longerusernameandemail',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.admindocs',
    'django.contrib.humanize',
    'django.contrib.sitemaps',
    # 'sorl.thumbnail',
    'slugify',
    'pytils',
    'contents',
    'multiselectfield',
)

MAX_USERNAME_LENGTH = 255
MAX_EMAIL_LENGTH = 255

MIDDLEWARE_CLASSES = (
    # 'django.middleware.cache.UpdateCacheMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    # 'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    # 'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    # 'django.middleware.doc.XViewMiddleware',
    # 'django.middleware.gzip.GZipMiddleware'
    # 'rsso.actives.CheckUserMiddleware',

)

# AUTH_USER_MODEL = 'contents.UserProfiles'

ROOT_URLCONF = 'rsso.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [PROJECT_PATH + '/templates', ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.core.context_processors.i18n',
                'django.core.context_processors.csrf',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
            ],
        },
    },
]


SITE_ID = 1

WSGI_APPLICATION = 'rsso.wsgi.application'


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'rss_o',
        'USER': 'rss_o',
        'PASSWORD': '',
        'HOST': '',
        'PORT': '',
    }
}


LANGUAGE_CODE = 'ru'

TIME_ZONE = 'Europe/Moscow'

USE_I18N = True

USE_L10N = True

USE_TZ = True


STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
)

STATIC_URL = '/static/'

MEDIA_ROOT = os.path.join(PROJECT_PATH, "media/")

MEDIA_URL = '/media/'

STATIC_ROOT = os.path.join(PROJECT_PATH, "media/static/")

STATICFILES_DIRS = (
    os.path.join(PROJECT_PATH, 'static'),
)
APPEND_SLASH = True

# EMAIL_BACKEND = 'django_mandrill.mail.backends.mandrillbackend.EmailBackend'
# MANDRILL_API_KEY = 'Es3dqHcjNOkaLysPC-NdzA'

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'

EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.xxxxxxx.ru'
EMAIL_HOST_USER = 'othody'
EMAIL_HOST_PASSWORD = 'xxxxxxx'
EMAIL_PORT = 587

DEFAULT_FROM_EMAIL = 'othody@xxxxxxx.ru'
DEFAULT_TO_EMAIL = ['xxxxxxxx@gmail.com', ]


try:
    from local_settings import *
except ImportError:
    pass