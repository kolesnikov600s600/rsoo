# -*- coding: utf-8 -*-
from django import http


class CheckUserMiddleware(object):

    response_redirect_class = http.HttpResponsePermanentRedirect

    def process_request(self, request):
        if not request.user.is_active and request.get_full_path() != '/login/' and request.get_full_path() != '/admin/':
            return self.response_redirect_class('/login/')










