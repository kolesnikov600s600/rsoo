var suggest;

$(function () {

    var workArea = $('.work-area');

    workArea.on("loadData", '.edit-panel', function (e) {
        $(this).height($(window).height() - $('.top-container').height() - 24);
        $(this).find('.inner-area').height($(this).height() - 60);
        $(this).find('select').styler({
            selectPlaceholder: $(this).data('placeholder')
        });
        $(this).find('.inner-area').jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });
        $(this).find('.t-help').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
        $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
        $('input[name=phone]').mask('+7 (999) 999-99-99', {autoclear: false});

        $("#id_address").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "PARTY",
            count: 10,
            width: 400,
            onSelect: function (suggestion) {
                var director;
                if (suggestion.data.type == 'INDIVIDUAL') {
                    director = suggestion.data.name.full
                }
                else {
                    director = suggestion.data.management.name
                }
                $(this).trigger('change').trigger('input');
                $(this).parents('form').find('input[name=inn]').val(suggestion.data.inn).trigger('change').trigger('input');
                $(this).parents('form').find('input[name=bin]').val(suggestion.data.ogrn).trigger('change').trigger('input');
                $(this).parents('form').find('input[name=director]').val(director).trigger('change').trigger('input');
                $(this).parents('form').find('input[name=address]').val(suggestion.data.address.value).trigger('change').trigger('input');
                $(this).parents('form').find('input[name=kpp]').val(suggestion.data.kpp).trigger('change').trigger('input');
                $(this).parents('form').find('input[name=okved]').val(suggestion.data.okved).trigger('change').trigger('input');
            }
        });
        if ($(this).find('.create-object').size() > 0) {
            $('#id_address').focus();
            $("#id_address").suggestions('update');
        }


    });

    $('.d-height').height($(window).height() - $('.top-container').height() - 24);
    $('select').styler({
        selectPlaceholder: $(this).data('placeholder')
    });
    $('.left-panel .scroll').height($('.left-panel').height() - 108 - $('.left-panel .bottom-panel').height());


    $('.left-panel .scroll').bind(
        'jsp-scroll-y',
        function (event, scrollPositionY, isAtTop, isAtBottom) {
            if (isAtBottom && $('.list-items .loader.post').size()) {
                $('.list-items .loader.post').removeClass('post');
                getOrganizationList($('.list-items .loader').data('next'));
            }

        }
    ).jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });

    $(".list-items").on("click", ".item", function (e) {
        if (!$(e.target).is('input,label,label i')) {
            if (!$(this).is('.active')) {
                getEditForm($(this).data('id'));
                $('.list-items .item').removeClass('active');
                $(this).addClass('active');
            }
            else {
                $(this).removeClass('active');
                $('.edit-panel').remove();
                if ($(this).data('id') == 'new') $(this).remove();
            }
            $('.list-items .item[data-id=new]').remove();
        }
    });

    $(".list-items").on("change", "input[type=checkbox]", function (e) {
        editFieldOrganization($(this).parents('.item').data('id'), $(this).prop('name'), $(this).is(':checked'));
    });


    workArea.on('click', '.toggle-link', function (e) {
        e.preventDefault();
        var t = $(this).find('span').text();
        $(this).find('span').text($(this).data('text'));
        $(this).data('text', t);
        var c = $(this).find('i').attr('class');
        if (c == 'fa fa-chevron-down') {
            $(this).find('i').attr('class', 'fa fa-chevron-up');
        }
        else {
            $(this).find('i').attr('class', 'fa fa-chevron-down');
        }
        $($(this).attr('href')).toggle(0);
    });

    workArea.on('change', '.edit-object .base-form input, .edit-object .base-form select', function (e) {
        if (!$(this).is('.error')) {
            if ($(this).is('[name=phone]')) {
                removeMessageInput($(this));
                if (!testinput(/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{2}[\s.-]\d{2}$/, $(this).val())) {
                    addErrorInput($(this));
                }
                else {
                    addSuccessInput($(this));
                }
            }
            else {
                addSuccessInput($(this));
            }
        }
    });

    workArea.on('input', '.edit-object .base-form input, .edit-object .base-form select', function (e) {
        removeMessageInput($(this));
        if ($(this).is('[data-required=1]')) {
            if ($(this).val().length < 5) {
                addErrorInput($(this));
            }
        }
        if ($(this).is('[name=email]')) {
            if (!testinput(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, $(this).val())) {
                addErrorInput($(this));
            }
        }

    });


    workArea.on('change', '.create-object .base-form input, .create-object .base-form select', function (e) {
        removeMessageInput($(this));
        if ($(this).is('[data-required=1]')) {
            if ($(this).val().length < 5) {
                addErrorInput($(this));
            }

        }
        if ($(this).is('[name=email]')) {
            if (!testinput(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, $(this).val())) {
                addErrorInput($(this));
                alert(1);
            }

        }
        if ($(this).is('[name=phone]')) {
            if (!testinput(/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{2}[\s.-]\d{2}$/, $(this).val())) {
                addErrorInput($(this));
            }

        }
        if (!$(this).is('.error')) {
            addSuccessInput($(this));
        }
        var check = 1;

        $('.base-form input[data-required=1], .base-form select').each(function () {
            if (!$(this).val() || $(this).is('.error')) {
                check = 0;
            }
            else {
                if (!$(this).is('.success')) {
                    addSuccessInput($(this));
                }
            }
        });
        var f = $('#input-filling');
        if (check) f.text('Параметры заполнены');
        else f.text('Заполните параметры');


    });


    workArea.on('change', '.edit-object .base-form .readonly-input input', function (e) {
        $($(this).data('related')).text($(this).val());
    });

    workArea.on('change', '.create-object .base-form .readonly-input input', function (e) {
        $($(this).data('related')).text($(this).val());
    });

    workArea.on('input', '.change-input', function (e) {
        var id = $(this).parents('form').data('id');
        $('.item[data-id=' + id + '] .' + $(this).data('change') + ', .object[data-id=' + id + '] .' + $(this).data('change')).text($(this).val());
    });

    workArea.on('click', '.base-form .read-only .edit', function (e) {
        e.preventDefault();
        $('.readonly-input').fadeToggle(0);
        $('.readonly-data').fadeToggle(0);
    });


    getOrganizationList();


    workArea.on('change', '.request-form input[type=checkbox]', function () {
        $(this).parents('.request-form').find('select').toggleDisabled().trigger('refresh');
        $(this).parents('.request-form').find('.text input').toggleReadonly();
    });

    workArea.on('click', '#save-object', function () {
        if ($('.edit-panel').data('id') == 'new') {
            var f = $('#input-filling');
            if (f.text() == 'Параметры заполнены') {
                showLoaderBase();
                $.ajax({
                    type: "POST",
                    url: '/ajax/',
                    contentType: 'application/json; charset=utf-8',
                    data: $.toJSON($('.create-object').serializeObject()),
                    dataType: 'json',
                    success: function (data) {
                        if (data['success']) {
                            $('.list-items .item[data-id=new]').replaceWith(data['html']);
                            removeBaseLoader();
                            $('.edit-panel').remove();
                            if (data['docs']) {
                                $.fancybox(data['docs']);
                            }
                        }
                    }
                });

            }
        }
        else {
            if ($('.edit-panel .error').size() == 0) {
                showLoaderBase();
                $.ajax({
                    type: "POST",
                    url: '/ajax/',
                    contentType: 'application/json; charset=utf-8',
                    data: $.toJSON($('.edit-object').serializeObject()),
                    dataType: 'json',
                    success: function (data) {
                        if (data['success']) {
                            $('.list-items .item[data-id='+data['id']+']').replaceWith(data['html']);
                            removeBaseLoader();
                            $('.edit-panel').remove();

                        }
                    }
                });
            }
        }
    });

    workArea.on('change', '.edit-object .request-form input, .request-form select', function () {
        editFormOrganization(
            $(this).parents('form').data('id'),
            $(this).parents('.request-form').find('.checkbox input').prop('value'),
            !$(this).parents('.request-form').find('.checkbox input').is(':checked'),
            $(this).parents('.request-form').find('input[type=text]').val(),
            $(this).parents('.request-form').find('select').val()
        )

    });

    $('#id_category,#id_status').change(function () {
        clearItemList();
        getOrganizationList(1);
    });
    var interval;

    $('#id_search').on('input', function (e) {
        clearTimeout(interval);
        var dInput = this.value;
        if (dInput.length > 0) {
            clearItemList();
            interval = setTimeout(function () {
                getOrganizationList(1, dInput);
            }, 800);
            if ($('.left-panel .suggestions-suggestions:visible').size() == 0) {
                $('.drop-block').show(0).find('strong').text(dInput);
            }
        }
        else {
            clearItemList();
            getOrganizationList(1, '');
            $('.drop-block').removeClass('active').hide(0).find('strong').text('Название');
            $("#id_search").suggestions('disable');
        }

    });

    $('#id_search').on('keydown', function (e) {
        console.log(e.keyCode);
        if (e.keyCode == 40 && $('.drop-block:visible').size() > 0) {
            e.preventDefault();
            $('.drop-block:visible').addClass('active');
        }
        if (e.keyCode == 13 && $('.drop-block.active').size() > 0 && $('.left-panel .suggestions-suggestions:visible').size() == 0) {
            e.preventDefault();
            $('.drop-block').hide(0);
            $("#id_search").suggestions('enable');
            $("#id_search").suggestions('update');
        }
        if (e.keyCode == 38 && $('.drop-block:visible').size() > 0) {
            e.preventDefault();
            $('.drop-block:visible').removeClass('active');
        }
    });


    $('#id_search').blur(function () {
        setTimeout(function () {
            $('.drop-block').hide(0);
        }, 200);
    });

    $('.drop-block').click(function () {

        $(this).hide(0, function () {
                $("#id_search").suggestions('enable');
                $("#id_search").suggestions('update');
            }
        );
    });


    $("#id_search").suggestions({
        serviceUrl: "https://dadata.ru/api/v2",
        token: "355f93ce71c996490531a51e9b6d924a54399dd4",
        type: "PARTY",
        hint: 'Организация не найдена, добавьте новую или продолжите ввод',
        count: 5,
        width: 400,
        onSelect: function (suggestion) {
            var director;
            if (suggestion.data.type == 'INDIVIDUAL') {
                director = suggestion.data.name.full
            }
            else {
                director = suggestion.data.management.name
            }

            getCreateForm({
                'category': $('.left-panel #id_category').val(),
                'name': suggestion.value,
                'inn': suggestion.data.inn,
                'bin': suggestion.data.ogrn,
                'address': suggestion.data.address.value,
                'director': director
            });
            $("#id_search").suggestions('disable');
        }
    });

    $("#id_search").suggestions('disable');

    $('.left-panel .add-object').click(function (e) {
        e.preventDefault();
        getCreateForm({'name': $('#id_search').val(), 'inn': ''});
    });

    $('#send-request').click(function (e) {
        e.preventDefault();
        sendAllRequest();
    });


});

function clearItemList() {
    $('.list-items').html('<div class="loader post"><i class="fa fa-spinner fa-pulse"></i></div>');
}


function getOrganizationList(page, search) {
    if (search === undefined) {
        if ($('#id_search').val().length > 0) {
            search = $('#id_search').val();
        }
    }

    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_organization_list',
                'page': page,
                'category': $('#id_category').val(),
                'status': $('#id_status').val(),
                'search': search
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                $('.list-items .loader').remove();
                $('.list-items').append(data['html']);
                $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});

            }

        }
    });

}

function editFieldOrganization(id, status, value) {
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'edit_field_organization',
                'id': id,
                'field': status,
                'value': value
            }
        ),
        dataType: 'json'

    });
}

function getEditForm(id) {
    showLoaderBase();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_form',
                'id': id
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);

            }

        }
    });
}

function closeEdit() {
    var a = $('.list-items .item.active');
    if (a.data('id') == 'new') {
        a.remove();
    }
    a.removeClass('active');
    $('.edit-panel').remove();
}


function editFormOrganization(id, form_name, del, comment, days) {
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'edit_form_organization',
                'id': id,
                'form_name': form_name,
                'delete': del,
                'comment': comment,
                'deadline': days
            }
        ),
        dataType: 'json'

    });
}

function getCreateForm(d) {
    showLoaderBase();
    createBlankItem(d);
    d['action'] = 'get_create_form';
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);

            }

        }
    });
}

function createBlankItem(d) {
    $('.list-items .item[data-id=new]').remove();
    $('.list-items').prepend('<div class="item active" data-id="new"><div class="name"><strong class="change-name">' + (d['name'] ? d['name'] : 'Новый объект') + '</strong><br>ИНН: <span class="change-inn">' + d['inn'] + '</span></div></div>')
}

function changeEditPanel(data) {
    $('.edit-panel').remove();
    removeBaseLoader();
    $('.left-panel').after(data);
    $(".edit-panel").trigger('loadData');
}

function sendAllRequest() {
    clearItemList();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON({'action': 'send_all_requests'}),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                getOrganizationList();
                $('.edit-panel').remove();
                if (data['docs']) {
                    $.fancybox(data['docs']);
                }
            }
        }
    });
}