var suggest;

$(function () {

    var workArea = $('.work-area');

    workArea.on("loadData", '.edit-panel', function (e) {
        $(this).height($(window).height() - $('.top-container').height() - 24);
        $(this).find('.inner-area').height($(this).height() - 60);
        $(this).find('select').styler({
            selectPlaceholder: $(this).data('placeholder')
        });
        if ($('.edit-panel .adr-form').height() > $('.d-height').height()) {
            $('.adr-form').height($(window).height() - $('.top-container').height() - 24);
            $('.adr-form').jScrollPane({
                autoReinitialise: 1,
                autoReinitialiseDelay: 100
            });
        }

        $(this).find('.inner-area').jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });

        $('.name-block').click(function () {
            $(this).next().slideToggle();
            $(this).find('i').toggleClass('fa-chevron-down').toggleClass('fa-chevron-up')
        });


        $(this).find('.t-help').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
        $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});

        $("#id_address").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "ADDRESS",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change');
                var i = $(this).parents('form').data('id'),
                    t = $(this).val();
                if (typeof map != 'undefined') {
                    if (findPlace(i) !== undefined) {
                        manager.remove(findPlace(i));
                    }
                    var geo = ymaps.geocode($(this).val());
                    geo.then(
                        function (res) {
                            var c = res.geoObjects.get(0).geometry.getCoordinates();
                            managerAdd({'id': i, 'name': $(name_input).val()}, c);
                            findPlace(i).options.set('draggable', true);
                            findPlace(i).options.set('iconLayout', templates_place[1]);
                            map.panTo(c).then(function () {
                                map.setZoom(18);
                            }, function (err) {
                                alert('Произошла ошибка ' + err);
                            }, this);
                            $('#id_lat').val(c[0].toFixed(6));
                            $('#id_lon').val(c[1].toFixed(6));
                        },
                        function (err) {
                            alert('Ошибка');
                        }
                    );
                }
            }
        });

        $("#id_date_approved, #id_date_agreement, .calendar-wg").datepicker({dateFormat: 'dd.mm.yy', regional: ['ru']});

        $('#choice_code').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "/ajax/",
                    dataType: "json",
                    data: {
                        action: 'code_fkko',
                        q: request.term
                    },
                    success: function (data) {
                        response(data);
                    }
                });
            },
            select: function (event, ui) {
                $("#id_fkko").val(ui.item.id);
                $('#description-fkko').html('<div class="description-field">' + ui.item.label + '</div>');
                $('#choice_code').val(ui.item.value);
                return false;
            }
        }).autocomplete("instance")._renderItem = function (ul, item) {
            return $("<li>")
                .append("<a id='" + item.id + "'>" + item.value + '<br>' + item.label + "</a>")
                .appendTo(ul);
        };

        $("#id_org_1, #id_org_2, #id_org_3, #id_gps_firm").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "PARTY",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change').trigger('input');
                $(this).parent().find('.inn input').val(suggestion.data.inn).trigger('change').trigger('input');
                $(this).parent().find('.ogrn input').val(suggestion.data.ogrn).trigger('change').trigger('input');
            }
        });

        $('input[name=phone]').mask('+7 (999) 999-99-99');


        setAutoComplete(data_select);

        if (typeof data_related != 'undefined') {
            setRelatedFields(data_related);
        }

        $('.hider-checkbox').change(function(){
            if ($(this).is(':checked')) {
                $($(this).data('hider')).show(0);
            }
            else {
                $($(this).data('hider')).hide(0);
            }
        });


    });

    workArea.on('click', '.datum .edit', function (e) {
        e.preventDefault();
        $(this).parent().find('.show').fadeToggle(0);
        $(this).parent().find('.hide').fadeToggle(0);
    });

    $('.d-height').height($(window).height() - $('.top-container').height() - 24);


    $('.left-panel .scroll').height($('.left-panel').height() - 56 - $('.left-panel .bottom-panel').height());


    $('.left-panel .scroll').bind(
        'jsp-scroll-y',
        function (event, scrollPositionY, isAtTop, isAtBottom) {
            if (isAtBottom && $('.list-items .loader.post').size()) {
                $('.list-items .loader.post').removeClass('post');
                getList($('.list-items .loader').data('next'));
            }

        }
    ).jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });

    $(".list-items").on("click", ".item", function (e) {
        if (!$(e.target).is('input,label,label i')) {
            if (!$(this).is('.active')) {
                if (typeof map != 'undefined') {
                    $('.list-items .item.active').each(function () {
                        if (findPlace($(this).data('id')) !== undefined) {
                            findPlace($(this).data('id')).options.set('draggable', false);
                            findPlace($(this).data('id')).options.set('iconLayout', templates_place[0]);
                        }
                    });
                }
                getObjectEditForm($(this).data('id'));
                $('.list-items .item').removeClass('active');
                $(this).addClass('active');
                if (typeof map != 'undefined') {
                    var c = findPlace($(this).data('id')).geometry.getCoordinates();
                    map.panTo([parseFloat(c[0]), parseFloat(c[1])]).then(function () {
                        map.setZoom(18);
                    }, function (err) {
                        alert('Произошла ошибка ' + err);
                    }, this);
                }
            }
            else {
                $(this).removeClass('active');
                if (typeof map != 'undefined') {
                    findPlace($(this).data('id')).options.set('draggable', false);
                    findPlace($(this).data('id')).options.set('iconLayout', templates_place[0]);
                }
                $('.edit-panel').remove();
                if ($(this).data('id') == 'new') $(this).remove();
            }
            $('.list-items .item[data-id=new]').remove();
        }
    });


    workArea.on('input', '.change-input', function (e) {
        var id = $(this).parents('form').data('id');
        $('.item[data-id=' + id + '] .' + $(this).data('change') + ', .object[data-id=' + id + '] .' + $(this).data('change')).text($(this).val());
    });


    workArea.on('click', '#save-object', function () {
        var check = 1;
        $('.base-form input.require').each(function () {
            removeMessageInput($(this));
            if (!$(this).val()) {
                addErrorInputShort($(this));
                check = 0;
            }
            else {
                addSuccessInputShort($(this));
            }
            if ($(this).is('[name=email]')) {
                removeMessageInput($(this));
                if (!testinput(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, $(this).val())) {
                    addErrorInputShort($(this));
                    check = 0;
                }
                else {
                    addSuccessInputShort($(this));
                }
            }
        });


        if (check && typeof attention_fields != 'undefined') {
            var text = '';
            for (var i = 0; i < attention_fields.length; i++) {
                if (!$(attention_fields[i].name).val()) {
                    if ($(attention_fields[i].name).parent().is(':visible')) {
                        check = 0;
                        if (attention_fields[i].label) {
                            text = text + '<li>' + attention_fields[i].label + '</li>';
                        }

                        else {
                            text = text + '<li>' + $(attention_fields[i].name).parent().find('label').text() + '</li>';
                        }
                    }
                }
            }
            if (text) {
                $('#popup_fields ul').html(text);
                $.fancybox('#popup_fields');
            }
        }


        if (check) {
            saveObject();
        }

    });


    var interval;
    $('#id_search').on('change', function () {
        clearTimeout(interval);
        var dInput = this.value;
        if (dInput.length > 0) {
            clearItemList();
            interval = setTimeout(function () {
                getList(1, dInput);
            }, 800);
        }
        else {
            clearItemList();
            getList(1, '');
        }
    });


    $('.left-panel #add-object').click(function (e) {
        e.preventDefault();
        closeEdit();
        getCreateObjectForm({'name': $('#id_search').val(), 'class': getClassName()});
    });


});








