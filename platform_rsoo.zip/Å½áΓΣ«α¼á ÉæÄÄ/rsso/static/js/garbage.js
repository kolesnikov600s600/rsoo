var suggest;

$(function () {

    var workArea = $('.work-area');

    workArea.on("loadData", '.edit-panel', function (e) {
        $(this).height($(window).height() - $('.top-container').height() - 24);
        $(this).find('.inner-area').height($(this).height() - 60);
        $(this).find('select').styler({
            selectPlaceholder: $(this).data('placeholder')
        });
        console.log($('.edit-panel .adr-form').height() > $('.d-height').height());
        if ($('.edit-panel .adr-form').height() > $('.d-height').height()) {
            $('.adr-form').height($(window).height() - $('.top-container').height() - 24);
            $('.adr-form').jScrollPane({
                autoReinitialise: 1,
                autoReinitialiseDelay: 100
            });
        }


        $(this).find('.t-help').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
        $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});

        $("#id_address").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "ADDRESS",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change');
                var i = $(this).parents('form').data('id'),
                    t = $(this).val();

                if (findPlace(i) !== undefined) {
                    manager.remove(findPlace(i));
                }
                var geo = ymaps.geocode($(this).val());
                geo.then(
                    function (res) {

                        var c = res.geoObjects.get(0).geometry.getCoordinates();
                        managerAdd({'id': i, 'name': t}, c);
                        map.panTo(c).then(function () {
                            map.setZoom(18);
                        }, function (err) {
                            alert('Произошла ошибка ' + err);
                        }, this);

                        $('#id_lat').val(c[0]);
                        $('#id_lon').val(c[1]);
                    },
                    function (err) {
                        alert('Ошибка');
                    }
                );
            }
        });

        $("#id_org_1, #id_org_2").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "PARTY",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change').trigger('input');
                $(this).parent().find('.inn input').val(suggestion.data.inn).trigger('change').trigger('input');
                $(this).parent().find('.ogrn input').val(suggestion.data.ogrn).trigger('change').trigger('input');
            }
        });

        var data_select = [
            {id: '#id_type', data: ['Открытая', 'Закрытая', 'С навесом']},
            {id: '#id_surface', data: ['Асфальт', 'Бетон', 'Грунт', 'Брусчатка', 'Мрамор', 'Стекло']},
            {id: '#id_fences', data: ['Отсутствует', 'Сетка', 'Профлист', 'Бетон']},
            {id: '#id_place_kgm', data: ['Есть', 'Нет']}

        ];

        setAutoComplete(data_select);




    });

    $('.d-height').height($(window).height() - $('.top-container').height() - 24);


    $('.left-panel .scroll').height($('.left-panel').height() - 56 - $('.left-panel .bottom-panel').height());


    $('.left-panel .scroll').bind(
        'jsp-scroll-y',
        function (event, scrollPositionY, isAtTop, isAtBottom) {
            if (isAtBottom && $('.list-items .loader.post').size()) {
                $('.list-items .loader.post').removeClass('post');
                getPlatformList($('.list-items .loader').data('next'));
            }

        }
    ).jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });

    $(".list-items").on("click", ".item:not(.garbage)", function (e) {
        if (!$(e.target).is('input,label,label i,.garbage,.garbage *,.add')) {
            if (!$(this).is('.active')) {
                getEditFormPlatform($(this).data('id'));
                $('.list-items .item').removeClass('active');
                $(this).addClass('active');
                var p = findPlace($(this).data('id'));
                var c = findPlace($(this).data('id')).geometry.getCoordinates();

                map.panTo([parseFloat(c[0]), parseFloat(c[1])]).then(function () {
                    map.setZoom(18).then(function () {
                        if (!p.balloon.isOpen()) {
                            p.balloon.open();
                        }
                    }, function (err) {
                        alert('Произошла ошибка ' + err);
                    }, this);
                }, function (err) {
                    alert('Произошла ошибка ' + err);
                }, this);


            }
            else {
                $(this).removeClass('active');
                $('.edit-panel').remove();
                if ($(this).data('id') == 'new') $(this).remove();
            }
            $('.list-items .item[data-id=new]').remove();
        }
    });


    $(".list-items").on("mouseover", ".item:not(.garbage)", function (e) {

        var p = findPlace($(this).data('id'));

        if (!p.balloon.isOpen() && $('.list-items .item.active').size() == 0) {
            p.balloon.open();
        }


    });

    $(".list-items").on("mouseout", ".item:not(.garbage)", function (e) {

        var p = findPlace($(this).data('id'));

        if (p.balloon.isOpen() && $('.list-items .item.active').size() == 0) {
            p.balloon.close();
        }


    });


    workArea.on("click", ".items.garbage", function (e) {
        if (!$(e.target).is('.close')) {
            if (!$(this).is('.active')) {
                getEditContainerPlatform($(this).data('id'));
            }

        }
    });

    workArea.on("click", ".drop-list .add", function (e) {
        getCreateContainerForm($(this).parents('.item').data('id'));
    });


    workArea.on('change', '.edit-object .base-form input', function (e) {
        if (!$(this).parents('.edit-panel').is('.edit-garbage')) {
            if (!$(this).is('.error')) {
                editFieldPlatform($(this).parents('form').data('id'), $(this).prop('name'), $(this).val());
            }
        }
        else {
            if (!$(this).is('.error')) {
                editFieldContainer($(this).parents('form').data('id'), $(this).prop('name'), $(this).val());
            }
        }
    });

    workArea.on('change', '.edit-object.edit-garbage .base-form input', function (e) {

    });

    workArea.on('input', '.edit-object .base-form input.require', function (e) {
        removeMessageInput($(this));
        if (!$(this).val().length) {
            addErrorInput($(this));
        }
    });


    workArea.on('change', '.create-object .base-form input.require', function (e) {
        removeMessageInput($(this));

        if ($(this).val().length < 1) {
            addErrorInput($(this));
        }


        var check = 1;

        $('.base-form input.require').each(function () {
            if (!$(this).val() || $(this).is('.error')) {
                check = 0;
            }
            else {
                if (!$(this).is('.success')) {
                    addSuccessInput($(this));
                }
            }
        });
        var f = $('#input-filling');
        if (check) f.text('Параметры заполнены');
        else f.text('Заполните параметры');


    });


    workArea.on('input', '.change-input', function (e) {
        var id = $(this).parents('form').data('id');
        $('.item[data-id=' + id + '] .' + $(this).data('change') + ', .object[data-id=' + id + '] .' + $(this).data('change')).text($(this).val());
    });


    workArea.on('click', '#save-object.platform-item', function () {
        var check = 1;
        $('.base-form input.require').each(function () {
            removeMessageInput($(this));
            if (!$(this).val() || $(this).is('.error')) {
                addErrorInput($(this));
                check = 0;
            }
            else {
                addSuccessInput($(this));
            }
        });
        var f = $('#input-filling');
        if (f.text() == 'Параметры заполнены' && check) {
            showLoaderBase();
            $.ajax({
                type: "POST",
                url: '/ajax/',
                contentType: 'application/json; charset=utf-8',
                data: $.toJSON($('.create-object').serializeObject()),
                dataType: 'json',
                success: function (data) {
                    if (data['success']) {
                        $('.list-items .item[data-id=new]').replaceWith(data['html']);
                        manager.remove(findPlace('new'));
                        managerAdd(data['place'], data['place']['place']);
                        removeBaseLoader();
                        $('.edit-panel').remove();
                        $('.list-items .item[data-id=' + data['place']['id'] + ']').addClass('active');

                        getCreateContainerForm(data['place']['id']);

                    }
                }
            });

        }
    });

    workArea.on('click', '#save-object.container-item', function () {
        var check = 1;
        $('.base-form input.require').each(function () {
            removeMessageInput($(this));
            if (!$(this).val() || $(this).is('.error')) {
                addErrorInput($(this));
                check = 0;
            }
            else {
                addSuccessInput($(this));
            }
        });
        var f = $('#input-filling');
        if (f.text() == 'Параметры заполнены' && check) {
            showLoaderBase();
            $.ajax({
                type: "POST",
                url: '/ajax/',
                contentType: 'application/json; charset=utf-8',
                data: $.toJSON($('.create-object').serializeObject()),
                dataType: 'json',
                success: function (data) {
                    if (data['success']) {
                        $('.list-items .item[data-id=' + data['platform'] + ']').html(data['html1']);
                        removeBaseLoader();
                        findPlace(data['platform']).properties.set('balloonContent', data['html2']);
                        $('.edit-panel').remove();
                    }
                }
            });

        }
    });

    workArea.on('click', '.remove-container', function () {
        var i = $(this).parents('.garbage').data('id');
        $('.garbage[data-id=' + i + ']').remove();
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                'action': 'remove_container',
                'id': i
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {
                    findPlace(data['platform']).properties.set('balloonContent', data['html2']);
                }
            }
        });
    });


    var interval;
    $('#id_search').on('input', function () {
        clearTimeout(interval);
        var dInput = this.value;
        if (dInput.length > 0) {
            clearItemList();
            interval = setTimeout(function () {
                getPlatformList(1, dInput);
            }, 800);
        }
        else {
            clearItemList();
            getPlatformList(1, '');
        }
    });


    $('.left-panel #add-object').click(function (e) {
        e.preventDefault();
        closeEdit();
        getCreatePlatformForm({'name': $('#id_search').val()});
    });


});

function clearItemList() {
    $('.list-items').html('<div class="loader post"><i class="fa fa-spinner fa-pulse"></i></div>');
}


function getPlatformList(page, search) {
    if (search === undefined) {
        if ($('#id_search').val().length > 0) {
            search = $('#id_search').val();
        }
    }

    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_platform_list',
                'page': page,
                'search': search
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                $('.list-items .loader').remove();
                $('.list-items').append(data['html']);
                $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
                if (data['page'] == 1) {
                    manager.removeAll();
                }
                addObjectsMap(data['places']);
                //if (data['page'] == 1 && data['places'].length) {
                //    map.panTo([parseFloat(data['places'][0].place[0]), parseFloat(data['places'][0].place[1])]);
                //}
            }

        }
    });

}

function editFieldPlatform(id, status, value) {
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'edit_field_platform',
                'id': id,
                'field': status,
                'value': value
            }
        ),
        dataType: 'json'

    });
}

function editFieldContainer(id, status, value) {
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'edit_field_container',
                'id': id,
                'field': status,
                'value': value
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                $('.list-items .garbage[data-id=' + data['id'] + ']').replaceWith(data['html1']);
                $('.prompt .garbage[data-id=' + data['id'] + ']').replaceWith(data['html2']);
            }

        }

    });
}

function getEditFormPlatform(id) {
    showLoaderBase();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_platform_form',
                'id': id
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function getEditContainerPlatform(id) {
    showLoaderBase();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_container_form',
                'id': id
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function closeEdit() {
    var a = $('.list-items .item.active');
    if (a.data('id') == 'new') {
        a.remove();
    }
    a.removeClass('active');
    $('.edit-panel').remove();
}


function getCreatePlatformForm(d) {
    showLoaderBase();
    createBlankItem(d);
    d['action'] = 'get_create_platform_form';
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}


function getCreateContainerForm(d) {
    showLoaderBase();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON({
            action: 'get_create_container_form',
            id: d
        }),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function createBlankItem(d) {
    $('.list-items .item[data-id=new]').remove();
    $('.list-items').prepend('<div class="item transport active" data-id="new"><div class="name"><strong>Контейнерная площадка №</strong><strong class="change-number">0</strong><br><span class="change-address"></span></div></div>')
}

function changeEditPanel(data) {
    $('.edit-panel').remove();
    removeBaseLoader();
    $('.left-panel').after(data);
    $(".edit-panel").trigger('loadData');
}


function getPrompt(id, place) {
    var d = {
        action: 'get_platform_prompt',
        id: id
    };
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                place.properties.set('balloonContent', data['html']);
            }

        }
    });
}
