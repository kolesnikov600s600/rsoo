var suggest;

$(function () {

    var workArea = $('.work-area');

    workArea.on("loadData", '.edit-panel', function (e) {
        $(this).height($(window).height() - $('.top-container').height() - 24);
        $(this).find('.inner-area').height($(this).height() - 60);
        $(this).find('select').styler({
            selectPlaceholder: $(this).data('placeholder')
        });
        if ($('.edit-panel .adr-form').height() > $('.d-height').height()) {
            $('.adr-form').height($(window).height() - $('.top-container').height() - 24);
            $('.adr-form').jScrollPane({
                autoReinitialise: 1,
                autoReinitialiseDelay: 100
            });
        }


        $(this).find('.t-help').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
        $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});

        $("#id_address").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "ADDRESS",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change');
                var i = $(this).parents('form').data('id'),
                    t = $(this).val();

                if (findPlacePl(i) !== undefined) {
                    manager.remove(findPlacePl(i));
                }
                var geo = ymaps.geocode($(this).val());
                geo.then(
                    function (res) {

                        var c = res.geoObjects.get(0).geometry.getCoordinates();
                        addObjectsMap([{'id': i, 'name': t, 'place': c}], true);
                        findPlacePl(i).options.set('draggable', true);
                        findPlacePl(i).options.set('iconLayout', templates_place[1]);
                        map.panTo(c).then(function () {
                            map.setZoom(18);
                        }, function (err) {
                            alert('Произошла ошибка ' + err);
                        }, this);
                        $('#id_lat').val(c[0].toFixed(6));
                        $('#id_lon').val(c[1].toFixed(6));
                    },
                    function (err) {
                        alert('Ошибка');
                    }
                );
            }
        });

        $("#id_org_1, #id_org_2").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "PARTY",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change').trigger('input');
                $(this).parent().find('.inn input').val(suggestion.data.inn).trigger('change').trigger('input');
                $(this).parent().find('.ogrn input').val(suggestion.data.ogrn).trigger('change').trigger('input');
            }
        });

        var data_select = [
            {id: '#id_type', data: ['Открытая', 'Закрытая', 'С навесом']},
            {id: '#id_surface', data: ['Асфальт', 'Бетон', 'Грунт', 'Брусчатка', 'Мрамор', 'Стекло']},
            {id: '#id_fences', data: ['Отсутствует', 'Сетка', 'Профлист', 'Бетон']},
            {id: '#id_place_kgm', data: ['Есть', 'Нет']},
            {id: '#id_capacity_container', data: ['0.24', '0.75', '1.1', '8.0']},
            {id: '#id_material', data: ['Пластик', 'Металл']},
            {id: '#id_mkd', data: ['Да', 'Нет']},
            {id: '#id_dispose', data: ['Несортированные отходы', 'Утилизируемые отходы']}

        ];



        setAutoComplete(data_select);

        $('#id_number').trigger('input');

        $('.datum .edit').click(function (e) {
            e.preventDefault();
            $(this).parent().find('.show').fadeToggle(0);
            $(this).parent().find('.hide').fadeToggle(0);
        });




    });

    $('.d-height').height($(window).height() - $('.top-container').height() - 24);


    $('.left-panel .scroll').height($('.left-panel').height() - 56 - $('.left-panel .bottom-panel').height());


    $('.left-panel .scroll').bind(
        'jsp-scroll-y',
        function (event, scrollPositionY, isAtTop, isAtBottom) {
            if (isAtBottom && $('.list-items .loader.post').size()) {
                $('.list-items .loader.post').removeClass('post');
                getPlatformList($('.list-items .loader').data('next'));
            }

        }
    ).jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });

    $(".list-items").on("click", ".item:not(.garbage)", function (e) {
        if (!$(e.target).is('input,label,label i,.garbage,.garbage *,.add')) {
            if (!$(this).is('.active')) {
                $('.list-items .item.active').each(function () {
                    if (findPlacePl($(this).data('id')) !== undefined) {
                        findPlacePl($(this).data('id')).options.set('draggable', false);
                        findPlacePl($(this).data('id')).options.set('iconLayout', templates_place[0]);
                    }
                });
                getEditFormPlatform($(this).data('id'));
                $('.list-items .item').removeClass('active');
				$(this).addClass('active');
				$('.left-panel .scroll').data('jsp').scrollToElement(this);
                var p = findPlacePl($(this).data('id'));
                if (typeof p != 'undefined') {
                    var c = findPlacePl($(this).data('id')).geometry.getCoordinates();
					if (!p.balloon.isOpen()) {
                                p.balloon.open();
                    }
				}


            }
            else {
                $(this).removeClass('active');
                findPlacePl($(this).data('id')).options.set('draggable', false);
                findPlacePl($(this).data('id')).options.set('iconLayout', templates_place[0]);
                $('.edit-panel').remove();
                if ($(this).data('id') == 'new') $(this).remove();
            }
            $('.list-items .item[data-id=new]').remove();
        }
    });


    $(".list-items").on("mouseover", ".item:not(.garbage)", function (e) {

        var p = findPlacePl($(this).data('id'));
        if (typeof p != 'undefined') {
        if (!p.balloon.isOpen() && $('.list-items .item.active').size() == 0) {
            p.balloon.open();
        }
            }


    });

    $(".list-items").on("mouseout", ".item:not(.garbage)", function (e) {

        var p = findPlacePl($(this).data('id'));
 if (typeof p != 'undefined') {
        if (p.balloon.isOpen() && $('.list-items .item.active').size() == 0) {
            p.balloon.close();
        }
        }


    });


    workArea.on("click", ".items.garbage", function (e) {
        if (!$(e.target).is('.close')) {
            if (!$(this).is('.active')) {
                getEditContainerPlatform($(this).data('id'));
            }

        }
    });

    workArea.on("click", ".drop-list .add", function (e) {
        getCreateContainerForm($(this).parents('.item').data('id'));
    });




    workArea.on('input', '.edit-object .base-form input.require', function (e) {
        removeMessageInput($(this));
        if (!$(this).val().length) {
            addErrorInputShort($(this));
        }
    });


    workArea.on('change', '.create-object .base-form input.require', function (e) {
        removeMessageInput($(this));

        if ($(this).val().length < 1) {
            addErrorInputShort($(this));
        }


        var check = 1;

        $('.base-form input.require').each(function () {
            if (!$(this).val() || $(this).is('.error')) {
                check = 0;
            }
            else {
                if (!$(this).is('.success')) {
                    addSuccessInputShort($(this));
                }
            }
        });
        var f = $('#input-filling');
        if (check) f.text('Параметры заполнены');
        else f.text('Заполните параметры');


    });



    workArea.on('input', '.change-input', function (e) {
        var id = $(this).parents('form').data('id');
        $('.item[data-id=' + id + '] .' + $(this).data('change') + ', .object[data-id=' + id + '] .' + $(this).data('change')).text($(this).val());
    });


     workArea.on('click', '#save-object', function () {
        var check = 1;
        $('.base-form input.require').each(function () {
            removeMessageInput($(this));
            if (!$(this).val()) {
                addErrorInputShort($(this));
                check = 0;
            }
            else {
                addSuccessInputShort($(this));
            }
            if ($(this).is('[name=email]')) {
                removeMessageInput($(this));
                if (!testinput(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, $(this).val())) {
                    addErrorInputShort($(this));
                    check = 0;
                }
                else {
                    addSuccessInputShort($(this));
                }
            }
        });

         var attention_fields = [];

         if ($(this).is('.platform-item')) {
                attention_fields = [
                    {name: '#id_type', label: 'Вид площадки'},
                    {name: '#id_surface', label: 'Тип поверхности'},
                    {name: '#id_fences', label: 'Материал ограждения'},
                    {name: '#id_org_1', label: 'Обслуживающая организация'},
                    {name: '#id_org_2', label: 'Организация-балансодержатель'},
                    {name: '#id_place_kgm', label: 'Наличие места для КГМ'}
                ];
            }

        if (check && typeof attention_fields != 'undefined') {
            var text = '';
            for (var i = 0; i < attention_fields.length; i++) {
                if (!$(attention_fields[i].name).val()) {
                    if ($(attention_fields[i].name).parent().is(':visible')) {
                        check = 0;
                        if (attention_fields[i].label) {
                            text = text + '<li>' + attention_fields[i].label + '</li>';
                        }

                        else {
                            text = text + '<li>' + $(attention_fields[i].name).parent().find('label').text() + '</li>';
                        }
                    }
                }
            }
            if (text) {
                $('#popup_fields ul').html(text);
                $.fancybox('#popup_fields');
            }
        }


        if (check) {
            if ($(this).is('.platform-item')) {
                saveObjectPlatform();
            }
            else {
                saveObjectContainer();
            }

        }

    });




    workArea.on('click', '.remove-container', function () {
        var i = $(this).parents('.garbage').data('id');
        $('.garbage[data-id=' + i + ']').remove();
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                'action': 'remove_container',
                'id': i
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {
                    findPlacePl(data['platform']).properties.set('balloonContent', data['html2']);
                }
            }
        });
    });


    var interval;
    $('#id_search').on('input', function () {
        clearTimeout(interval);
        var dInput = this.value;
        if (dInput.length > 0) {
            clearItemList();
            interval = setTimeout(function () {
                getPlatformList(1, dInput);
            }, 800);
        }
        else {
            clearItemList();
            getPlatformList(1, '');
        }
    });


    $('.left-panel #add-object').click(function (e) {
        e.preventDefault();
        closeEdit();
        getCreatePlatformForm({'name': $('#id_search').val()});
    });


});

function clearItemList() {
    $('.list-items').html('<div class="loader post"><i class="fa fa-spinner fa-pulse"></i></div>');
}

var create_from = true;

function getPlatformList(page, search, bounds) {
    if (search === undefined) {
        if ($('#id_search').val().length > 0) {
            search = $('#id_search').val();
        }
    }
	var boundsString = bounds[0][0] + ',' + bounds[0][1] + ',' + bounds[1][0] + ',' + bounds[1][1];
    $.ajax({
        type: "GET",
        url: '/ajax/?bbox=' + boundsString + '&action=get_objects_list_geo&class=Platforms',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (data) {
            if (data.features !== undefined) {
                $('.list-items .loader').remove();
                $('.list-items').html(data.html);
                $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
                addObjectsMap(data.features);
                /*if (data.features.length > 0) {
                    if (manager.length > 1) {
                        map.setBounds(manager.getBounds());
                    }
                    else {
                        map.panTo([parseFloat(data.features[0].geometry.coordinates[0]), parseFloat(data.features[0].geometry.coordinates[1])]).then(function () {
                            map.setZoom(18);
                        }, function (err) {
                            alert('Произошла ошибка ' + err);
                        }, this);
                    }
                }*/
                var id_waste = getParametrUrl('cfaw');
                if (id_waste && create_from) {
                    create_from = false;
                    getCreatePlatformForm({'waste': id_waste});
                }
                 var id_house = getParametrUrl('cfh');
                if (id_house && create_from) {
                    create_from = false;
                    getCreatePlatformForm({'house': id_house});
                }

            }

        }
    });

}



function getEditFormPlatform(id) {
    showLoaderBase();
     if (typeof findPlacePl(id) != 'undefined') {
         findPlacePl(id).options.set('draggable', true);
         findPlacePl(id).options.set('iconLayout', templates_place[1]);
     }
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_platform_form',
                'id': id
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function getEditContainerPlatform(id) {
    showLoaderBase();

    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_container_form',
                'id': id
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function closeEdit() {
    var a = $('.list-items .item.active');
    a.each(function () {
        if (findPlacePl($(this).data('id')) !== undefined) {
            findPlacePl($(this).data('id')).options.set('draggable', false);
            findPlacePl($(this).data('id')).options.set('iconLayout', templates_place[0]);
        }
    });
    if (a.data('id') == 'new') {
        a.remove();
    }
    a.removeClass('active');
    $('.edit-panel').remove();
}


function getCreatePlatformForm(d) {
    showLoaderBase();
    createBlankItem(d);
    d['action'] = 'get_create_platform_form';
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
                if ($('#id_lat').val() && $('#id_lon').val()) {
                    addObjectsMap([{'id': 'new', 'name': $('#id_address').val(), 'place': [$('#id_lat').val() , $('#id_lon').val()]}]);
                    findPlacePl('new').options.set('draggable', true);
                        findPlacePl('new').options.set('iconLayout', templates_place[1]);
                        map.setCenter([$('#id_lat').val() , $('#id_lon').val()]);
                }

            }

        }
    });
}


function getCreateContainerForm(d) {
    showLoaderBase();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON({
            action: 'get_create_container_form',
            id: d
        }),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function createBlankItem(d) {
    $('.list-items .item[data-id=new]').remove();
    $('.list-items').prepend('<div class="item transport active" data-id="new"><div class="name"><strong>Контейнерная площадка №</strong><strong class="change-number">0</strong><br><span class="change-address"></span></div></div>')
}

function changeEditPanel(data) {
    $('.edit-panel').remove();
    removeBaseLoader();
    $('.left-panel').after(data);
    $(".edit-panel").trigger('loadData');
}


function getPrompt(id, place) {
    var d = {
        action: 'get_platform_prompt',
        id: id
    };
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                place.properties.set('balloonContent', data['html']);
            }

        }
    });
}


function saveObjectPlatform() {
     if (usersign) {
        $.fancybox('#signing_popup2');
        usersign = false;
        return true;
    }
    showLoaderBase();
    if ($('.edit-panel').data('id') == 'new') {
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                form: $('.create-object').serializeObject(),
                id: $('.edit-panel').data('id'),
                action: 'create_platform'
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {

                    $('.list-items .item[data-id=new]').replaceWith(data['html']);
                     if (typeof manager != 'undefined') {
                         map.geoObjects.removeAll();
                         getPlatformList('', '', map.getBounds());
                         //manager.remove(findPlacePl('new'));
                         //managerAdd(data['place'], data['place']['place']);
                     }
                    removeBaseLoader();
                    $('.edit-panel').remove();
                }
            }
        });
    }
    else {
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                form: $('.edit-object').serializeObject(),
                id: $('.edit-panel').data('id'),
                action: 'save_platform'
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {
                     if (typeof manager != 'undefined') {
                         if (typeof findPlacePl(data['id']) != 'undefined') {
                         findPlacePl(data['id']).properties.set('iconContent', data['name']);
                        }
                     }
                    closeEdit();
                    $('.left-panel .item[data-id=' + data['id'] + ']').replaceWith(data['html']);
                    removeBaseLoader();

                }
            }
        });


    }
}function saveObjectContainer() {
     if (usersign) {
        $.fancybox('#signing_popup2');
        usersign = false;
        return true;
    }
    showLoaderBase();
    if ($('.edit-panel').data('id') == 'new') {
        $.ajax({
                type: "POST",
                url: '/ajax/',
                contentType: 'application/json; charset=utf-8',
                data: $.toJSON({
                    form: $('.create-object').serializeObject(),
                    action: 'create_container'
                }),
                dataType: 'json',
                success: function (data) {
                    if (data['success']) {
                        $('.list-items .item[data-id=' + data['platform'] + ']').html(data['html1']);
                        removeBaseLoader();
                        findPlacePl(data['platform']).properties.set('balloonContent', data['html2']);
                        $('.edit-panel').remove();
                    }
                }
            });
    }
    else {
        $.ajax({
                type: "POST",
                url: '/ajax/',
                contentType: 'application/json; charset=utf-8',
                data: $.toJSON({
                    form: $('.edit-object').serializeObject(),
                    action: 'save_container',
                    id: $('.edit-panel').data('id')
                }),
                dataType: 'json',
                success: function (data) {
                    if (data['success']) {
                        $('.list-items .item[data-id=' + data['platform'] + ']').html(data['html1']);
                        removeBaseLoader();
                        findPlacePl(data['platform']).properties.set('balloonContent', data['html2']);
                        $('.edit-panel').remove();
                    }
                }
            });


    }
}

function deleteObject(classname, id) {
     if (usersign) {
        $.fancybox('#signing_popup2');
        usersign = false;
        return true;
    }
    showLoaderBase();
    if (typeof manager != 'undefined') {
        findPlacePl(id).options.set('draggable', true);
        findPlacePl(id).options.set('iconLayout', templates_place[1]);
    }
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'delete_object',
                'id': id,
                'class': classname
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                removeBaseLoader();
                closeEdit();
                $('.list-items .item[data-id='+data['id']+']').remove();
                if (typeof manager != 'undefined') {
                    manager.remove(findPlacePl(data['id']));
                }
            }

        }
    });
}

function findPlacePl(id) {
    var f;
    $.each(objects, function () {
        if (id == getPlaceId(this)) {
            f = this;
        }
    });
    return f;
}


function deleteContainer(id) {
     if (usersign) {
        $.fancybox('#signing_popup2');
        usersign = false;
        return true;
    }
    showLoaderBase();
        var i = id;
        $('.garbage[data-id=' + i + ']').remove();
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                'action': 'remove_container',
                'id': i
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {
                    removeBaseLoader();
                    changeEditPanel('');
                    findPlacePl(data['platform']).properties.set('balloonContent', data['html2']);
                }
            }
        });
}

function getClassName() {
    return $('#ClassName').val();

}