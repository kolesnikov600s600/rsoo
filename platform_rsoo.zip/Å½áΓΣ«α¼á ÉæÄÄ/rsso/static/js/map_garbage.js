var map;
var map_objects;
var manager;

var place_templates = {
    'container': '<div class="placemark"></div>',
    'house': '<div class="placemark house"><i></i></div>'
};

var test_data = [

    {
        id: 1, place: [55.80, 37.50], 'name': 'parent', drag: false, template: 'container', childrens: [
        {id: 2, place: [55.70, 37.40], 'name': 'id2', drag: true, template: 'house', id_line: 'line1', parent: 1},
        {id: 3, place: [55.60, 37.20], 'name': 'id3', drag: true, template: 'house', id_line: 'line2', parent: 1},
        {id: 4, place: [55.90, 37.80], 'name': 'id4', drag: true, template: 'house', id_line: 'line3', parent: 1}
    ]
    },
    {id: 5, place: [55.85, 37.20], 'name': 'parent', drag: false, template: 'house'},
    {id: 6, place: [55.90, 37.50], 'name': 'parent', drag: false, template: 'house'}
];
function init_map() {
    map = new ymaps.Map('map', {
        center: [55.75396, 37.620393],
        zoom: 10,
        controls: []

    });

    map.controls.add('zoomControl', {
        float: 'left',
        position: {
            bottom: 30,
            right: 10,
            left: 'auto'
        }
    });

    manager = new ymaps.GeoObjectCollection();


    addObjectsMap(test_data);

}

function addObjectsMap(data) {

    for (var i = 0; i < data.length; i++) {
        var cc = [data[i].place[0], data[i].place[1]];
        managerAdd(data[i], cc);
        if (data[i]['childrens']) {
            addObjectsMap(data[i]['childrens']);
        }
    }

}

function managerAdd(el, c) {


    var placeIco = ymaps.templateLayoutFactory.createClass(place_templates[el.template]);
    var p_options = {
        iconLayout: placeIco,
        draggable: el['drag'] ? 1 : 0,
        openEmptyBalloon: true,
        iconShape: {
            type: 'Circle',
            coordinates: [0, 0],
            radius: 12
        },

        openHintOnHover: true,
        hideIconOnBalloonOpen: false,

        balloonPanelMaxMapArea: 0,
        zIndexDrag: 1000,
        zIndexHover: 1000

    };

    var p = new ymaps.Placemark(
        {
            type: "Point",
            coordinates: c
        },
        {
            id: el.id,
            id_line: el.id_line,
            template: el.template,
            clusterCaption: el.name,
            hintContent: el.name

        },
        p_options
    );

    p.events.add('drag', function (e) {
        var p = e.get('target'),
            c1 = p.geometry.getCoordinates(),
            c2 = findPlace(el['parent']).geometry.getCoordinates();

        findPlace(el['id_line']).geometry.setCoordinates([c2, c1]);

    });

    p.events.add('drag', function (e) {
        var p = e.get('target'),
            c1 = p.geometry.getCoordinates(),
            c2 = findPlace(el['parent']).geometry.getCoordinates();

        findPlace(el['id_line']).geometry.setCoordinates([c2, c1]);

    });

    if (el['parent']) {
        addConnectLine([findPlace(el['parent']).geometry.getCoordinates(), c], el['id_line']);
    }


    manager.add(p);

    map.geoObjects.add(manager);
}

function findPlace(id) {
    var f;
    manager.each(function (e) {
        if (id == getPlaceId(e)) {
            f = e;
        }
    });
    return f;
}

function getPlaceId(p) {
    return p.properties.get('id');
}

function addConnectLine(c, id) {
    var line = new ymaps.GeoObject({
        geometry: {
            type: "LineString",
            coordinates: c
        },
        properties: {
            id: id
        }
    }, {
        draggable: false,
        strokeColor: "#999999",
        strokeWidth: 2
    });

    manager.add(line);

    map.geoObjects.add(manager);
}