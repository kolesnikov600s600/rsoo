

function getList(page, search) {
    if (search !== undefined) {
        if ($('#id_search').val().length > 0) {
            search = $('#id_search').val();
        }
    }

    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_objects_list',
                'page': page,
                'class': getClassName(),
                'search': search
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                $('.list-items .loader').remove();
                $('.list-items').append(data['html']);
                $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
                if (typeof map != 'undefined') {
                if (data['page'] == 1) {
                    manager.removeAll();
                }

                    addObjectsMap(data['places']);
                    if (data['places'].length > 0) {
                        if (manager.getLength() > 1) {
                            map.setBounds(manager.getBounds());
                        }
                        else {
                            map.panTo([parseFloat(data['places'][0].place[0]), parseFloat(data['places'][0].place[1])]).then(function () {
                                map.setZoom(18);
                            }, function (err) {
                                alert('Произошла ошибка ' + err);
                            }, this);
                        }
                    }
                }


            }

        }
    });

}



function changeEditPanel(data) {
    $('.edit-panel').remove();
    removeBaseLoader();
    $('.left-panel').after(data);
    $(".edit-panel").trigger('loadData');
}

function createBlankItem(d) {
    $('.list-items .item[data-id=new]').remove();
    $('.list-items').prepend('<div class="item transport active" data-id="new"><div class="name"><strong>Новый объект</strong></div></div>')
}


function getObjectEditForm(id) {
    showLoaderBase();
    if (typeof map != 'undefined') {
        findPlace(id).options.set('draggable', true);
        findPlace(id).options.set('iconLayout', templates_place[1]);
    }
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_object_form',
                'id': id,
                'class': getClassName()
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}

function closeEdit(id) {
    var a = $('.list-items .item.active');
     if (typeof map != 'undefined') {
         a.each(function () {
             if (findPlace($(this).data('id')) !== undefined) {
                 findPlace($(this).data('id')).options.set('draggable', false);
                 findPlace($(this).data('id')).options.set('iconLayout', templates_place[0]);
             }
         });
     }
    if (a.data('id') == 'new') {
        a.remove();
    }
    a.removeClass('active');
    $('.edit-panel').remove();

}

function getCreateObjectForm(d) {
    showLoaderBase();
    createBlankItem(d);
    d['action'] = 'get_create_object_form';
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
            }

        }
    });
}


function clearItemList() {
    $('.list-items').html('<div class="loader post"><i class="fa fa-spinner fa-pulse"></i></div>');
}


function saveObject() {
    if (usersign) {
        $.fancybox('#signing_popup2');
        usersign = false;
        return true;
    }
    showLoaderBase();

    if ($('.edit-panel').data('id') == 'new') {
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                form: $('.create-object').serializeObject(),
                id: $('.edit-panel').data('id'),
                class: getClassName(),
                action: 'create_object'
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {

                    $('.list-items .item[data-id=new]').replaceWith(data['html']);
                     if (typeof map != 'undefined') {
                         manager.remove(findPlace('new'));
                         managerAdd(data['place'], data['place']['place']);
                     }
                    removeBaseLoader();
                    closeEdit();
                }
            }
        });
    }
    else {
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                form: $('.edit-object').serializeObject(),
                id: $('.edit-panel').data('id'),
                class: getClassName(),
                action: 'save_object'
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {
                     if (typeof map != 'undefined') {
                         findPlace(data['id']).properties.set('iconContent', data['name']);
                     }
                    closeEdit();
                    $('.left-panel .item[data-id=' + data['id'] + ']').replaceWith(data['html']);
                    removeBaseLoader();


                }
            }
        });


    }
}


function deleteObject(classname, id) {
    if (usersign) {
        $.fancybox('#signing_popup2');
        usersign = false;
        return true;
    }

    showLoaderBase();



    if (typeof map != 'undefined') {
        findPlace(id).options.set('draggable', true);
        findPlace(id).options.set('iconLayout', templates_place[1]);
    }
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'delete_object',
                'id': id,
                'class': classname
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                removeBaseLoader();
                closeEdit();
                $('.list-items .item[data-id='+data['id']+']').remove();
                if (typeof map != 'undefined') {
                    manager.remove(findPlace(data['id']));
                }
            }

        }
    });
}

