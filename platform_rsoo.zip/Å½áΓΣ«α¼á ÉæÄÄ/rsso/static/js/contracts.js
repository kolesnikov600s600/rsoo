var suggest;

$(function () {

    var workArea = $('.work-area');

    workArea.on("loadData", '.edit-panel', function (e) {
        $(this).height($(window).height() - $('.top-container').height() - 24);
        $(this).find('.inner-area').height($(this).height() - 60);
        $(this).find('select').styler({
            selectPlaceholder: $(this).data('placeholder')
        });
        if ($('.edit-panel .adr-form').height() > $('.d-height').height()) {
            $('.adr-form').height($(window).height() - $('.top-container').height() - 24);
            $('.adr-form').jScrollPane({
                autoReinitialise: 1,
                autoReinitialiseDelay: 100
            });
        }


        $(this).find('.t-help').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
        $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});

        $("input[name=points], input[name=firms]").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "ADDRESS",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).prop('readonly', 'readonly');
                var id = 'new-' + $(this).data('count');
                $(this).after('<i data-id="' + id + '" class="new fa fa-remove"></i>');
                var address = $(this).val();
                var f = $(this);
                f.suggestions('disable');
                var geo = ymaps.geocode(address);
                geo.then(
                    function (res) {
                        var c = res.geoObjects.get(0).geometry.getCoordinates();
                        managerAdd({'id': id, 'contracts': [], 'address': address}, c);
                        var p = findPlace(id);
                        p.properties.set('open', true);
                        p.options.set('draggable', true);
                        p.options.set('iconLayout', templates_place[7]);

                        f.parent().find('input[name=lat]').val(c[0].toFixed(6));
                        f.parent().find('input[name=lon]').val(c[1].toFixed(6));
                    },
                    function (err) {
                        alert('Ошибка');
                    }
                );

            }
        });

        $("#id_org_1, #id_org_2, #id_org_3, #id_gps_firm").suggestions({
            serviceUrl: "https://dadata.ru/api/v2",
            token: "355f93ce71c996490531a51e9b6d924a54399dd4",
            type: "PARTY",
            count: 10,
            width: 267,
            onSelect: function (suggestion) {
                $(this).trigger('change').trigger('input');
                $(this).parent().find('.inn input').val(suggestion.data.inn).trigger('change').trigger('input');
                $(this).parent().find('.ogrn input').val(suggestion.data.ogrn).trigger('change').trigger('input');
            }
        });

        $('input[name=phone]').mask('+7 (999) 999-99-99');


        setAutoComplete(data_select);

        if (typeof data_related != 'undefined') {
            setRelatedFields(data_related);
        }

        $("#id_contract_date").datepicker({dateFormat: 'dd.mm.yy', regional: ['ru']});

        $('#choice_code').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "/ajax/",
                    dataType: "json",
                    data: {
                        action: 'code_fkko',
                        q: request.term
                    },
                    success: function (data) {
                        response(data);
                    }
                });
            },
            select: function (event, ui) {
                $("#id_fkko").val(ui.item.id);
                $('#description-fkko').html('<div class="description-field">' + ui.item.label + '</div>');
                $('#choice_code').val(ui.item.value);
                return false;
            }
        }).autocomplete("instance")._renderItem = function (ul, item) {
            return $("<li>")
                .append("<a id='" + item.id + "'>" + item.value + '<br>' + item.label + "</a>")
                .appendTo(ul);
        };


        $('.name-block').click(function () {
            $(this).next().slideToggle();
            $(this).find('i').toggleClass('fa-chevron-down').toggleClass('fa-chevron-up')
        });


        $('#fileupload').fileupload({
            add: function(e, data) {
                    var uploadErrors = [];
                    if(data.originalFiles[0]['size'] > 30000000) {
                        $.fancybox('<strong style="font-size:22px;">Неверный файл</strong><br><br>Размер файла должен быть <strong>не более 30MB</strong>');
                    }
                    else {
                        data.submit();
                    }
            },
            dataType: 'json',
            autoUpload: false,
            done: function (e, data) {
                $.each(data.result, function (index, file) {
                    var html = '';
                    if ($('#result-file').find('strong').size() == 0) {
                        html = '<strong>Файлы</strong><br>';
                    }
                    html = html + '<div class="file"><a href="' + file.url + '" target="_blank">' + file.name + '</a><i class="fa fa-remove" data-id="' + file.id + '"></i></div>';
                    $(html).appendTo('#result-file');
                    $('#file-input').append('<input type="hidden" value="' + file.id + '" id="id_file_' + file.id + '" name="file">');
                });
            },
            progressall: function (e, data) {
                var progress = parseInt(data.loaded / data.total * 100, 10);
                $('#progress .bar').css('width', progress + '%');
                if (progress == 100) {
                    $('#progress .bar').css('width', '0');
                }
            }
        });


        $('.add-address').click(function (e) {
            e.preventDefault();
            var s = 2;
            $('.address.new input[name=points]').each(function(){
                if (parseInt($(this).data('count')) == s) {
                    s = parseInt($(this).data('count')) + 1
                }
            });

            var ht = $('<div class="address new"><input data-count="' + s + '" name="points" type="text"/><input name="lat" type="hidden"/><input name="lon" type="hidden"/></div>');


            ht.find("input[name=points], input[name=firms]").suggestions({
                serviceUrl: "https://dadata.ru/api/v2",
                token: "355f93ce71c996490531a51e9b6d924a54399dd4",
                type: "ADDRESS",
                count: 10,
                width: 267,
                onSelect: function (suggestion) {
                    $(this).prop('readonly', 'readonly');
                    var id = 'new-' + $(this).data('count');
                    $(this).after('<i data-id="' + id + '" class="new fa fa-remove"></i>');
                    var address = $(this).val();
                    var f = $(this);
                    f.suggestions('disable');
                    var geo = ymaps.geocode(address);
                    geo.then(
                        function (res) {
                            var c = res.geoObjects.get(0).geometry.getCoordinates();
                            managerAdd({'id': id, 'contracts': [], 'address': address}, c);
                            var p = findPlace(id);

                            p.properties.set('open', true);
                            p.options.set('draggable', true);
                            p.options.set('iconLayout', templates_place[7]);

                            f.parent().find('input[name=lat]').val(c[0]);
                            f.parent().find('input[name=lon]').val(c[1]);
                        },
                        function (err) {
                            alert('Ошибка');
                        }
                    );

                }
            });

            $(this).before(ht);


        });


    });

    workArea.on('click', '.datum .edit', function (e) {
        e.preventDefault();
        $(this).parent().find('.show').fadeToggle(0);
        $(this).parent().find('.hide').fadeToggle(0);
    });

    workArea.on('click', '.file i', function (e) {
        e.preventDefault();
        var d = $(this).data('id');
        $('#id_file_' + d).remove();
        $(this).parent().remove();
    });

    workArea.on('click', '.address i', function (e) {
        e.preventDefault();
        var d = $(this).data('id');
        var p = findPlace(d);
        p.options.set('iconLayout', templates_place[0]);
        p.properties.set('open', false);
        var id_arr = p.properties.get('id', true).split('-');
        $('#id_' + id_arr[0] + '_' + id_arr[1]).remove();
        $('#id_blank_' + id_arr[0] + '_' + id_arr[1]).parent().remove();
        if ($(this).is('.new')) {
            manager.remove(p);
        }
        $(this).parent().remove();
    });

    $('.d-height').height($(window).height() - $('.top-container').height() - 24);


    $('.left-panel .scroll').height($('.left-panel').height() - 56 - $('.left-panel .bottom-panel').height());


    $('.left-panel .scroll').bind(
        'jsp-scroll-y',
        function (event, scrollPositionY, isAtTop, isAtBottom) {
            if (isAtBottom && $('.list-items .loader.post').size()) {
                $('.list-items .loader.post').removeClass('post');
                getList($('.list-items .loader').data('next'));
            }

        }
    ).jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });

    $(".list-items").on("click", ".item", function (e) {
        if (!$(e.target).is('input,label,label i')) {
            if (!$(this).is('.active')) {
                closeEdit();
                getObjectEditForm($(this).data('id'));
                $(this).addClass('active');
            }
            else {
                $(this).removeClass('active');
                closeEdit();
                if ($(this).data('id') == 'new') $(this).remove();
            }
            $('.list-items .item[data-id=new]').remove();
        }
    });


    workArea.on('click', '#save-object', function () {
        var check = 1;
        $('.base-form input.require').each(function () {
            removeMessageInput($(this));
            if (!$(this).val()) {
                addErrorInputShort($(this));
                check = 0;
            }
            else {
                addSuccessInputShort($(this));
            }
            if ($(this).is('[name=email]')) {
                removeMessageInput($(this));
                if (!testinput(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, $(this).val())) {
                    addErrorInputShort($(this));
                    check = 0;
                }
                else {
                    addSuccessInputShort($(this));
                }
            }
        });


        if (check && typeof attention_fields != 'undefined') {
            var text = '';
            for (var i = 0; i < attention_fields.length; i++) {
                if (!$(attention_fields[i].name).val()) {
                    if ($(attention_fields[i].name).parent().is(':visible')) {
                        check = 0;
                        if (attention_fields[i].label) {
                            text = text + '<li>' + attention_fields[i].label + '</li>';
                        }

                        else {
                            text = text + '<li>' + $(attention_fields[i].name).parent().find('label').text() + '</li>';
                        }
                    }
                }
            }
            if (text) {
                $('#popup_fields ul').html(text);
                $.fancybox('#popup_fields');
            }
        }


        if (check) {
            saveObject();
        }

    });


    var interval;
    $('#id_search').on('input', function () {
        clearTimeout(interval);
        var dInput = this.value;
        if (dInput.length > 0) {
            clearItemList();
            interval = setTimeout(function () {
                getList(1, dInput);
            }, 800);
        }
        else {
            clearItemList();
            getList(1, '');
        }
    });


    $('.left-panel #add-object').click(function (e) {
        e.preventDefault();
        closeEdit();
        getCreateObjectForm({'name': $('#id_search').val(), 'class': getClassName()});
    });


});








