$(function(){


     $('.d-height').height($(window).height() - $('.top-container').height() - 24);

    $('.left-panel .scroll').height($('.left-panel').height() - 56 - $('.left-panel .bottom-panel').height());


    $('.left-panel .scroll').jScrollPane({
            autoReinitialise: 1,
            autoReinitialiseDelay: 100
        });
    $('.informations li> a').click(function(e){
        e.preventDefault();
        if (!$(this).is('active')) {
            $(this).parents('ul').find('a').removeClass('active');
            $(this).addClass('active');
            $('.slide-info ul').trigger('slideTo', $(this).data('id'));
        }
    });

    $('.slide-info ul li .inf').each(function(){
        $(this).css('padding-top', (($('.slide-info').height()-$(this).height())/2) + 'px');
    });

     $('.slide-info ul').carouFredSel({
        items: 1,
        circular: true,
         responsive: true,
        auto: false,
        next: '.next',
        prev: '.prev',
        scroll: {items: 1, responsive: true, fx: 'fade', onAfter : function(e){
            console.log(e);
            $('.informations li> a').removeClass('active');
            $('.informations li> a[data-id='+$(e.items.visible).data('id')+']').addClass('active');
        }
        }
    });

    $('input[name=phone]').mask('+7 (999) 999-99-99');


    $('#change-contact input').bind('blur', function(){

        $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'change_contact',
                'value': $(this).val(),
                'field': $(this).prop('name')
            }
        ),
        dataType: 'json'

    });


    });

});