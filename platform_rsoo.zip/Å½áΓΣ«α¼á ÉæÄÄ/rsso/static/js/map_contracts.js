var map;
var map_objects;
var manager;
var templates_place;
function init_map() {
    map = new ymaps.Map('map', {
        center: [55.75396, 37.620393],
        zoom: 10,
        controls: []

    });

    map.controls.add('zoomControl', {
        float: 'left',
        position: {
            bottom: 30,
            right: 10,
            left: 'auto'
        }
    });

    manager = new ymaps.GeoObjectCollection();

    getList();

    templates_place = [
        ymaps.templateLayoutFactory.createClass('<div class="place-contract"></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="place-contract active"></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="place-contract hover"></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="place-contract hover active"></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="place-contract hover"><div class="t-map">Добавить адрес в договор</div></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="place-contract hover active"><div class="t-map">Удалить адрес из договора</div></div>'),

        ymaps.templateLayoutFactory.createClass('<div class="place-contract hover active"><div class="t-map">Удалить адрес из договора</div><div class="t-map2">Перетащите объект, чтобы уточнить его местонахождение</div></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="place-contract active"><div class="t-map2">Перетащите объект, чтобы уточнить его местонахождение</div></div>')
    ];

    addObjectsMap(points);
    if (points.length == 1) {
        map.setCenter(manager.get(0).geometry.getCoordinates());
        map.setZoom(16);

    }
    else {
         map.setBounds(manager.getBounds());
    }

    var waste = getParametrUrl('waste');
    var name_point = getParametrUrl('point') ? getParametrUrl('point'): 'firms';

    if (waste) {
        getObjectEditForm(getParametrUrl('contract'));
        pl = findPlace(name_point+'-'+waste).geometry.getCoordinates();
        map.panTo([parseFloat(pl[0]), parseFloat(pl[1])]).then(function () {
            map.setZoom(18);
        }, function (err) {
            alert('Произошла ошибка ' + err);
        }, this);

    }


}

function addObjectsMap(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var cc = [data[i].coordinates[0], data[i].coordinates[1]];
            managerAdd(data[i], cc);
        }
    }
}

function managerAdd(el, c) {
    var temp = templates_place[0];
    if (el.contracts.length > 0) {
        temp = templates_place[1];
    }
    var p_options = {
        iconLayout: temp,
        draggable: false,
        iconShape: {
            type: 'Circle',
            coordinates: [0, 0],
            radius: 15
        },
        openHintOnHover: true,
        hideIconOnBalloonOpen: false,
        balloonPanelMaxMapArea: 0

    };
    var p = new ymaps.Placemark(
        {
            type: "Point",
            coordinates: c
        },
        {
            id: el.id,
            address: el.address,
            contracts: el.contracts,
            open: false

        },
        p_options
    );

    p.events.add('mouseenter', function (e) {
        var pl = e.get('target');
        if (!$('.edit-panel').size()) {

            if (pl.properties.get('contracts').length) {
                pl.options.set('iconLayout', templates_place[3]);
            }
            else {
                pl.options.set('iconLayout', templates_place[2]);
            }
        }
        else {

            var dr = pl.options.get('draggable');

            if (pl.properties.get('open')) {
                if (dr) {
                    pl.options.set('iconLayout', templates_place[6]);
                }
                else {
                    pl.options.set('iconLayout', templates_place[5]);
                }

            }
            else {

                if (dr) {
                    pl.options.set('iconLayout', templates_place[7]);
                }
                else {
                   pl.options.set('iconLayout', templates_place[4]);
                }


            }
        }

    });

    p.events.add('mouseleave', function (e) {
        var pl = e.get('target');
        if (!$('.edit-panel').size()) {
            if (pl.properties.get('contracts').length) {
                pl.options.set('iconLayout', templates_place[1]);
            }
            else {
                pl.options.set('iconLayout', templates_place[0]);
            }
        }
        else {

             var dr = pl.options.get('draggable');

            if (pl.properties.get('open')) {

                if (dr) {
                    pl.options.set('iconLayout', templates_place[7]);
                }
                else {
                    pl.options.set('iconLayout', templates_place[1]);
                }

            }
            else {
                pl.options.set('iconLayout', templates_place[0]);
            }
        }

    });

    p.events.add('click', function (e) {
        var pl = e.get('target');
        if (!$('.edit-panel').size()) {
            if (pl.properties.get('contracts').length) {
                getObjectEditForm(pl.properties.get('contracts')[0]);
                $('.list-items .item[data-id=' + pl.properties.get('contracts')[0] + ']').addClass('active');
            }
            else {
                pl.properties.set('open', true);
                getCreateObjectForm({'name': $('#id_search').val(), 'class': getClassName()});
            }
        }
        else {
            var id_arr = pl.properties.get('id', true).split('-');
            if (pl.properties.get('open')) {
                $('#id_' + id_arr[0] + '_' + id_arr[1]).remove();
                $('#id_blank_' + id_arr[0] + '_' + id_arr[1]).parent().remove();
                //alert('Убрать');
                pl.properties.set('open', false);
                pl.options.set('iconLayout', templates_place[0]);
                if (id_arr[0] == 'new') {
                    $('input[data-count=' + id_arr[1] + ']').parent().remove();
                    manager.remove(pl);
                }
            }
            else {
                var html = '<input type="hidden" value="' + id_arr[1] + '" id="id_' + id_arr[0] + '_' + id_arr[1] + '" name="' + id_arr[0] + '">';
                $('#' + id_arr[0] + '-input').append(html);
                html = '<div class="address"><input readonly value="' + pl.properties.get('address') + '" id="id_blank_' + id_arr[0] + '_' + id_arr[1] + '" type="text"/><i data-id="' + pl.properties.get('id') + '" class="fa fa-remove"></i></div>';
                $('#result-address label').after(html);
                //alert('Добавить');
                pl.properties.set('open', true);
                pl.options.set('iconLayout', templates_place[1]);
            }
        }
    });

    p.events.add('dragend', function (e) {
        var p = e.get('target'),
            c = p.geometry.getCoordinates(),
            adr = $('i[data-id=' + p.properties.get('id') + ']').parent();
        adr.find('input[name=lat]').val(c[0].toFixed(6));
        adr.find('input[name=lon]').val(c[1].toFixed(6));
    });

    manager.add(p);
    map.geoObjects.add(manager);
}

