function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
var csrftoken = getCookie('csrftoken');
function sameOrigin(url) {
    var host = document.location.host; // host + port
    var protocol = document.location.protocol;
    var sr_origin = '//' + host;
    var origin = protocol + sr_origin;
    return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
        (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') || !(/^(\/\/|http:|https:).*/.test(url));
}
function csrfSafeMethod(method) {
    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}
$.ajaxSetup({
    beforeSend: function (xhr, settings) {
        if (!csrfSafeMethod(settings.type) && sameOrigin(settings.url)) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        }
    }
});


function plural(i, s1, s3, s7) {
    s = String(i);
    e = s.slice(-2);
    f = parseInt(e);
    if (['11', '12', '13', '14'].indexOf(e) + 1 && (9 < f || f < 20 || f == 0)) {
        d = s7;
    }
    else {
        e = (s.slice(s.length - 1))[0];
        if (9 < i && i < 20 && i == 0) {
            d = s7;
        }
        else {
            if (e == '1') {
                d = s1;
            }
            else {
                if (['2', '3', '4'].indexOf(e) + 1) {
                    d = s3;
                }
                else {
                    d = s7;
                }
            }
        }
    }
    return d
}


function sendForm(options, form, onSuccess, onError, onErrorAjax) {
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(options),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                onSuccess ? onSuccess(data, form) : false;
            }
            else {
                onError ? onError(data, form) : false;
            }
        },
        error: function (data) {
            onErrorAjax ? onErrorAjax() : false;
        }
    });
}

$(function () {
    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name] !== undefined) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };


    $.fn.toggleDisabled = function () {
        return this.each(function () {
            this.disabled = !this.disabled;
        });
    };

    $.fn.toggleReadonly = function () {
        return this.each(function () {
            this.readOnly = !this.readOnly;
        });
    };

});

/**
 * @return {boolean}
 */
function CheckForm(form) {
    var status = true;
    form.find('.req input, input.req').each(function () {
        if (!$(this).val()) {
            status = false;
            $(this).addClass('error');
        }
        else $(this).removeClass('error');
    });
    if ($('[name=honey]').val()) status = false;
    var email = form.find('[type=email]');
    if (email.size()) {
        var valid = validateEmail(email.val());
        email.next().remove();
        if (!valid) {
            status = false;
            email.addClass('error');
            email.after('<div class="err">Неверный формат e-mail адреса</div>');
        }
        else {
            email.removeClass('error');

        }
    }
    return status;
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}


$(function () {
    $('.send-form').click(function (e) {
        e.preventDefault();
        var form = $(this).parents('form');
        var status = CheckForm(form);
        if ($('[name=honey]').val()) {
            status = false;
        }
        if (status) {
            form.find('.preloader').css('visibility', 'visible');
            $(this).css('visibility', 'hidden');
            sendForm(form.serializeObject(), form, successSend, errorSend);
        }
        return false;
    });
    $('.send-no-aj').click(function (e) {
        e.preventDefault();
        var form = $(this).parents('form');
        var status = CheckForm(form);
        if (status) {
            form.find('.preloader').css('visibility', 'visible');
            $(this).css('visibility', 'hidden');
            form.submit();
        }
        return false;
    });

    $('#delete-object').click(function (e) {
        e.preventDefault();
        var i = $('.edit-panel').data('id');
        var d = {
            action: $(this).data('action'),
            id: i
        };
        $('.list-items .item[data-id=' + i + ']').remove();
        closeEdit();
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON(d),
            dataType: 'json'
        });
    });


     $('.work-area').on('input change', '.change-input', function (e) {
        var id = $(this).parents('form').data('id');
        $('.item[data-id=' + id + '] .' + $(this).data('change') + ', .object[data-id=' + id + '] .' + $(this).data('change')).text($(this).val());
    });


     $('.work-area').on('change', '.change-account', function (e) {
        $(this).val($(this).val().replace(',', '.'));
        $('.change-account').each(function () {
            var e = $(this),
                d1 = ($(e.data('d1')).val().replace(/ /g, '')),
                d2 = ($(e.data('d2')).val().replace(/ /g, ''));
            if (!e.val() && d1 && d2) {
                d1 = parseFloat(d1);
                d2 = parseFloat(d2);
                if (e.data('a') == 'div') {
                    e.val(accounting.formatNumber(parseFloat(d1 / d2), 2, " ", "."));
                }
                else {
                    e.val(accounting.formatNumber(parseFloat(d1 * d2), 2, " ", "."));
                }
            }
            else {
                if (e.val()) {
                    e.val(accounting.formatNumber(parseFloat(e.val().replace(/ /g, '')), 2, " ", "."))
                }
            }
        });

        var id = $(this).parents('form').data('id');
        $('.item[data-id=' + id + '] .' + $(this).data('change') + ', .object[data-id=' + id + '] .' + $(this).data('change')).text($(this).val());
    });



});

function successSend(data, form) {
    form[0].reset();
    errorSend(data, form);
}
function errorSend(data, form) {
    form.find('button').css('visibility', 'visible');
    form.find('.preloader').css('visibility', 'hidden');

}


function showLoaderBase() {
    $('body').append('<div class="base-loader"><i class="fa fa-spinner fa-pulse"></i> Идет загрузка</div>');
}

function removeBaseLoader() {
    $('.base-loader').remove();
}


function addErrorInput(el) {
    el.before('<div class="message error ico">Ошибка заполнения</div>');
    el.addClass('error');
}

function addSuccessInput(el) {
    el.before('<div class="message success ico">Верно</div>');
    el.addClass('success');
}

function addErrorInputShort(el) {
    el.before('<div class="message error ico">&nbsp;</div>');
    el.addClass('error');
}

function addSuccessInputShort(el) {
    el.before('<div class="message success ico">&nbsp;</div>');
    el.addClass('success');
}

function removeMessageInput(el) {
    el.parent().find('.message').remove();
    el.removeClass('error').removeClass('success');
}

function testinput(re, str) {
    return (re.test(str));
}

function setAutoComplete(data_select) {
    for (var i = 0; i < data_select.length; i++) {
        $(data_select[i].id).autocomplete({
            source: data_select[i].data,
            minLength: 0,
            select: function (event, ui) {
                $(this).val(ui.item.value).trigger('change');
            }
        });
        $(data_select[i].id).focus(function () {
            $(this).autocomplete("search", "");
        });
    }
}

function setRelatedFields(d) {
    var p = '.form-item';
    for (var i = 0; i < d.length; i++) {

        var element = $(d[i].id),
            related = $(d[i].related),
            dict = d[i].data;


        if (!related.val() || dict[related.val()] == '') {
            //element.val('');
            element.parents(p).hide(0);
            element.parents(p).find('input').val('').trigger('change').trigger('input');
        }
        else {
            element.parents(p).show(0);
            element.parents(p).find('label:eq(0)').text(dict[related.val()]);
        }

        related.data('rel', d[i].id);

        related.change(function () {
            var el = $($(this).data('rel')),
                di = getDictRelated(data_related, $(this).data('rel'));
            if (!$(this).val() || di[$(this).val()] == '') {
                //el.val('');
                el.parents(p).hide(0);
                el.parents(p).find('input').val('').trigger('change').trigger('input');
            }
            else {
                el.parents(p).show(0);
                //el.val('');
                el.parents(p).find('input').val('').trigger('change').trigger('input');
                el.parents(p).find('label:eq(0)').text(di[$(this).val()]);
            }
        });

    }
}

function getDictRelated(d, r) {
    for (var i = 0; i < d.length; i++) {
        if (d[i].id == r) {
            return d[i].data;
        }
    }
    return undefined;
}

function findPlace(id) {
    var f;
    manager.each(function (e) {
        if (id == getPlaceId(e)) {
            f = e;
        }
    });
    return f;
}

function getPlaceId(p) {
    return p.properties.get('id');
}

function getClassName() {
    return $('#ClassName').val();
}

function getParametrUrl(val) {
    var result = false,
        tmp = [];
    location.search
    //.replace ( "?", "" )
    // this is better, there might be a question mark inside
    .substr(1)
        .split("&")
        .forEach(function (item) {
        tmp = item.split("=");
        if (tmp[0] === val) result = decodeURIComponent(tmp[1]);
    });
    return result;
}