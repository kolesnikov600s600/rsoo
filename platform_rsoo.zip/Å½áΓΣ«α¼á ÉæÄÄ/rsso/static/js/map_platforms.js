var map;
var manager;
var templates_place;
var objects;
function init_map() {
    map = new ymaps.Map('map', {
        center: [55.75396, 37.620393],
        zoom: 10,
        controls: []
    }, {
        mapAutoFocus: false
    });

    map.controls.add('zoomControl', {
        float: 'left',
        position: {
            bottom: 30,
            right: 10,
            left: 'auto'
        }
    });

    templates_place = [
        ymaps.templateLayoutFactory.createClass('<div class="placemark"></div>'),
        ymaps.templateLayoutFactory.createClass('<div class="placemark"><div class="t-map2">Перетащите объект, чтобы уточнить его местонахождение</div></div>')
    ];

	map.events.add('boundschange', function (event) {
		getPlatformList('', '', event.get('newBounds'));
	});
	map.setZoom(9);

}

function addObjectsMap(data, newpoint) {
	objects = [];
    var flags = true;
    for (var i = 0; i < data.length; i++) {

		var coords;
        if (typeof newpoint != 'undefined' && newpoint) {
            flags = false;
            coords = data[i]['place']
        }
        else {
            coords = data[i].geometry.coordinates;
        }

        var cc = [coords[0], coords[1]];

		var balloonContent = ymaps.templateLayoutFactory.createClass('<div class="balloon">$[[options.contentLayout observeSize minWidth=255 maxWidth=300 maxHeight=350]]<div class="arrow"></div><div class="close"></div></div>',
			{
				build: function () {
					this.constructor.superclass.build.call(this);
					this._$element = $('.balloon', this.getParentElement());
					this.applyElementOffset();
					this._$element.find('.close').on('click', $.proxy(this.onCloseClick, this));
				},
				clear: function () {
					this._$element.find('.close').off('click');

					this.constructor.superclass.clear.call(this);
				},
				onSublayoutSizeChange: function () {
					balloonContent.superclass.onSublayoutSizeChange.apply(this, arguments);

					if (!this._isElement(this._$element)) {
						return;
					}

					this.applyElementOffset();

					this.events.fire('shapechange');
				},
				applyElementOffset: function () {
					this._$element.css({
						left: -43,
						top: -(this._$element[0].offsetHeight + 10)
					});
				},
				onCloseClick: function (e) {
					e.preventDefault();

					this.events.fire('userclose');
				},
				getShape: function () {
					if (!this._isElement(this._$element)) {
						return balloonContent.superclass.getShape.call(this);
					}

					var position = this._$element.position();

					return new ymaps.shape.Rectangle(new ymaps.geometry.pixel.Rectangle([
						[position.left, position.top], [
							position.left + this._$element[0].offsetWidth,
							position.top + this._$element[0].offsetHeight + this._$element.find('.arrow')[0].offsetHeight
						]
					]));
				},
				_isElement: function (element) {
					return element && element[0] && element.find('.arrow')[0];
				}

			}
		);

		var contentLayout = ymaps.templateLayoutFactory.createClass(
			'<div class="shop">$[properties.balloonContent]</div>'
		);
		objects[i] = new ymaps.Placemark(
			cc,
			{
				id: flags ? data[i].id : data[i]['id'],
				clusterCaption: flags ? data[i].name : data[i]['name'],
				hintContent: flags ? data[i].name : data[i]['name']

			},
			{
				iconLayout: templates_place[0],
				draggable: false,
				openEmptyBalloon: true,
				iconShape: {
					type: 'Circle',
					coordinates: [0, 0],
					radius: 12
				},
				openHintOnHover: true,
				hideIconOnBalloonOpen: false,
				balloonPanelMaxMapArea: 0,
				balloonAutoPan: false,
				zIndexDrag: 1000,
				zIndexHover: 1000
			}
		);

		objects[i].events.add('click', function (e) {
			var objectId = getPlaceId(e.get('target'));
			$('.list-items .item[data-id=' + objectId + ']').click();
		});
		objects[i].events.add('mouseenter', function (e) {
			var objectId = getPlaceId(e.get('target'));
			var p = findPlacePl(objectId);
			if (!p.balloon.isOpen()) {
                 p.balloon.open();
            }
        });
		objects[i].events.add('mouseleave', function (e) {
			var objectId = getPlaceId(e.get('target'));
			var p = findPlacePl(objectId);
			if (p.balloon.isOpen()) {
                 p.balloon.close();
            }
		});
		objects[i].events.add('dragend', function (e) {
			var p = e.get('target'),
				c = p.geometry.getCoordinates(),
				i = getPlaceId(p);
			console.log(c[0]);
			console.log(c[0].toFixed(6).replace('.',','));
				$('#id_lat').val(c[0].toFixed(6));
				$('#id_lon').val(c[1].toFixed(6));

		});
		objects[i].events.add('balloonopen', function (e) {
			var p = e.get('target');
			getPrompt(getPlaceId(p), p);

		});
		
    }
	manager = new ymaps.Clusterer({
		preset: 'islands#darkGreenClusterIcons',
		gridSize: 128,
		minClusterSize: 3
	});
	manager.removeAll();
    manager.add(objects);
    map.geoObjects.add(manager);

}
