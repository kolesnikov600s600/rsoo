var map;
var map_objects;
var manager;
var templates_place;
function init_map() {
    map = new ymaps.Map('map', {
        center: [55.75396, 37.620393],
        zoom: 10,
        controls: []

    });

    map.controls.add('zoomControl', {
        float: 'left',
        position: {
            bottom: 30,
            right: 10,
            left: 'auto'
        }
    });

     templates_place = [
        ymaps.templateLayoutFactory.createClass('<div class="placemark"></div><div class="place-text">{{ properties.iconContent }}</div>'),
        ymaps.templateLayoutFactory.createClass('<div class="placemark"><div class="t-map">Перетащите объект, чтобы уточнить его местонахождение</div></div><div class="place-text">{{ properties.iconContent }}</div>')
    ];

    manager = new ymaps.GeoObjectCollection();
    getList();


}

function addObjectsMap(data) {

    for (var i = 0; i < data.length; i++) {
        var cc = [data[i].place[0], data[i].place[1]];
        managerAdd(data[i], cc);
    }

}

function managerAdd(el, c) {


    var placeIco = templates_place[0];
    var p_options = {
        iconLayout: placeIco,
        draggable: false,
        iconShape: {
            type: 'Circle',
            coordinates: [0, 0],
            radius: 12
        },

        openHintOnHover: true,
        hideIconOnBalloonOpen: false,

        balloonPanelMaxMapArea: 0,
        zIndexDrag: 1000,
        zIndexHover: 1000

    };



    var p = new ymaps.Placemark(
        {
            type: "Point",
            coordinates: c
        },
        {
            id: el.id,
            iconContent: el.name

        },
        p_options
    );

    p.events.add('click', function (e) {
        var objectId = getPlaceId(e.get('target'));
        $('.list-items .item[data-id=' + objectId + ']').click();
    });

    p.events.add('dragend', function (e) {
        var p = e.get('target'),
            c = p.geometry.getCoordinates(),
            i = getPlaceId(p);
            $('#id_lat').val(c[0].toFixed(6));
            $('#id_lon').val(c[1].toFixed(6));
    });

    manager.add(p);

    map.geoObjects.add(manager);
}

