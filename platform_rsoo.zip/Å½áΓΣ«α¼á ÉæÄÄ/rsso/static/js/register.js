/**
 * Created by Ivan on 29.02.2016.
 */

$(function(){
    $('#id_category').styler();

    $('#id_category').change(function(e){
        if (!($.inArray($(this).val(),['6','4'])+1)) {
            $('.input-block').hide(0);
            $('.no-open').show(0);
        }
        else {
            if ($(this).val() == '6') {
            location.pathname = '/registration/micro/';
                }
            $('.input-block').show(0);
            $('.no-open').hide(0);
        }
    });

    $("#id_name").suggestions({
        serviceUrl: "https://dadata.ru/api/v2",
        token: "355f93ce71c996490531a51e9b6d924a54399dd4",
        type: "PARTY",
        hint: 'Организация не найдена, добавьте новую или продолжите ввод',
        count: 5,
        width: 400,
        onSelect: function (suggestion) {
            var director = '';
            if (suggestion.data.type == 'INDIVIDUAL') {
                director = suggestion.data.name.full
            }
            else {
                if (suggestion.data.management) {
                    director = suggestion.data.management.name;
                }
            }
            $('#id_fio').val(director);
            $('#id_inn').val(suggestion.data.inn);
            $('#id_ogrn').val(suggestion.data.ogrn);
            $('#id_kpp').val(suggestion.data.kpp);
            $('#id_okved').val(suggestion.data.okved).change();
            $('#id_address').val(suggestion.data.address.value);
        }
    });

    $('input[name=phone]').mask('+7 (999) 999-99-99');



});


function fetchFromObject(obj, prop) {

    if(typeof obj === 'undefined') {
        return false;
    }

    var _index = prop.indexOf('.');
    if(_index > -1) {
        return fetchFromObject(obj[prop.substring(0, _index)], prop.substr(_index + 1));
    }

    return obj[prop];
}