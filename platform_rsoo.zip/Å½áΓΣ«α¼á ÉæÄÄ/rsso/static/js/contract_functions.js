function getList(page, search) {
    if (search !== undefined) {
        if ($('#id_search').val().length > 0) {
            search = $('#id_search').val();
        }
    }

    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_objects_list',
                'page': page,
                'class': getClassName(),
                'search': search
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                $('.list-items .loader').remove();
                $('.list-items').append(data['html']);
                $('.t-item:not(.tooltipstered)').tooltipster({theme: 'tooltipster-yellow', contentAsHTML: true});
            }

        }
    });

}


function changeEditPanel(data) {
    $('.edit-panel').remove();
    removeBaseLoader();
    $('.left-panel').after(data);
    $(".edit-panel").trigger('loadData');
}

function createBlankItem(d) {
    $('.list-items .item[data-id=new]').remove();
    $('.list-items').prepend('<div class="item transport active" data-id="new"><div class="name"><strong>Новый договор</strong></div></div>')
}


function getObjectEditForm(id) {
    showLoaderBase();
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'get_edit_object_form',
                'id': id,
                'class': getClassName()
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
                var id = parseInt($('.edit-panel').data('id'));
                manager.each(function (e) {
                    if ($.inArray(id, e.properties.get('contracts')) > -1) {
                        e.options.set('iconLayout', templates_place[1]);
                        e.properties.set('open', true);
                    }
                    else {
                        e.options.set('iconLayout', templates_place[0]);
                    }


                });
                $('.list-items .item[data-id=' + getParametrUrl('contract') + ']').addClass('active');


            }

        }
    });
}

function closeEdit(id) {
    var a = $('.list-items .item.active');

    if (a.data('id') == 'new') {
        a.remove();
    }
    a.removeClass('active');
    $('.edit-panel').remove();
    var delp = [];
    manager.each(function (e) {
        var id_arr = e.properties.get('id', true).split('-');
        if (id_arr[0] != 'new') {
            if (e.properties.get('contracts').length > 0) {
                e.options.set('iconLayout', templates_place[1]);
            }
            else {
                e.options.set('iconLayout', templates_place[0]);
            }
            e.properties.set('open', false);
        }
        else {
            delp.push(e);
             //manager.remove(e);
        }



    });
    $.each(delp, function(i, el){
        manager.remove(el);
        });


}

function getCreateObjectForm(d) {
    showLoaderBase();
    createBlankItem(d);
    d['action'] = 'get_create_object_form';
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(d),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                changeEditPanel(data['html']);
                manager.each(function (e) {
                    if (!e.properties.get('open')) {
                        e.options.set('iconLayout', templates_place[0]);
                        e.properties.set('open', false);
                    }
                    else {
                        e.options.set('iconLayout', templates_place[1]);

                        var id_arr = e.properties.get('id', true).split('-');

                        var html = '<input type="hidden" value="' + id_arr[1] + '" id="id_' + id_arr[0] + '_' + id_arr[1] + '" name="' + id_arr[0] + '">';
                        $('#' + id_arr[0] + '-input').append(html);

                        html = '<div class="address"><input readonly value="' + e.properties.get('address') + '" id="id_blank_' + id_arr[0] + '_' + id_arr[1] + '" type="text"/><i data-id="' + e.properties.get('id') + '" class="fa fa-remove"></i></div>';
                        $('#result-address label').after(html);

                    }


                });
            }

        }
    });
}


function clearItemList() {
    $('.list-items').html('<div class="loader post"><i class="fa fa-spinner fa-pulse"></i></div>');
}


function saveObject() {
    showLoaderBase();
    if ($('.edit-panel').data('id') == 'new') {
        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                form: $('.create-object').serializeObject(),
                id: $('.edit-panel').data('id'),
                class: getClassName(),
                action: 'create_object'
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {

                    manager.each(function (e) {
                        var id_arr = e.properties.get('id', true).split('-');
                        var i = parseInt(data['id']);
                        var ch = $.inArray(i, e.properties.get('contracts'));
                        var sel = '#id_' + id_arr[0] + '_' + id_arr[1];
                        var ar = e.properties.get('contracts');
                        if (id_arr[0] != 'new') {
                            if ($(sel).size() > 0) {
                                if (ch == -1) {
                                    ar.push(i);
                                    e.properties.set('contracts', ar)
                                }
                            }
                            else {
                                if (ch > -1) {
                                    var pos = ar.indexOf(i);
                                    ar.splice(pos, 1);
                                    e.properties.set('contracts', ar);
                                }
                            }
                        }


                    });

                    $('.list-items .item[data-id=new]').replaceWith(data['html']);

                    removeBaseLoader();
                    closeEdit();
                    if (typeof data['points'] != 'undefined' ) {
                    addObjectsMap(data['points']);
                        }
                }
            }
        });
    }
    else {

        manager.each(function (e) {
            var id_arr = e.properties.get('id', true).split('-');
            var i = parseInt($('.edit-panel').data('id'));
            var ch = $.inArray(i, e.properties.get('contracts'));
            var sel = '#id_' + id_arr[0] + '_' + id_arr[1];
            var ar = e.properties.get('contracts');
            if ($(sel).size() > 0) {
                if (ch == -1) {
                    ar.push(i);
                    e.properties.set('contracts', ar)
                }
            }
            else {
                if (ch > -1) {
                    var pos = ar.indexOf(i);
                    ar.splice(pos, 1);
                    e.properties.set('contracts', ar);
                }
            }


        });

        $.ajax({
            type: "POST",
            url: '/ajax/',
            contentType: 'application/json; charset=utf-8',
            data: $.toJSON({
                form: $('.edit-object').serializeObject(),
                id: $('.edit-panel').data('id'),
                class: getClassName(),
                action: 'save_object'
            }),
            dataType: 'json',
            success: function (data) {
                if (data['success']) {

                    $('.left-panel .item[data-id=' + data['id'] + ']').replaceWith(data['html']);
                    removeBaseLoader();
                    closeEdit();
                    if (typeof data['points'] != 'undefined' ) {
                        addObjectsMap(data['points']);
                    }

                }
            }
        });


    }
}


function deleteObject(classname, id) {
    showLoaderBase();

    manager.each(function (e) {
        var i = parseInt(id);
        var ar = e.properties.get('contracts');
        var ch = $.inArray(i, ar);
        if (ch > -1) {
            var pos = ar.indexOf(i);
            ar.splice(pos, 1);
            e.properties.set('contracts', ar);
        }
    });


    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'delete_object',
                'id': id,
                'class': classname
            }
        ),
        dataType: 'json',
        success: function (data) {
            if (data['success']) {
                removeBaseLoader();
                closeEdit();
                $('.list-items .item[data-id=' + data['id'] + ']').remove();

            }

        }
    });
}

function deleteFile(classname, id) {
    $.ajax({
        type: "POST",
        url: '/ajax/',
        contentType: 'application/json; charset=utf-8',
        data: $.toJSON(
            {
                'action': 'delete_object',
                'id': id,
                'class': classname
            }
        )
    });
}

