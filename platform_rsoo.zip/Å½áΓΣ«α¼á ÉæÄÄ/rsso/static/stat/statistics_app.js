//отрисовка табов//
tab = function() {
  var numTabs = $('.background').length;
  //alert(numTabs);
  var pageArray = [];
  var currentState;

  function Page(zIndex, id) { //each page object has three positions and is attached to a html element.
    this.positionLeft = zIndex * 5;
    this.positionMiddle = (zIndex / numTabs) * 100;
    this.positionRight = 100 - ((numTabs - zIndex) * 5);
    this.pageId = document.getElementById(id);
  }

  $('.background').each(function() { //building the pages objects & setting the page start-up position
    var zIndex = $(this).css('z-index');
    var id = this.id;
    pageArray[zIndex] = new Page(zIndex, id);
    var percent = (zIndex / numTabs) * 100;
    $(this).css('left', percent + '%');
    //console.log(pageArray[zIndex]);
  });
    
  $('.background').click(function() { //click event, checks what page was selected and changes appropriate positions
    var currentPage = $(this).css('z-index');
    if (currentPage != currentState) {
      for (var i =0; i < numTabs; i++) {
        if (currentPage >= i) {
          //console.log(pageArray[i].pageId)
          $(pageArray[i].pageId).animate({
            left: pageArray[i].positionLeft + '%'
          }, 825);
        } else {
          $(pageArray[i].pageId).animate({
            left: pageArray[i].positionRight + '%'
          }, 825);
        }
      }
      currentState = currentPage;
    } else {
      for (var i = 0; i < numTabs; i++) {
        $(pageArray[i].pageId).animate({
          left: pageArray[i].positionrigth + '%'
        }, 825);
        currentState = null;
      }
    }
  });
    $('.background').ready(function() { //click event, checks what page was selected and changes appropriate positions
    var currentPage = 0;
    if (currentPage != currentState) {
      for (var i =0; i < numTabs; i++) {
        if (currentPage >= i) {
          //console.log(pageArray[i].pageId)
          $(pageArray[i].pageId).animate({
            left: pageArray[i].positionLeft + '%'
          }, 825);
        } else {
          $(pageArray[i].pageId).animate({
            left: pageArray[i].positionRight + '%'
          }, 825);
        }
      }
      currentState = currentPage;
    } else {
      for (var i = 0; i < numTabs; i++) {
        $(pageArray[i].pageId).animate({
          left: pageArray[i].positionrigth + '%'
        }, 825);
        currentState = null;
      }
    }
  });
    
};
//$('.background').ready

$(document).ready(tab);
//отрисовка табов --------------/


//Для выравнивания табов со статистикой
$(document).ready(function() {
   
    show_charts0();
    
    setTimeout(function() {
        var mainDivs = $(".background");
        var maxHeight = 0;
        for (var i = 0; i < mainDivs.length; ++i) {
            if (maxHeight < $(mainDivs[i]).height()) {
                maxHeight = $(mainDivs[i]).height();
            }
        }
        for (var i = 0; i < mainDivs.length; ++i) {
            $(mainDivs[i]).height(maxHeight);
        }
    }, 1000);
    
 //Отрисовка графиков
$( "#clickzone0" ).click( function() {
     $("#statistics_tab0").hide();
     show_charts0();
});
$( "#clickzone1" ).click( function() {
    //$("#statistics_tab1").hide();
     show_charts1();
});
$( "#clickzone2" ).click( function() {
     $("#statistics_tab2").hide();
     show_charts2();
});

    
});
//datepicker
$(function() {
           $( "#datepicker0" ).datepicker();
         });
         $(function() {
           $( "#datepicker1" ).datepicker();
         });
        $(function() {
           $( "#datepicker2" ).datepicker();
         });
         $(function() {
           $( "#datepicker3" ).datepicker();
         });
        $(function() {
           $( "#datepicker4" ).datepicker();
         });
         $(function() {
           $( "#datepicker5" ).datepicker();
         });
        $(function() {
           $( "#datepicker6" ).datepicker();
         });
         $(function() {
           $( "#datepicker7" ).datepicker();
         });
        $(function() {
           $( "#datepicker8" ).datepicker();
         });
         $(function() {
           $( "#datepicker9" ).datepicker();
         });

//Граффики
var show_charts0 = function() {
        //JSON сюда
        

    
        var theme = ["theme2","theme3","theme4"];
        var stat_label_final = [];
        var stat_value_final =[];
       
        $.ajax({
            url: "/ajax/",
            dataType: "json",
            data: {
                action: 'get_stat',
                date_from: '01.02.16',
                date_to: '30.04.16'
            },
            beforeSend: function() {
                $("#create_loader").append(" <div id='loader'  style=' margin-left: 500px; margin-top: 200px;'></div> ");
                $("#loader").radialProgress("init", {'size': 300,'fill': 15}).radialProgress("to", {'perc': 100, 'time': 4000}); 
               
            },
            complete: function() {
               
                $("#loader").remove();
              
                $("#statistics_tab0").show();
               
            } ,
            success: function (data) { 
     
        var stat_label = []; //контейнеры хранения значений с бд
        var stat_value = [];
        
        for(var i=0; i<8; i++)  { //кол-во организаций-компаний в файле(статичный параметр)         
           
            stat_label.push(data.stat[i].name);
            stat_value.push(data.stat[i].total);
          
       } 
        var stat_0_date_value = [];
        var stat_1_date_value = [];
        var stat_2_date_value = [];
        var stat_3_date_value = [];
        var stat_4_date_value = [];
        var stat_5_date_value = [];
        var stat_6_date_value = [];
        var stat_7_date_value = [];
        
    
         //загрузка статистики по дням в массивы
                //изменить счетчик i на количество элементов,пока используем статическое значение
        for(var i=0; i<90; i++)  {
           
            stat_0_date_value.push(data.stat[0].days[i]);
            stat_1_date_value.push(data.stat[1].days[i]);
            stat_2_date_value.push(data.stat[2].days[i]);
            stat_3_date_value.push(data.stat[3].days[i]);
            stat_4_date_value.push(data.stat[4].days[i]);
            stat_5_date_value.push(data.stat[5].days[i]);
            stat_6_date_value.push(data.stat[6].days[i]);
            stat_7_date_value.push(data.stat[7].days[i]);
            
        } 
      
        
        
                
                //!!!!! НАИМЕНОВАНИЯ
        //полные наименования категорий ,получаемые с БД
        stat_label_final[0] = stat_label[0];//Администрация муниципального образования
        stat_label_final[1] = stat_label[1];//Профильный орган власти
        stat_label_final[2] = stat_label[2];//Управляющая компания  
        stat_label_final[3] = stat_label[3];//Транспортная компания
        stat_label_final[4] = stat_label[4];//Пункт выгрузки отходов  
        stat_label_final[5] = stat_label[5];//Организация-отходообразователь  
        stat_label_final[6] = stat_label[6];//Прочее
        stat_label_final[7] = stat_label[7];//Микропредприятие  
        
        //краткие наименования категорий 
        short_label_0 = "ОМСУ";
        short_label_1 = "ОГВ";
        short_label_2 = "УК";
        short_label_3 = "ТК";
        short_label_4 = "ОИ";
        short_label_5 = "ОО";
        short_label_6 = "МП";   
        short_label_7 = "ПР";
        
                //!!!!! ДАННЫЕ
        //сумма данных за весь период выборки ,период выборки указывается в AJAX/разнести полную выборку и выборку datepicker!!!***
        stat_value_final[0] = stat_value[0];
        stat_value_final[1] = stat_value[1];
        stat_value_final[2] = stat_value[2];
        stat_value_final[3] = stat_value[3];
        stat_value_final[4] = stat_value[4];
        stat_value_final[5] = stat_value[5];
        stat_value_final[6] = stat_value[6];
        stat_value_final[7] = stat_value[7];
        
        //выборка данных за период времени
         //обработка элементов массива
      
                
       
        //Range графика
        var max = getMaxValue(stat_value);
        var min = getMinValue(stat_value);


                function getMaxValue(array){
                    var max = stat_value[0];
                        for (var i = 0; i < stat_value.length; i++) { 
                                if (max < stat_value[i]) max = stat_value[i]; 
                            }
                            return max;
                    }
                function getMinValue(stat_value){
    var min = stat_value[0];
    for (var i = 0; i < stat_value.length; i++) {
        if (min > stat_value[i]) min = stat_value[i];
    }
    return min;
}
                
                
        var maxrange = max+((max/100)*15);
        var minrange = min;         
     
        ////1 гистограмма             
        ////1 гистограмма             
        var chart0 = new CanvasJS.Chart("chartContainer02", {
            animationEnabled: true,
            zoomEnabled:true,
            title:{
                text: "Распределение данных по источникам",
                fontSize: 22,
                fontWeight: "bold",
                fontFamily: "calibri"
            },
            theme: theme[3],
            data: [{
                type: "column", 
                dataPoints: [{
                    label: short_label_0,
                    y: stat_value_final[0]*1
                }, {
                    label: short_label_1,
                    y: stat_value_final[1]*1
                }, {
                    label:short_label_2,
                    y: stat_value_final[2]*1
                }, {
                    label: short_label_3,
                    y: stat_value_final[3]*1
                }, {
                    label: short_label_4,
                    y: stat_value_final[4]*1
                }, {
                    label: short_label_5,
                    y: stat_value_final[5]*1
                }, {
                    label: short_label_6,
                    y: stat_value_final[6]*1
                }, {
                    label: short_label_7,
                    y: stat_value_final[7]*1
                }]
            }]
        });
        chart0.render();
        ////1 гистограмма
        
       
        ////2 график
        var chart1 = new CanvasJS.Chart("chartContainer01", {
            zoomEnabled: true,
             title:{
                text: "Динамика подачи сведений",
                fontSize: 22,
                fontWeight: "bold",
                fontFamily: "calibri"
            },
            animationEnabled: true,
            axisY2: {
                valueFormatString: "0",
//                maximum: maxrange,
                maximum: 1000,
                minimum: minrange,
//                interval: (maxrange/100)*10,
                interval: 10,
                interlacedColor: "#F5F5F5",
               // gridColor: "#D7D7D7",
               // tickColor: "#D7D7D7"
            },
            theme:  theme[3],
            toolTip: {
                shared: true
            },
            legend: {
                verticalAlign: "bottom",
                horizontalAlign: "center",
                fontSize: 15,
                fontFamily: "calibri"
            },
            data: [],
            legend: {
                verticalAlign: "top",
                horizontalAlign: "left",
                fontSize: 20,
                cursor: "pointer",
                itemclick: function(e) {
                    if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                        e.dataSeries.visible = false;
                    } else {
                        e.dataSeries.visible = true;
                    }
                    chart1.render();
                }
            }
        });
        ///!!! Обработчик данных массивов!!!
                //хранилища данных по статистике за определенный период!!!
       var stat_0_package = [];   
       var stat_1_package = []; 
       var stat_2_package = [];   
       var stat_3_package = []; 
       var stat_4_package = [];   
       var stat_5_package = [];         
       var stat_6_package = [];   
       var stat_7_package = []; 
       //обработчик массивов ,значение keys является ключевым и его необходимо обнулять и пересоздавать каждый цикл for!!!
                //stat 0
       var keys = Object.keys( stat_0_date_value );
       for (var i = 0; i < keys.length; i++) {
           var date_from_stat_0 = Object.keys(stat_0_date_value[i]);
           var values_from_stat_0 = stat_0_date_value[i][date_from_stat_0];
                stat_0_package.push( { label:date_from_stat_0 , x: i, y: values_from_stat_0  } );
        }  
        keys= null;    
        //--------
                //stat 1
       var keys = Object.keys( stat_1_date_value );
       for (var i = 0; i < keys.length; i++) {
           var date_from_stat_1 = Object.keys(stat_1_date_value[i]);
           var values_from_stat_1 = stat_1_date_value[i][date_from_stat_1];
                stat_1_package.push( { x: i, y: values_from_stat_1} );
        } 
        keys= null; 
        //-----------
                //stat 2
        var keys = Object.keys( stat_2_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_2 = Object.keys(stat_2_date_value[i]);
           var values_from_stat_2 = stat_2_date_value[i][date_from_stat_2];
                stat_2_package.push( { x: i, y: values_from_stat_2} );
                    
                } 
        keys= null;         
        //----------
                //stat 3
        var keys = Object.keys( stat_3_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_3 = Object.keys(stat_3_date_value[i]);
           var values_from_stat_3 = stat_3_date_value[i][date_from_stat_3];
                stat_3_package.push( { x: i, y: values_from_stat_3} );
        } 
        keys= null;         
        //---------    
                //stat 4
        var keys = Object.keys( stat_4_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_4 = Object.keys(stat_4_date_value[i]);
           var values_from_stat_4 = stat_4_date_value[i][date_from_stat_4];
                stat_4_package.push( { x: i, y: values_from_stat_4} );
        } 
        keys= null;         
        //---------       
                //stat 5
        var keys = Object.keys( stat_5_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_5 = Object.keys(stat_5_date_value[i]);
           var values_from_stat_5 = stat_5_date_value[i][date_from_stat_5];
                stat_5_package.push( { x: i, y: values_from_stat_5} );
        } 
        keys= null;         
        //---------       
                 //stat 6
        var keys = Object.keys( stat_6_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_6 = Object.keys(stat_6_date_value[i]);
           var values_from_stat_6 = stat_6_date_value[i][date_from_stat_6];
                stat_6_package.push( { x: i, y: values_from_stat_6} );
        } 
        keys= null;         
        //--------- 
                //stat 7
        var keys = Object.keys( stat_7_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_7 = Object.keys(stat_7_date_value[i]);
           var values_from_stat_7 = stat_7_date_value[i][date_from_stat_7];
                stat_7_package.push( { x: i, y: values_from_stat_7} );
        } 
        keys= null;         
        //---------       
        var newSeries_0 = { type:"area",name:stat_label_final[0], dataPoints: stat_0_package };
        var newSeries_1 = { type:"area",name:stat_label_final[1], dataPoints: stat_1_package };
        var newSeries_2 = { type:"area",name:stat_label_final[2], dataPoints: stat_2_package };
        var newSeries_3 = { type:"area",name:stat_label_final[3], dataPoints: stat_3_package };
        var newSeries_4 = { type:"area",name:stat_label_final[4], dataPoints: stat_4_package };
        var newSeries_5 = { type:"area",name:stat_label_final[5], dataPoints: stat_5_package };
        var newSeries_6 = { type:"area",name:stat_label_final[6], dataPoints: stat_6_package };
        var newSeries_7 = { type:"area",name:stat_label_final[7], dataPoints: stat_7_package };
        
        chart1.options.data.push(newSeries_0);
        chart1.options.data.push(newSeries_1);
        chart1.options.data.push(newSeries_2);
        chart1.options.data.push(newSeries_3);
        chart1.options.data.push(newSeries_4);
        chart1.options.data.push(newSeries_5);
        chart1.options.data.push(newSeries_6);
        chart1.options.data.push(newSeries_7);
            
        chart1.render();
        ////2 график
       
       ////3 бублик 
        var chart2 = new CanvasJS.Chart("chartContainer03", {
            title: {
                text: "Соотношение поданных сведений",
               fontSize: 22,
               fontWeight: "bold",
               fontFamily: "calibri"
            },
            theme:  theme[3],
            animationEnabled: true,
            data: [{
                type: "doughnut",
                startAngle: 20,
                innerRadius:"35%",
                indexLabelLineThickness: 3,
                indexLabelFontFamily: "Calibri",
                indexLabelFontWeight: "normal",
                indexLabelLineColor:"#0d81a7",
                indexLabelFontSize: 18,
                dataPoints: [{
                    y: stat_value_final[0]*1,
                    label: short_label_0
                }, {
                    y: stat_value_final[1]*1,
                    label: short_label_1
                }, {
                    y: stat_value_final[2]*1,
                    label: short_label_2
                }, {
                    y: stat_value_final[3]*1,
                    label: short_label_3
                }, {
                    y: stat_value_final[4]*1,
                    label: short_label_4
                }, {
                    y: stat_value_final[5]*1,
                    label: short_label_5
                }, {
                    y: stat_value_final[6]*1,
                    label: short_label_6
                },{
                    y: stat_value_final[7]*1,
                    label: short_label_7
                }
                ]
            }]
        });
        chart2.render();
        ////3 бублик
            
            
            
       }
         });
};
var show_charts1 = function() {
    
    var organization_category = ["Водоканалы","АИС 'ГЖИ' МО ","Транспортировщики","МосОблГаз","ОМСУ","Генеральные схемы санитарной очистки","Пеший обход","Портал открытых данных МО","Кадастр отходов МО","Региональный оператор капитального ремонта МО","Поставщики тепла","Открытые данные (yandex,google) ","Мосэнергосбыт","Медицинские отходы","Промышленные отходы","Отходы строительства и сноса"]; //16 позиций,где 17 ?
    
    var organization_array = [{ y: 0 ,label: organization_category[0] },
            { y: 0 ,
              label: organization_category[1]
            },
            { y: 0 ,
              label: organization_category[2]
            },
            { y: 17000 ,
              label: organization_category[3]
            },
            { y: 4000 ,
              label: organization_category[4]
            },
            { y: 0 ,
              label: organization_category[5]
            },
            { y: 0 ,
              label: organization_category[6]
            },
            { y: 40000 ,
              label: organization_category[7]
            },
            { y: 0 ,
              label: organization_category[8]
            },
            { y: 0 ,
              label: organization_category[9]
            },
            { y: 0 ,
              label: organization_category[10]
            },
            { y: 245000 ,
              label: organization_category[11]
            },
            { y: 75000 ,
              label: organization_category[12]
            },
            { y: 0 ,
              label: organization_category[13]
            },
            { y: 0 ,
              label: organization_category[14]
            },
            { y: 0 ,
              label: organization_category[15]
            }
            ];
    
    
     ////1 гистограмма             
        var chart_histogram_organisations = new CanvasJS.Chart("chartContainer04", {
            animationEnabled: true,
            axisX:{
                labelAngle: 50,
                labelFontSize: 12,
                labelAutoFit: true,
                labelMaxWidth: 200,
                labelWrap: true,   // change it to false
			    interval: 0
            },
            axisY:{
            labelFontSize: 14
            },
            title:{
                text: "Распределение данных по источникам",
                fontSize: 22,
                fontWeight: "bold",
                fontFamily: "calibri"
            },
            data: [{
                type: "column", 
                indexLabelMaxWidth: 500,
                indexLabelFontFamily: "Calibri",
                indexLabelFontWeight: "normal",
                indexLabelLineColor:"#0d81a7",
                indexLabelFontSize: 10,
                dataPoints: organization_array
                }]
        });
        chart_histogram_organisations.render();
        ////1 гистограмма
 
    };
var show_charts2 = function() {
       //JSON сюда
        
        var theme = ["theme2","theme3","theme4"];
        var stat_label_final = [];
        var stat_value_final =[];
       
        $.ajax({
            url: "/ajax/",
            dataType: "json",
            data: {
                action: 'get_stat',
                date_from: '01.02.16',
                date_to: '30.04.16',
                class:'Platforms'
            },
             beforeSend: function() {
                $("#create_loader2").append(" <div id='loader2'  style=' margin-left: 500px; margin-top: 200px;'></div> ");
                $("#loader2").radialProgress("init", {'size': 300,'fill': 15}).radialProgress("to", {'perc': 100, 'time': 4000}); 
               
            },
            complete: function() {
               
                $("#loader2").remove();
              
                $("#statistics_tab2").show();
               
            } ,
            success: function (data) { 
     
        var stat_label = []; //контейнеры хранения значений с бд
        var stat_value = [];
        
        for(var i=0; i<8; i++)  { //кол-во организаций-компаний в файле(статичный параметр)         
           
            stat_label.push(data.stat[i].name);
            stat_value.push(data.stat[i].total);
          
       } 
        var stat_0_date_value = [];
        var stat_1_date_value = [];
        var stat_2_date_value = [];
        var stat_3_date_value = [];
        var stat_4_date_value = [];
        var stat_5_date_value = [];
        var stat_6_date_value = [];
        var stat_7_date_value = [];
        
    
         //загрузка статистики по дням в массивы
                //изменить счетчик i на количество элементов,пока используем статическое значение
        for(var i=0; i<90; i++)  {
           
            stat_0_date_value.push(data.stat[0].days[i]);
            stat_1_date_value.push(data.stat[1].days[i]);
            stat_2_date_value.push(data.stat[2].days[i]);
            stat_3_date_value.push(data.stat[3].days[i]);
            stat_4_date_value.push(data.stat[4].days[i]);
            stat_5_date_value.push(data.stat[5].days[i]);
            stat_6_date_value.push(data.stat[6].days[i]);
            stat_7_date_value.push(data.stat[7].days[i]);
            
        } 
      
        
        
                
                //!!!!! НАИМЕНОВАНИЯ
        //полные наименования категорий ,получаемые с БД
        stat_label_final[0] = stat_label[0];//Администрация муниципального образования
        stat_label_final[1] = stat_label[1];//Профильный орган власти
        stat_label_final[2] = stat_label[2];//Управляющая компания  
        stat_label_final[3] = stat_label[3];//Транспортная компания
        stat_label_final[4] = stat_label[4];//Пункт выгрузки отходов  
        stat_label_final[5] = stat_label[5];//Организация-отходообразователь  
        stat_label_final[6] = stat_label[6];//Прочее
        stat_label_final[7] = stat_label[7];//Микропредприятие  
        
        //краткие наименования категорий 
        short_label_0 = "ОМСУ";
        short_label_1 = "ОГВ";
        short_label_2 = "УК";
        short_label_3 = "ТК";
        short_label_4 = "ОИ";
        short_label_5 = "ОО";
        short_label_6 = "МП";   
        short_label_7 = "ПР";
        
                //!!!!! ДАННЫЕ
        //сумма данных за весь период выборки ,период выборки указывается в AJAX/разнести полную выборку и выборку datepicker!!!***
        stat_value_final[0] = stat_value[0];
        stat_value_final[1] = stat_value[1];
        stat_value_final[2] = stat_value[2];
        stat_value_final[3] = stat_value[3];
        stat_value_final[4] = stat_value[4];
        stat_value_final[5] = stat_value[5];
        stat_value_final[6] = stat_value[6];
        stat_value_final[7] = stat_value[7];
        
        //выборка данных за период времени
         //обработка элементов массива
      
                
       
        //Range графика
        var max = getMaxValue(stat_value);
        var min = getMinValue(stat_value);


                function getMaxValue(array){
                    var max = stat_value[0];
                        for (var i = 0; i < stat_value.length; i++) { 
                                if (max < stat_value[i]) max = stat_value[i]; 
                            }
                            return max;
                    }
                function getMinValue(stat_value){
    var min = stat_value[0];
    for (var i = 0; i < stat_value.length; i++) {
        if (min > stat_value[i]) min = stat_value[i];
    }
    return min;
}
                
                
        var maxrange = max+((max/100)*15);
        var minrange = min;         
     
        ////1 гистограмма             
        ////1 гистограмма             
        var chart0 = new CanvasJS.Chart("chartContainer08", {
            animationEnabled: true,
            zoomEnabled:true,
            title:{
                text: "Распределение данных по источникам",
                fontSize: 22,
                fontWeight: "bold",
                fontFamily: "calibri"
            },
            theme: theme[3],
            data: [{
                type: "column", 
                dataPoints: [{
                    label: short_label_0,
                    y: stat_value_final[0]*1
                }, {
                    label: short_label_1,
                    y: stat_value_final[1]*1
                }, {
                    label:short_label_2,
                    y: stat_value_final[2]*1
                }, {
                    label: short_label_3,
                    y: stat_value_final[3]*1
                }, {
                    label: short_label_4,
                    y: stat_value_final[4]*1
                }, {
                    label: short_label_5,
                    y: stat_value_final[5]*1
                }, {
                    label: short_label_6,
                    y: stat_value_final[6]*1
                }, {
                    label: short_label_7,
                    y: stat_value_final[7]*1
                }]
            }]
        });
        chart0.render();
        ////1 гистограмма
        
       
        ////2 график
        var chart1 = new CanvasJS.Chart("chartContainer07", {
            zoomEnabled: true,
             title:{
                text: "Динамика подачи сведений",
                fontSize: 22,
                fontWeight: "bold",
                fontFamily: "calibri"
            },
            animationEnabled: true,
            axisY2: {
                valueFormatString: "0",
//                maximum: maxrange,
                maximum: 1000,
                minimum: minrange,
//                interval: (maxrange/100)*10,
                interval: 10,
                interlacedColor: "#F5F5F5",
               // gridColor: "#D7D7D7",
               // tickColor: "#D7D7D7"
            },
            theme:  theme[3],
            toolTip: {
                shared: true
            },
            legend: {
                verticalAlign: "bottom",
                horizontalAlign: "center",
                fontSize: 15,
                fontFamily: "calibri"
            },
            data: [],
            legend: {
                verticalAlign: "top",
                horizontalAlign: "left",
                fontSize: 20,
                cursor: "pointer",
                itemclick: function(e) {
                    if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                        e.dataSeries.visible = false;
                    } else {
                        e.dataSeries.visible = true;
                    }
                    chart1.render();
                }
            }
        });
        ///!!! Обработчик данных массивов!!!
                //хранилища данных по статистике за определенный период!!!
       var stat_0_package = [];   
       var stat_1_package = []; 
       var stat_2_package = [];   
       var stat_3_package = []; 
       var stat_4_package = [];   
       var stat_5_package = [];         
       var stat_6_package = [];   
       var stat_7_package = []; 
       //обработчик массивов ,значение keys является ключевым и его необходимо обнулять и пересоздавать каждый цикл for!!!
                //stat 0
       var keys = Object.keys( stat_0_date_value );
       for (var i = 0; i < keys.length; i++) {
           var date_from_stat_0 = Object.keys(stat_0_date_value[i]);
           var values_from_stat_0 = stat_0_date_value[i][date_from_stat_0];
                stat_0_package.push( { label:date_from_stat_0 , x: i, y: values_from_stat_0  } );
        }  
        keys= null;    
        //--------
                //stat 1
       var keys = Object.keys( stat_1_date_value );
       for (var i = 0; i < keys.length; i++) {
           var date_from_stat_1 = Object.keys(stat_1_date_value[i]);
           var values_from_stat_1 = stat_1_date_value[i][date_from_stat_1];
                stat_1_package.push( { x: i, y: values_from_stat_1} );
        } 
        keys= null; 
        //-----------
                //stat 2
        var keys = Object.keys( stat_2_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_2 = Object.keys(stat_2_date_value[i]);
           var values_from_stat_2 = stat_2_date_value[i][date_from_stat_2];
                stat_2_package.push( { x: i, y: values_from_stat_2} );
                    
                } 
        keys= null;         
        //----------
                //stat 3
        var keys = Object.keys( stat_3_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_3 = Object.keys(stat_3_date_value[i]);
           var values_from_stat_3 = stat_3_date_value[i][date_from_stat_3];
                stat_3_package.push( { x: i, y: values_from_stat_3} );
        } 
        keys= null;         
        //---------    
                //stat 4
        var keys = Object.keys( stat_4_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_4 = Object.keys(stat_4_date_value[i]);
           var values_from_stat_4 = stat_4_date_value[i][date_from_stat_4];
                stat_4_package.push( { x: i, y: values_from_stat_4} );
        } 
        keys= null;         
        //---------       
                //stat 5
        var keys = Object.keys( stat_5_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_5 = Object.keys(stat_5_date_value[i]);
           var values_from_stat_5 = stat_5_date_value[i][date_from_stat_5];
                stat_5_package.push( { x: i, y: values_from_stat_5} );
        } 
        keys= null;         
        //---------       
                 //stat 6
        var keys = Object.keys( stat_6_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_6 = Object.keys(stat_6_date_value[i]);
           var values_from_stat_6 = stat_6_date_value[i][date_from_stat_6];
                stat_6_package.push( { x: i, y: values_from_stat_6} );
        } 
        keys= null;         
        //--------- 
                //stat 7
        var keys = Object.keys( stat_7_date_value );
        for (var i = 0; i < keys.length; i++) {
           var date_from_stat_7 = Object.keys(stat_7_date_value[i]);
           var values_from_stat_7 = stat_7_date_value[i][date_from_stat_7];
                stat_7_package.push( { x: i, y: values_from_stat_7} );
        } 
        keys= null;         
        //---------       
        var newSeries_0 = { type:"area",name:stat_label_final[0], dataPoints: stat_0_package };
        var newSeries_1 = { type:"area",name:stat_label_final[1], dataPoints: stat_1_package };
        var newSeries_2 = { type:"area",name:stat_label_final[2], dataPoints: stat_2_package };
        var newSeries_3 = { type:"area",name:stat_label_final[3], dataPoints: stat_3_package };
        var newSeries_4 = { type:"area",name:stat_label_final[4], dataPoints: stat_4_package };
        var newSeries_5 = { type:"area",name:stat_label_final[5], dataPoints: stat_5_package };
        var newSeries_6 = { type:"area",name:stat_label_final[6], dataPoints: stat_6_package };
        var newSeries_7 = { type:"area",name:stat_label_final[7], dataPoints: stat_7_package };
        
        chart1.options.data.push(newSeries_0);
        chart1.options.data.push(newSeries_1);
        chart1.options.data.push(newSeries_2);
        chart1.options.data.push(newSeries_3);
        chart1.options.data.push(newSeries_4);
        chart1.options.data.push(newSeries_5);
        chart1.options.data.push(newSeries_6);
        chart1.options.data.push(newSeries_7);
            
        chart1.render();
        ////2 график
       
       ////3 бублик 
        var chart2 = new CanvasJS.Chart("chartContainer09", {
            title: {
                text: "Соотношение поданных сведений",
               fontSize: 22,
               fontWeight: "bold",
               fontFamily: "calibri"
            },
            theme:  theme[3],
            animationEnabled: true,
            data: [{
                type: "doughnut",
                startAngle: 20,
                innerRadius:"35%",
                indexLabelLineThickness: 3,
                indexLabelFontFamily: "Calibri",
                indexLabelFontWeight: "normal",
                indexLabelLineColor:"#0d81a7",
                indexLabelFontSize: 18,
                dataPoints: [{
                    y: stat_value_final[0]*1,
                    label: short_label_0
                }, {
                    y: stat_value_final[1]*1,
                    label: short_label_1
                }, {
                    y: stat_value_final[2]*1,
                    label: short_label_2
                }, {
                    y: stat_value_final[3]*1,
                    label: short_label_3
                }, {
                    y: stat_value_final[4]*1,
                    label: short_label_4
                }, {
                    y: stat_value_final[5]*1,
                    label: short_label_5
                }, {
                    y: stat_value_final[6]*1,
                    label: short_label_6
                },{
                    y: stat_value_final[7]*1,
                    label: short_label_7
                }
                ]
            }]
        });
        chart2.render();
        ////3 бублик
            
            
            
       }
         });
};