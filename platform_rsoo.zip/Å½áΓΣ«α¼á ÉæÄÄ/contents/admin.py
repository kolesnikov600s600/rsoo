# vim:fileencoding=utf-8

from django import forms
import adminactions.actions as actions
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from models import Profile, OrganizationCategory, Organization, RequestForm, Transport, TransportBrand, Staffing, \
    Instruction, ContainerPlatform, Container, ObjectsTreatment, AdjustableWaste, ProfileForm, FKKO, Contract, File, \
    Waste, WasteComponent, RelatesWastes, Assigning, SignedDocuments, AddressAssign, ContractGarbage, Transporters, \
    Settlements, ConflictContainer, ConflictSettle, ConflictTreat, Conflict


class ProfileInline(admin.StackedInline):
    model = Profile
    fk_name = 'user'
    verbose_name_plural = 'profile'


class NewUserAdmin(UserAdmin):
    inlines = (ProfileInline, )
    add_form = UserCreationForm
    list_filter = ('is_staff', 'is_superuser', 'is_active')
    search_fields = ['username', 'email', 'first_name', 'last_name']


class OrganizationAdmin(admin.ModelAdmin):
    list_display = ['name']
    list_filter = ['category']


class InstructionAdmin(admin.ModelAdmin):
    list_display = ['name', 'sort']
    list_editable = ['sort']


class FKKOAdmin(admin.ModelAdmin):
    list_display = ['code', 'name']


class RelatesWastesAdmin(admin.ModelAdmin):
    list_display = ['name', 'okved', 'fkko']


class AddressesAdmin(admin.ModelAdmin):
    list_display = ['address', 'inn']


class ConflictContainerAdmin(admin.StackedInline):
    model = ConflictContainer
    raw_id_fields = ['obj1', 'obj2']


class ConflictSettleAdmin(admin.StackedInline):
    model = ConflictSettle
    raw_id_fields = ['obj1', 'obj2']


class ConflictTreatAdmin(admin.StackedInline):
    model = ConflictTreat
    raw_id_fields = ['obj1', 'obj2']


class ConflictAdmin(admin.ModelAdmin):
    inlines = [ConflictContainerAdmin, ConflictSettleAdmin, ConflictTreatAdmin]
    list_filter = ['conflict_type']
    raw_id_fields = ['solved_by', 'company']


admin.site.unregister(User)
admin.site.register(User, NewUserAdmin)
admin.site.register(OrganizationCategory)
admin.site.register(Instruction, InstructionAdmin)
admin.site.register(Organization, OrganizationAdmin)
admin.site.register(RequestForm)
admin.site.register(Transport)
admin.site.register(TransportBrand)
admin.site.register(Staffing)
admin.site.register(ContainerPlatform)
admin.site.register(Container)
admin.site.register(ObjectsTreatment)
admin.site.register(AdjustableWaste)
admin.site.register(ProfileForm)
admin.site.register(FKKO, FKKOAdmin)
admin.site.register(Contract)
admin.site.register(ContractGarbage)
admin.site.register(File)
admin.site.register(Waste)
admin.site.register(WasteComponent)
admin.site.register(RelatesWastes, RelatesWastesAdmin)
admin.site.register(Assigning)
admin.site.register(Transporters)
admin.site.register(SignedDocuments)
admin.site.register(Settlements)
admin.site.register(AddressAssign, AddressesAdmin)
admin.site.register(Conflict, ConflictAdmin)

actions.add_to_site(admin.site)