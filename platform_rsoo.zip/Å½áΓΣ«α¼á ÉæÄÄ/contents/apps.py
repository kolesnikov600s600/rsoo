# vim:fileencoding=utf-8
from django.apps import AppConfig
 
 
class ContentConfig(AppConfig):
    name = 'contents'
    verbose_name = u'Объекты'
 
    def ready(self):
        import contents.signals