# vim:fileencoding=utf-8
import json
from django.contrib.auth.models import User
from contents.forms import Registration, MicroRegistration, RegisterFormSet, PlatformFormCreate
from django.core.serializers.json import DjangoJSONEncoder
from contents.models import OrganizationCategory, STATUS_WEB, STATUS_DOC, Instruction, ContainerPlatform, \
    AdjustableWaste, Profile, Organization, RequestForm, ProfileForm, SignedDocuments, Container, House
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect
from django.template.loader import render_to_string
from django.views.generic import TemplateView, FormView, View
from contents.templatetags.template_tags import getforms
from django.http import HttpResponse
from django.template import loader
from hubarcode.code128 import Code128Encoder
from pygost.gost3411_12 import GOST341112
import os
from rsso.settings import MEDIA_ROOT

CREATE_ORG_FORMS = {
    '6': ['form_21', 'form_22', 'form_23'],
    '8': ['form_24', 'form_25', 'form_26'],
    '4': ['form_7', 'form_4', 'form_9', 'form_11', 'form_12', 'form_8'],
}


class Protected(View):
    type_user = []


    def user_passes_test(self, user):
        type_user = self.type_user
        return user.is_active

    def user_failed_test(self):
        return redirect('/login/')

    def dispatch(self, request, *args, **kwargs):
        if not self.user_passes_test(request.user):
            return self.user_failed_test()
        return super(Protected, self).dispatch(request, *args, **kwargs)


class FrontView(TemplateView, Protected):
    template_name = 'front.html'

    def get_context_data(self, **kwargs):
        ctx = {'instructions': []}
        forms = getforms(self.request.user)
        for item in Instruction.objects.all():
            if item.forms:
                for i in item.forms:
                    if i in forms:
                        ctx['instructions'].append(item)
        ctx['instructions'] = list(set(ctx['instructions']))
        ctx['instructions'].sort(key=lambda x: x.sort, reverse=False)
        return ctx


class Login(FormView):
    form_class = AuthenticationForm
    template_name = 'login.html'

    def form_valid(self, form):
        username = self.request.POST['username']
        password = self.request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(self.request, user)
                return HttpResponseRedirect('/')
        return HttpResponseRedirect(reverse('login'))


def standart_registration(self, data, u):
    item_data = {
        'name': data['name'],
        'category': data['category'],
        'email': data['email'],
        'phone': data['phone'],
        'inn': data['inn'],
        'bin': data['ogrn'],
        'kpp': data['kpp'],
        'okved': data['okved'],
        'director': data['fio'],
        'address': data['address'],
        'creator': u,
        'request_user': u,
        'request_web': True,
        'registered': True,
    }
    return item_data


def micro_registration(self, data, u):
    item_data = {
        'name': data['name'],
        'category': data['category'],
        'email': data['email'],
        'phone': data['phone'],
        'inn': data['inn'],
        'bin': data['ogrn'],
        'kpp': data['kpp'],
        'okved': data['okved'],
        'director': data['fio'],
        'address': data['address'],
        'contract': data['contract'],
        'creator': u,
        'request_user': u,
        'request_web': True,
        'registered': True,
    }
    return item_data


class RegistrationView(TemplateView):
    form_class = Registration
    template_name = 'register.html'
    formset = None
    create_data = standart_registration
    first_name = 'fio2'
    formset_initial = []
    checkinn = True

    def get_context_data(self, **kwargs):
        ctx = super(RegistrationView, self).get_context_data(**kwargs)
        ctx['form'] = self.form_class()
        if self.formset:
            ctx['formset'] = self.formset(initial=self.formset_initial)
        return ctx

    def post(self, request, *args, **kwargs):
        context = self.get_context_data()
        form = self.form_class(request.POST)
        if self.formset:
            formset = self.formset(request.POST)
            context['formset'] = formset
        status = 'form'
        if form.is_valid():
            data = form.cleaned_data
            kpp = data['kpp']
            inn = data['inn']
            repeat = data['repeat']
            if self.checkinn:
                if repeat:
                    qs = Organization.objects.filter(Q(inn=inn) & Q(kpp=kpp))
                    if qs.exists():
                        o = qs[0]
                        o.request_web = True
                        o.save()
                        o.send_request([o.get_request_user().username], u'Регистрация на сайте www.rsoo.ru')
                        context['status'] = 'success'
                        return super(RegistrationView, self).render_to_response(context)

            if self.checkinn:
                qs = Organization.objects.filter(
                    Q(inn=inn) & (Q(kpp=kpp) | Q(kpp='') | Q(kpp__isnull=True)) & Q(email=data['email']))
                if qs.exists():
                    o = qs[0]
                    o.request_web = True
                    o.save()
                    o.send_request([o.get_request_user().username], u'Регистрация на сайте www.rsoo.ru')
                    status = 'success'

            if status != 'success' and not repeat:
                qs = Organization.objects.filter(Q(inn=inn) & Q(kpp=kpp))
                if qs.exists():
                    o = qs[0]
                    if o.email != data['email']:
                        u = o.get_request_user()
                        ar = u.username.split('@')
                        n = ar[0]
                        if len(n) == 2:
                            n[0] = '*'
                        else:
                            count = 1
                            s = ''
                            for i in n:
                                t = '*'
                                if count == 1 or count == len(n):
                                    t = i
                                s += t
                                count += 1
                            n = s
                        u = '%s@%s' % (n, ar[1])
                        form.cleaned_data['repeat'] = 1
                        context['form'] = form
                        context['u'] = u
                        return super(RegistrationView, self).render_to_response(context)

            if status != 'success':
                qs = User.objects.filter(username=data['email'])
                if qs.exists():
                    status = 'error'

            # регистрация организации
            if status not in ['success', 'error']:
                password = User.objects.make_random_password()
                u = User.objects.create_user(data['email'], data['email'], password,
                                             **{'first_name': data[self.first_name]})
                Profile.objects.create(user=u, password=password, phone=data['phone'])
                # логин пользователя
                user = authenticate(username=u.username, password=password)
                login(request, user)
                item_data = self.create_data(data, u)
                item = Organization.objects.create(**item_data)
                for i in CREATE_ORG_FORMS[str(data['category'].id)]:
                    f = RequestForm.objects.create(
                        form_name=i,
                        deadline=3,
                        organization=item
                    )
                    ProfileForm.objects.create(user=u, form_name=i)
                item.send_request([item.get_request_user().username], u'Регистрация на сайте www.rsoo.ru')
                status = 'success'
                if self.formset:
                    formset = self.formset(request.POST, instance=item)
                    if formset.is_valid():
                        formset.save()
                        for i in item.assigment.all():
                            if not i.name or not i.active:
                                i.delete()
                item.create_wastes()
        context['form'] = form
        context['status'] = status
        return super(RegistrationView, self).render_to_response(context)


class RegistrationMicroView(RegistrationView):
    form_class = MicroRegistration
    template_name = 'micro-register.html'
    formset = RegisterFormSet
    first_name = 'fio'
    create_data = micro_registration
    formset_initial = [{'active': True, 'name': u'Офисное помещение'}]
    checkinn = False


class ManageOrganizations(TemplateView, Protected):
    template_name = 'organizations/base_organizations.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'categories': OrganizationCategory.objects.all(),
            'status_web': STATUS_WEB,
            'status_doc': STATUS_DOC,
            'item4': 1
        }
        return ctx


class ManagePlatform(TemplateView, Protected):
    template_name = 'platforms/base_platform.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'item7': 1
        }
        return ctx


class ManageConflicts(TemplateView, Protected):
    template_name = 'conflicts/blank.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'item10': 1
        }
        return ctx

class Statistic(TemplateView, Protected):
    template_name = 'statistics/stat.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'item30': 1
        }
        return ctx


class ManageScheme(TemplateView, Protected):
    template_name = 'conflicts/blank.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'item11': 1
        }
        return ctx


class ManageGarbage(TemplateView, Protected):
    template_name = 'garbage/base_garbage.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'item12': 1
        }
        return ctx


class ManageObject(TemplateView, Protected):
    template_name = 'universal/bases/treatment.html'
    menu = 'item13'

    def get_context_data(self, **kwargs):
        ctx = {
            self.menu: 1
        }
        return ctx


class ManageContracts(ManageObject):
    points = [
        {'class': ContainerPlatform, 'name': 'platforms'},
        {'class': AdjustableWaste, 'name': 'firms'}
    ]

    def get_context_data(self, **kwargs):
        ctx = super(ManageContracts, self).get_context_data(**kwargs)
        d = self.points
        places = []
        for s in d:
            c = s['class'].objects.filter(creator=self.request.user)
            for i in c:
                places.append({
                    'id': '%s-%s' % (s['name'], i.id),
                    'coordinates': [str(i.lat).replace(',', '.'), str(i.lon).replace(',', '.')],
                    'address': i.address,
                    'contracts': i.get_contracts()
                })
        ctx['places'] = json.dumps(places, cls=DjangoJSONEncoder)

        return ctx


class ManageGarbageContracts(ManageContracts):
    points = [
        {'class': AdjustableWaste, 'name': 'firms'}
    ]


class ManageGarbageContractsBuildings(ManageContracts):
    points = [
        {'class': House, 'name': 'houses'}
    ]


class TestView(TemplateView, Protected):
    template_name = 'upload.html'

    def get_context_data(self, **kwargs):
        ctx = {
            'item10': 1
        }
        return ctx


class XMLData(TemplateView, Protected):
    template_name = 'utils/xmldata.xml'
    content_type = "application/xhtml+xml"

    # def get_context_data(self, **kwargs):
    #
    # ctx['user'] = self.request.user
    #     return ctx


class SubDocument(TemplateView, Protected):
    template_name = 'utils/sub-document.html'

    def get_context_data(self, **kwargs):
        ctx = super(SubDocument, self).get_context_data(**kwargs)
        h = GOST341112(digest_size=256)
        u = self.request.user
        u.profile.sign = True
        u.profile.save()
        data = render_to_string('utils/xmldata.xml', {'user': u})
        name_file = "data-%s.xml" % u.id
        path = os.path.join(MEDIA_ROOT, 'xml', name_file)

        f = open(path, "w")
        f.write(data.encode('utf8'))
        f.close()

        ctx['org'] = u.request_users.all()[0]
        ctx['h1'] = gosthash(path)[0:32].upper()

        d, new = SignedDocuments.objects.get_or_create(creator=u, stribog=ctx['h1'])
        h = GOST341112(digest_size=256)
        h.update(str(d.id))
        ctx['h2'] = h.hexdigest()[0:32].upper()

        name_file = "bar-1-%s.jpg" % u.id
        path = os.path.join(MEDIA_ROOT, 'bars', name_file)
        f = open(path, "wb")
        encoder = Code128Encoder(ctx['h1'])
        encoder.save(f)
        # generate('code39', '%s' % ctx['h1'], output=f, writer=ImageWriter(),
        #          writer_options={'format': 'JPEG', 'dpi': 72, 'center_text': False})
        f.close()

        name_file = "bar-2-%s.jpg" % u.id
        path = os.path.join(MEDIA_ROOT, 'bars', name_file)
        f = open(path, "wb")
        # generate('code39', '%s' % ctx['h2'], output=f, writer=ImageWriter(),
        #          writer_options={'format': 'JPEG', 'dpi': 72, 'center_text': False})
        encoder = Code128Encoder(ctx['h2'])
        encoder.save(f)
        f.close()
        return ctx


def gosthash(fname):
    hash_gost = GOST341112(digest_size=256)
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_gost.update(chunk)
    return hash_gost.hexdigest()


class LocustView(TemplateView):
    template_name = 'upload.html'

    def get_context_data(self, **kwargs):
        ctx = super(LocustView, self).get_context_data(**kwargs)
        item = PlatformFormCreate(
            {
                'number': "1",
                'address': u"kaluga",
                'qty_container': "2",
                'capacity_container': "0.75",
                'creator': "1252",
                'fences': u"no",
                'lat': "55.112005",
                'lon': "36.586531",
                'org_1': u"kolos",
                'org_1_inn': "7708640145",
                'org_1_ogrn': "5077746884705",
                'org_2': u"prolog",
                'org_2_inn': "7715698587",
                'org_2_ogrn': "1087746552299",
                'place_kgm': u"yes",
                'surface': u"aspalt",
                'type': u"open"
            })
        s = item.save()
        for i in range(1, s.qty_container + 1):
            Container.objects.create(
                number=i,
                capacity=s.capacity_container,
                container=s,
                dispose=s.dispose,
                creator=self.request.user
            )

        return ctx


class ManageBuldingsUK(ManageObject):

    def get_context_data(self, **kwargs):
        ctx = super(ManageBuldingsUK, self).get_context_data(**kwargs)
        ctx['houses'] = House.objects.filter(creator=self.request.user)
        return ctx


class ManageFirmWastes(ManageObject):

    def get_context_data(self, **kwargs):
        ctx = super(ManageFirmWastes, self).get_context_data(**kwargs)
        ctx['firms'] = AdjustableWaste.objects.filter(creator=self.request.user)
        return ctx