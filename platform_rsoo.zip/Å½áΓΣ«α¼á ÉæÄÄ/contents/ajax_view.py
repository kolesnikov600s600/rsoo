# vim:fileencoding=utf-8
import json
import urllib2
from decimal import Decimal
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from django.db.models.loading import get_model
from contents.forms import TransportForm, StaffForm, PlatformForm, \
    PlatformFormCreate, ContainerForm, ContainerFormCreate, BasesForm, PointForm, \
    TreatmentForm, TransportersForm, SettlementsForm, WasteForm, BuildingsForm, ContractForm, WastesForm, WasteFormSet, \
    BuildingsMicroForm, FirmWasteFormSet, WastesCheckForm, GarbageContractForm, HouseForm, BuildingsFormUK, \
    GarbageContractFormUK, FirmWastesOneForm
from django.template.loader import render_to_string
from contents.models import Organization, OrganizationCategory, REQUEST_FORM, RequestForm, \
    ContainerPlatform, Container, Profile, FKKO, Waste, RelatesWastes, AdjustableWaste, AddressAssign, get_nearby_points, \
    House, FirmWastes, ContractGarbage, UnloadingPoint, Transporters
from django.template.defaultfilters import strip_tags
from django.views.generic import View
from rsso.utils import JSONResponseMixin, allowed_action
from django.core.paginator import Paginator
from django.db.models import Q, Count, Sum
from service_forms import RangeDate
from datetime import timedelta
from django.core import serializers


def get_model_data(class_name):
    d = CLASS_DICTIONARY[class_name]
    cls = get_model(app_label='contents', model_name=d['model'])
    return cls, d


def list_for_user(user):
    if user.is_superuser:
        q = Q()
    else:
        q = Q(creator=user)
    return q

def firm_wastes_queryset(user):
    aw = AdjustableWaste.objects.filter(creator=user).values_list('id', flat=True)
    qs = FirmWastes.objects.filter(firm__id__in=aw).distinct()
    return qs

def get_one_object(user, cls, pk):
    if user.is_superuser:
        instance = get_object_or_404(cls, id=pk)
    else:
        instance = get_object_or_404(cls, id=pk, creator=user)
    return instance


def get_firm_waste_one(user, pk):
    if user.is_superuser:
        instance = FirmWastes.objects.get(id=pk)
    else:
        instance = FirmWastes.objects.get(id=pk, firm__creator=user)
    return instance


def save_draft_points(form, obj, ctx):
    points = []
    if form.data.get('points', False):
        count = 0
        for p in form.data['points']:
            i = ContainerPlatform.objects.create(
                number=u'б/н',
                address=p,
                lat=form.data['lat'][count],
                lon=form.data['lon'][count],
                creator=obj.creator,
                draft=True
            )
            obj.platforms.add(i)
            points.append({
                'id': '%s-%s' % ('platforms', i.id),
                'coordinates': [str(i.lat).replace(',', '.'), str(i.lon).replace(',', '.')],
                'address': i.address,
                'contracts': [int(obj.id)]
            })
            count += 1
        obj.save()
        ctx['points'] = points
    return ctx


def save_draft_firms(form, obj, ctx):
    points = []
    if form.data.get('points', False):
        count = 0
        for p in form.data['points']:
            if form.data['lat'][count] and form.data['lon'][count]:
                i = AdjustableWaste.objects.create(
                    address=p,
                    org_1=form.data['org_1'],
                    org_1_inn=form.data['org_1_inn'],
                    org_1_ogrn=form.data['org_1_ogrn'],
                    lat=form.data['lat'][count],
                    lon=form.data['lon'][count],
                    creator=obj.creator,
                    category=u'Другое',
                    draft=True
                )
                obj.firms.add(i)
                points.append({
                    'id': '%s-%s' % ('firms', i.id),
                    'coordinates': [str(i.lat).replace(',', '.'), str(i.lon).replace(',', '.')],
                    'address': i.address,
                    'contracts': [int(obj.id)]
                })
                count += 1
        obj.save()
        ctx['points'] = points
    return ctx


def save_wastes(form, obj, ctx):
    ws = obj.wastes.all()
    for waste in ws:
        qs = obj.creator.wastes_creator.filter(fkko=waste.fkko)
        if not qs.exists():
            Waste.objects.create(
                creator=obj.creator,
                fkko=waste.fkko,
                draft=True
            )
    return ctx


def clear_waste_components(s):
    s.wastes.filter(name='', mass='').delete()


CLASS_DICTIONARY = {
    'ObjectsTreatment': {
        'search': ['org_1__icontains', 'address__icontains'],
        'name': 'org_1',
        'model': 'ObjectsTreatment',
        'form': TreatmentForm,
        'create_form': TreatmentForm,
        'map': True,
        'initial_user': False,
        'draft_fields': ['email', 'phone']
    },
    'Transporters': {
        'search': ['org_1__icontains', 'address__icontains'],
        'name': 'org_1',
        'model': 'Transporters',
        'form': TransportersForm,
        'create_form': TransportersForm,
        'map': True,
        'initial_user': False,
        'draft_fields': ['email', 'phone']
    },
    'FirmWastes': {
        'search': ['firm__id'],
        'name': 'fkko',
        'model': 'FirmWastes',
        'form': FirmWastesOneForm,
        'create_form': FirmWastesOneForm,
        'map': False,
        'initial_user': False,
        'get_queryset': firm_wastes_queryset,
        'get_object': get_firm_waste_one,
        'template_form': 'universal/edit/edit-firm-wastes.html'
    },
    'Settlements': {
        'search': ['name__icontains', 'address__icontains'],
        'name': 'name',
        'model': 'Settlements',
        'form': SettlementsForm,
        'create_form': SettlementsForm,
        'map': True,
        'initial_user': False,
        'draft_fields': ['email', 'phone']
    },
    'AdjustableWaste': {
        'search': ['org_1__icontains', 'address__icontains'],
        'name': 'org_1',
        'model': 'AdjustableWaste',
        'form': WasteForm,
        'create_form': WasteForm,
        'map': True,
        'initial_user': False,
        'draft_fields': ['email', 'phone']
    },
    'Base': {
        'search': ['name__icontains', 'address__icontains'],
        'name': 'name',
        'model': 'Base',
        'form': BasesForm,
        'create_form': BasesForm,
        'map': True,
        'initial_user': False
    },
    'UnloadingPoint': {
        'search': ['address__icontains'],
        'name': 'address',
        'model': 'UnloadingPoint',
        'form': PointForm,
        'create_form': PointForm,
        'map': True,
        'initial_user': False,
        'template_form': 'universal/edit/edit-unload.html',
    },
    'Transport': {
        'search': ['brand__name__icontains', 'model__icontains', 'number__icontains'],
        'name': 'model',
        'model': 'Transport',
        'form': TransportForm,
        'create_form': TransportForm,
        'map': False,
        'template_form': 'universal/edit/edit-transport-form.html',
        'initial_user': False
    },
    'Staffing': {
        'search': ['job__icontains'],
        'name': 'job',
        'model': 'Staffing',
        'form': StaffForm,
        'create_form': StaffForm,
        'map': False,
        'template_form': 'universal/edit/edit-staff-form.html',
        'initial_user': False
    },
    'ContainerPlatform': {
        'map': True,
        'model': 'ContainerPlatform',
        'initial_user': False
    },
    'File': {
        'map': False,
        'model': 'File',
        'initial_user': False
    },
    'Buildings': {
        'search': ['org_1__icontains', 'address__icontains'],
        'name': 'category',
        'model': 'AdjustableWaste',
        'form': BuildingsForm,
        'create_form': BuildingsForm,
        'map': True,
        'initial_user': True
    },
    'BuildingsUK': {
        'search': ['org_1__icontains', 'address__icontains'],
        'name': 'category',
        'model': 'AdjustableWaste',
        'form': BuildingsFormUK,
        'create_form': BuildingsFormUK,
        'map': True,
        'initial_user': False,
        'template_form': 'universal/edit/edit-build-uk.html'
    },
    'House': {
        'search': ['address__icontains', 'house_type__icontains'],
        'name': 'address',
        'model': 'House',
        'form': HouseForm,
        'create_form': HouseForm,
        'map': True,
        'initial_user': False,
        'template_form': 'universal/edit/edit-house.html',
    },
    'MicroBuildings': {
        'search': ['org_1__icontains', 'address__icontains'],
        'name': 'category',
        'model': 'AdjustableWaste',
        'form': BuildingsMicroForm,
        'create_form': BuildingsMicroForm,
        'formset': FirmWasteFormSet,
        'map': True,
        'initial_user': True,
        'functions': [save_wastes],
        'template_form': 'universal/edit/edit-micro-build.html',
    },
    'Contract': {
        'search': ['org_1__icontains', 'number__icontains'],
        'name': 'org_1',
        'model': 'Contract',
        'form': ContractForm,
        'create_form': ContractForm,
        'map': False,
        'mtm': ['file', 'platforms', 'firms', 'points', 'lat', 'lon'],
        'functions': [save_draft_points],
        'template_form': 'universal/edit/edit-contract.html',
        'initial_user': False
    },
    'GarbageContract': {
        'search': ['org_1__icontains', 'number__icontains'],
        'name': 'org_1',
        'model': 'ContractGarbage',
        'form': GarbageContractForm,
        'create_form': GarbageContractForm,
        'map': False,
        'mtm': ['file', 'firms', 'points', 'lat', 'lon'],
        'functions': [save_draft_firms],
        'template_form': 'universal/edit/edit-g-contract.html',
        'initial_user': False,
        'fk_fields': ['point']
    },
    'GarbageContractUK': {
        'search': ['org_1__icontains', 'number__icontains'],
        'name': 'org_1',
        'model': 'ContractGarbage',
        'form': GarbageContractFormUK,
        'create_form': GarbageContractFormUK,
        'map': False,
        'mtm': ['file', 'houses'],
        'template_form': 'universal/edit/edit-g-contract-uk.html',
        'initial_user': False
    },
    'Waste': {
        'search': ['fkko__name__icontains', 'fkko__code__icontains'],
        'name': 'id',
        'model': 'Waste',
        'form': WastesForm,
        'create_form': WastesForm,
        'formset': WasteFormSet,
        'formset_clear': clear_waste_components,
        'map': False,
        'template_form': 'universal/edit/edit-wastes.html',
        'initial_user': False
    },
    'WasteCheck': {
        'name': 'id',
        'model': 'Waste',
        'form': WastesCheckForm,
        'create_form': WastesForm,
    },
    'Platforms': {
        'name': 'address',
        'model': 'ContainerPlatform',
        'form': PlatformForm,
        'create_form': PlatformForm,
    },

}


class AjaxMethods(JSONResponseMixin, View):
    @allowed_action
    def get_organization_list(self, data, request):
        if request.user.is_superuser:
            q = Q()
        else:
            q = (Q(creator=request.user) | Q(access=request.user))
        if data.get('category', False):
            q &= Q(category=data.get('category'))
        if data.get('status', False):
            s = data.get('status').split("|")
            if s[0] == 'status_web':
                q &= Q(status_web=s[1])
            else:
                q &= Q(status_doc=s[1])
        if data.get('search', False):
            q &= (Q(name__icontains=data['search']) | Q(inn__icontains=data['search']))
        objects = Organization.objects.filter(q).distinct()
        pager = Paginator(objects, 100)
        page = data.get('page', 1)
        page = pager.page(page)
        suggest = False
        if data.get('search', False) and not objects.count():
            suggest = True
        html = render_to_string('organizations/short-list.html', {'pager': page})
        return {'success': True, 'html': html, 'suggest': suggest}

    @allowed_action
    def edit_field_organization(self, data, request):
        if request.user.is_superuser:
            q = Q(id=data['id'])
        else:
            q = (Q(creator=request.user) | Q(access=request.user)) & Q(id=data['id'])
        objects = Organization.objects.filter(q).distinct()
        if objects.exists():
            o = objects[0]
            setattr(o, data['field'], data['value'])
            o.save()
            if data['field'] == 'email':
                o.change_email()
        return {'success': True}

    @allowed_action
    def get_edit_form(self, data, request):
        item = Organization.objects.get(id=data['id'])
        categories = OrganizationCategory.objects.all()
        forms = []
        for form in REQUEST_FORM:
            f = item.forms.filter(form_name=form[0])
            if f.exists():
                f = f[0]
            else:
                f = False
            forms.append({
                'key': form[0],
                'name': form[1],
                'data': f
            })

        html = render_to_string('organizations/edit-form.html',
                                {'object': item,
                                 'categories': categories,
                                 'forms': forms,
                                 'days': [3, 4, 5, 6, 7]
                                 })
        return {'success': True, 'html': html}

    @allowed_action
    def edit_form_organization(self, data, request):
        if request.user.is_superuser:
            q = Q(id=data['id'])
        else:
            q = (Q(creator=request.user) | Q(access=request.user)) & Q(id=data['id'])
        objects = Organization.objects.filter(q).distinct()
        if objects.exists():
            o = objects[0]
            if data['delete']:
                f = RequestForm.objects.filter(form_name=data['form_name'], organization=o)
                f.delete()
            else:
                f, new = RequestForm.objects.get_or_create(form_name=data['form_name'], organization=o)
                f.comment = data['comment']
                f.deadline = data['deadline']
                f.save()
            o.save()
        return {'success': True}

    @allowed_action
    def get_create_form(self, data, request):
        categories = OrganizationCategory.objects.all()
        forms = []
        for form in REQUEST_FORM:
            forms.append({
                'key': form[0],
                'name': form[1]
            })
        c = data.get('category', False)
        if c == '':
            c = 0
        else:
            c = int(c)
        html = render_to_string('organizations/edit-form.html',
                                {'categories': categories,
                                 'forms': forms,
                                 'days': [3, 4, 5, 6, 7],
                                 'name': data.get('name', ''),
                                 'category_id': c,
                                 'inn': data.get('inn', ''),
                                 'bin': data.get('bin', ''),
                                 'director': data.get('director', ''),
                                 'address': data.get('address', '')
                                 })
        return {'success': True, 'html': html}

    @allowed_action
    def create_organization(self, data, request):
        item_data = {
            'name': data['name'],
            'category': OrganizationCategory.objects.get(id=data['category']),
            'email': data['email'],
            'phone': data['phone'],
            'comment': data['comment'],
            'inn': data['inn'],
            'bin': data['bin'],
            'kpp': data['kpp'],
            'okved': data['okved'],
            'director': data['director'],
            'address': data['address'],
            'creator': request.user,
            'request_web': data.get('request_web', False),
            'request_doc': data.get('request_doc', False),
            'request_send': data.get('request_send', False)
        }
        item = Organization.objects.create(**item_data)
        item.access.add(request.user)
        if data.get('form', False):
            forms = data['form']
            if isinstance(forms, unicode):
                forms = [data['form'], ]
            for i in forms:
                f = RequestForm.objects.create(
                    form_name=i,
                    deadline=data['days_' + i],
                    comment=data['comment_' + i],
                    organization=item
                )
        doc = ''
        if item.request_send:
            send = item.send_request()
            if send['document']:
                doc = render_to_string('organizations/doc-print.html', {'items': [send['document']]})
        html = render_to_string('organizations/one-item.html', {'item': item})

        return {'success': True, 'html': html, 'docs': doc}

    @allowed_action
    def save_organization(self, data, request):

        if request.user.is_superuser:
            instance = Organization.objects.filter(id=data['id'])
        else:
            instance = Organization.objects.filter(id=data['id'], creator=request.user)

        item_data = {
            'name': data['name'],
            'category': OrganizationCategory.objects.get(id=data['category']),
            'email': data['email'],
            'phone': data['phone'],
            'comment': data['comment'],
            'inn': data['inn'],
            'bin': data['bin'],
            'kpp': data['kpp'],
            'okved': data['okved'],
            'director': data['director'],
            'address': data['address'],
        }
        instance.update(**item_data)
        instance[0].change_email()
        html = render_to_string('organizations/one-item.html', {'item': instance[0]})
        return {'success': True, 'id': instance[0].id, 'html': html}

    @allowed_action
    def send_all_requests(self, data, request):
        q = (Q(creator=request.user) | Q(access=request.user)) & (Q(request_web=True) | Q(request_doc=True))
        objects = Organization.objects.filter(q).distinct()
        doc = ''
        docs = []
        for item in objects:
            send = item.send_request()
            if send['document']:
                docs.append(send['document'])
        if len(docs):
            doc = render_to_string('organizations/doc-print.html', {'items': docs})
        return {'success': True, 'docs': doc}

    # platform views

    @allowed_action
    def get_platform_list(self, data, request):
        if request.user.is_superuser:
            q = Q()
        else:
            q = Q(creator=request.user)
        if data.get('search', False):
            q &= (Q(number__icontains=data['search']) | Q(address__icontains=data['search']))
        objects = ContainerPlatform.objects.filter(q).distinct()
        pager = Paginator(objects, 100)
        page = data.get('page', 1)
        page = pager.page(page)
        html = render_to_string('platforms/short-list.html', {'pager': page, 'user': request.user})
        places = []
        for item in page.object_list:
            places.append({'id': item.id, 'name': item.address,
                           'place': [str(item.lat).replace(',', '.'), str(item.lon).replace(',', '.')]})
        return {'success': True, 'html': html, 'places': places, 'page': int(data.get('page', 1))}

    @allowed_action
    def get_edit_platform_form(self, data, request):
        item = ContainerPlatform.objects.get(id=data['id'])
        form = PlatformForm(instance=item)
        html = render_to_string('platforms/edit-form-platform.html',
                                {'object': item, 'form': form, 'user': request.user})
        return {'success': True, 'html': html}

    @allowed_action
    def edit_field_platform(self, data, request):
        if request.user.is_superuser:
            q = Q(id=data['id'])
        else:
            q = Q(creator=request.user) & Q(id=data['id'])
        objects = ContainerPlatform.objects.filter(q).distinct()
        if objects.exists():
            o = objects[0]
            if data['field'] == 'coordinates':
                o.lat = data['value'][0]
                o.lon = data['value'][1]
            else:
                setattr(o, data['field'], data['value'])
            o.save()
        return {'success': True}

    @allowed_action
    def get_create_platform_form(self, data, request):
        u = request.user
        count = ContainerPlatform.objects.filter(creator=u).count() + 1
        if data.get('waste', False):
            ws = AdjustableWaste.objects.get(creator=u, id=int(data.get('waste', 0)))
            form = PlatformFormCreate(initial={'creator': u, 'number': count, 'address': ws.address, 'lat': ws.lat, 'lon': ws.lon})
        elif data.get('house', False):
            ws = House.objects.get(creator=u, id=int(data.get('house', 0)))
            form = PlatformFormCreate(initial={'creator': u, 'number': count, 'address': ws.address, 'lat': ws.lat, 'lon': ws.lon})
        else:
            form = PlatformFormCreate(initial={'creator': u, 'number': count})
        html = render_to_string('platforms/edit-form-platform.html',
                                {'form': form, 'number': data.get('name', ''), 'user': request.user})
        return {'success': True, 'html': html}

    @allowed_action
    def create_platform(self, data, request):
        item = PlatformFormCreate(data['form'])
        s = item.save()
        for i in range(1, s.qty_container + 1):
            Container.objects.create(
                number=i,
                capacity=s.capacity_container,
                container=s,
                dispose=s.dispose,
                creator=request.user
            )
        html = render_to_string('platforms/one-item.html', {'item': s, 'user': request.user})
        p = {'id': s.id, 'name': s.address, 'place': [str(s.lat).replace(',', '.'), str(s.lon).replace(',', '.')]}
        return {'success': True, 'html': html, 'place': p}

    @allowed_action
    def save_platform(self, data, request):
        if request.user.is_superuser:
            instance = get_object_or_404(ContainerPlatform, id=data['id'])
        else:
            instance = get_object_or_404(ContainerPlatform, id=data['id'], creator=request.user)
        form = PlatformForm(data['form'], instance=instance)
        form.is_valid()
        s = form.save()
        if s.draft:
            s.draft = False
            s.save()
        html = render_to_string('platforms/one-item.html', {'item': s, 'user': request.user})
        return {'success': True, 'html': html, 'id': s.id}


    @allowed_action
    def get_platform_prompt(self, data, request):
        if request.user.is_superuser:
            q = Q(id=data['id'])
        else:
            q = Q(creator=request.user) & Q(id=data['id'])
        objects = ContainerPlatform.objects.filter(q).distinct()
        html = u'Пусто'
        if objects.exists():
            o = objects[0]
            html = render_to_string('platforms/prompt.html', {'item': o, 'user': request.user})
        return {'success': True, 'html': html}

    @allowed_action
    def get_edit_container_form(self, data, request):
        item = Container.objects.get(id=data['id'])
        form = ContainerForm(instance=item)
        html = render_to_string('platforms/edit-container-platform.html',
                                {'object': item, 'form': form, 'user': request.user})
        return {'success': True, 'html': html}

    @allowed_action
    def edit_field_container(self, data, request):
        if request.user.is_superuser:
            q = Q(id=data['id'])
        else:
            q = Q(creator=request.user) & Q(id=data['id'])
        objects = Container.objects.filter(q).distinct()
        html1, html2 = '', ''
        o = None
        if objects.exists():
            o = objects[0]
            setattr(o, data['field'], data['value'])
            o.save()
            html1 = render_to_string('platforms/row-container.html', {'object': o})
            html2 = render_to_string('platforms/row-container2.html', {'object': o})
        return {'success': True, 'html1': html1, 'html2': html2, 'id': o.id}

    @allowed_action
    def get_create_container_form(self, data, request):
        u = request.user
        container = ContainerPlatform.objects.get(id=data['id'])
        count = Container.objects.filter(creator=u, container=container).count() + 1
        form = ContainerFormCreate(initial={'creator': u, 'container': container, 'number': count})
        html = render_to_string('platforms/edit-container-platform.html',
                                {'form': form, 'platform': container, 'user': request.user})
        return {'success': True, 'html': html}

    @allowed_action
    def create_container(self, data, request):
        item = ContainerFormCreate(data['form'])
        s = item.save()
        html1 = render_to_string('platforms/one-item.html', {'item': s.container, 'active': True, 'user': request.user})
        html2 = render_to_string('platforms/prompt.html', {'item': s.container, 'user': request.user})
        return {'success': True, 'html1': html1, 'html2': html2, 'platform': s.container.id}

    @allowed_action
    def save_container(self, data, request):
        if request.user.is_superuser:
            instance = get_object_or_404(Container, id=data['id'])
        else:
            instance = get_object_or_404(Container, id=data['id'], creator=request.user)
        form = ContainerForm(data['form'], instance=instance)
        form.is_valid()
        s = form.save()
        html1 = render_to_string('platforms/one-item.html', {'item': s.container, 'active': True, 'user': request.user})
        html2 = render_to_string('platforms/prompt.html', {'item': s.container, 'user': request.user})
        return {'success': True, 'html1': html1, 'html2': html2, 'platform': s.container.id}

    @allowed_action
    def remove_container(self, data, request):
        c = Container.objects.get(id=data['id'])
        platform = c.container
        c.delete()
        html2 = render_to_string('platforms/prompt.html', {'item': platform, 'user': request.user})
        return {'success': True, 'html2': html2, 'platform': platform.id}


    @allowed_action
    def delete_organization(self, data, request):
        c = Organization.objects.get(id=data['id'])
        c.delete()
        return {'success': True}

    # universal
    @allowed_action
    def get_objects_list(self, data, request):
        cls, d = get_model_data(data['class'])
        objects = None
        if d.get('get_queryset', False):
            objects = d['get_queryset'](request.user)
            q = None
            flag = False
        else:
            q = list_for_user(request.user)
            flag = True
        if data.get('search', False):
            s = False
            for i in d['search']:
                qn = Q(**{i: data['search']})
                if not s:
                    s = qn
                else:
                    s |= qn
            if s:
                if q:
                    q &= (s)
                else:
                    q = (s)
        if flag:
            if not objects:
                objects = cls.objects.filter(q).distinct()
            else:
                objects = objects.filter(q).distinct()
        pager = Paginator(objects, 100)
        page = data.get('page', 1)
        page = pager.page(page)
        html = render_to_string('universal/short-list.html', {'pager': page})
        places = []
        if d['map']:
            for item in page.object_list:
                places.append({'id': item.id, 'name': getattr(item, d['name']),
                               'place': [str(item.lat).replace(',', '.'), str(item.lon).replace(',', '.')]})
        return {'success': True, 'html': html, 'places': places, 'page': int(data.get('page', 1))}


    @allowed_action
    def get_objects_list_geo(self, data, request):
        bbox = data['bbox'].split(',')
        lat1, lon1, lat2, lon2 = Decimal(bbox[0]), Decimal(bbox[1]), Decimal(bbox[2]), Decimal(bbox[3])
        cls, d = get_model_data(data['class'])
        q = list_for_user(request.user)
        if data.get('search', False):
            s = False
            for i in d['search']:
                qn = Q(**{i: data['search']})
                if not s:
                    s = qn
                else:
                    s |= qn
            if s:
                q &= s
        q &= Q(Q(Q(lat__gt=lat1) & Q(lat__lt=lat2)) & Q(Q(lon__gt=lon1) & Q(lon__lt=lon2)))
        objects = cls.objects.filter(q).distinct()
        obj_roller = []
        for mark in objects:
            mark_d = {'type': data['class'],
                      'id': mark.id,
                      'name': mark.address,
                      'geometry': {
                          'type': "Point",
                          'coordinates': [str(mark.lat), str(mark.lon)]
                      },
                      'properties': {
                          # "balloonContent": "",
                          # "hintContent": "",
                      }}
            obj_roller.append(mark_d)
        html = render_to_string('platforms/short-list.html', {'pager': objects, 'user': request.user})
        return {'type': "FeatureCollection", 'features': obj_roller, 'html': html}


    @allowed_action
    def get_edit_object_form(self, data, request):
        cls, d = get_model_data(data['class'])
        if d.get('get_object'):
            item = d['get_object'](request.user, data['id'])
        else:
            item = get_one_object(request.user, cls, data['id'])
        formset = None
        form = d['form'](instance=item)
        if d.get('fk_fields', False):
            for f in d['fk_fields']:
                form.fields[f].queryset = form.fields[f].queryset.filter(creator=request.user)
        if d.get('formset', False):
            formset = d['formset'](instance=item)
        template_form = d.get('template_form', 'universal/edit-object.html')
        html = render_to_string(template_form, {'object': item, 'form': form, 'formset': formset})
        return {'success': True, 'html': html}

    @allowed_action
    def get_create_object_form(self, data, request):
        cls, d = get_model_data(data['class'])
        u = request.user
        init = {
            'creator': u
        }
        if d['initial_user']:
            init.update({'email': u.username, 'phone': u.profile.phone, 'org_1': u.request_users.all()[0].name})

        formset = None
        if d.get('formset', False):
            formset = d['formset']()

        form = d['create_form'](initial=init)
        if d.get('fk_fields', False):
            for f in d['fk_fields']:
                form.fields[f].queryset = form.fields[f].queryset.filter(creator=request.user)
        template_form = d.get('template_form', 'universal/edit-object.html')
        html = render_to_string(template_form,
                                {'form': form, 'name': data.get('name', ''), 'formset': formset, 'user': u})
        return {'success': True, 'html': html}

    @allowed_action
    def save_object(self, data, request):
        cls, d = get_model_data(data['class'])
        if d.get('get_object'):
            instance = d['get_object'](request.user, data['id'])
        else:
            instance = get_one_object(request.user, cls, data['id'])
        if d.get('mtm', False):
            for f in d['mtm']:
                if data['form'].get(f, False):
                    if not isinstance(data['form'][f], list):
                        data['form'][f] = [data['form'][f]]
        form = d['form'](data['form'], instance=instance)
        form.is_valid()
        s = form.save()

        if d.get('formset', False):
            formset = d['formset'](data['form'], instance=instance)
            if formset.is_valid():
                formset.save()
                if d.get('formset_clear', False):
                    d['formset_clear'](s)

        if d.get('draft_fields', False):
            draft = False
            for f in d['draft_fields']:
                if not getattr(s, f, False):
                    draft = True
            s.draft = draft
            s.save()

        html = render_to_string('universal/one-item.html', {'item': s})
        ctx = {'success': True, 'html': html, 'id': s.id, 'name': getattr(s, d['name'])}
        if d.get('functions', False):
            for f in d['functions']:
                ctx = f(form, s, ctx)
        return ctx

    @allowed_action
    def create_object(self, data, request):
        cls, d = get_model_data(data['class'])
        if d.get('mtm', False):
            for f in d['mtm']:
                if data['form'].get(f, False):
                    if not isinstance(data['form'][f], list):
                        data['form'][f] = [data['form'][f]]
        item = d['create_form'](data['form'])
        s = item.save()
        if d.get('draft_fields', False):
            draft = False
            for f in d['draft_fields']:
                if not getattr(s, f, False):
                    draft = True
            s.draft = draft
            s.save()
        if d.get('formset', False):
            formset = d['formset'](data['form'], instance=s)
            if formset.is_valid():
                formset.save()
                if d.get('formset_clear', False):
                    d['formset_clear'](s)

        html = render_to_string('universal/one-item.html', {'item': s})
        p = None
        if d['map']:
            p = {'id': s.id, 'name': getattr(s, d['name']),
                 'place': [str(s.lat).replace(',', '.'), str(s.lon).replace(',', '.')]}
        ctx = {'success': True, 'html': html, 'place': p, 'id': s.id}
        if d.get('functions', False):
            for f in d['functions']:
                ctx = f(item, s, ctx)
        return ctx

    @allowed_action
    def delete_object(self, data, request):
        cls, d = get_model_data(data['class'])
        item = get_one_object(request.user, cls, data['id'])
        pk = item.id
        item.delete()
        return {'success': True, 'id': pk}

    @allowed_action
    def change_contact(self, data, request):
        if data['field'] == 'first_name':
            request.user.first_name = data['value']
            request.user.save()
        if data['field'] == 'phone':
            if not getattr(request.user, 'profile', False):
                Profile.objects.create(user=request.user, phone=data['value'])
            else:
                request.user.profile.phone = data['value']
                request.user.profile.save()
        return {'success': True}

    @allowed_action
    def code_fkko(self, data, request):
        q = FKKO.objects.filter(Q(code__icontains=data['q']) | Q(name__icontains=data['q'])).exclude(code__endswith='0').distinct()
        d = []
        for item in q:
            d.append({
                'value': item.code,
                'label': item.name,
                'id': item.id
            })
        return d

    @allowed_action
    def check_buildings(self, data, request):
        c = request.user.waste_creator.all().count()
        if c > 0:
            return {'subscribe': True}
        return {'subscribe': False}

    @allowed_action
    def check_transport_company(self, data, request):
        c = request.user.platform_creator.all().count()
        if c == 0:
            return {'subscribe': False}
        wastes = request.user.waste_creator.all()
        found = False
        for item in wastes:
            if len(item.get_contracts()) > 0:
                pl = get_nearby_points(item, ContainerPlatform)
                if pl.count() == 0:
                    found = item
                    break
        if found:
            contract = found.get_contracts()[0]
            found = render_to_string('messages/sign-transport-error.html', {'item': found, 'contract': contract})
        return {'subscribe': True, 'found': found}


    @allowed_action
    def check_manager_company(self, data, request):
        c = request.user.platform_creator.all().count()
        if c == 0:
            return {'subscribe': False}
        houses = request.user.house_creator.all()
        found = False
        for item in houses:
            if len(item.get_contracts()) > 0:
                pl = get_nearby_points(item, ContainerPlatform)
                if pl.count() == 0:
                    found = item
                    break
        if found:
            contract = found.get_contracts()[0]
            found = render_to_string('messages/sign-uk-error.html', {'item': found, 'contract': contract})
        return {'subscribe': True, 'found': found}

    @allowed_action
    def address_inn(self, data, request):
        q = AddressAssign.objects.filter(inn=data['inn'])
        d = []
        for item in q:
            d.append(item.address)
        return d

    @allowed_action
    def okved_assign(self, data, request):
        from BeautifulSoup import BeautifulSoup
        okved = data['okved']
        items = RelatesWastes.objects.filter(okved=okved, name__isnull=False).exclude(name='')
        html = render_to_string('utils/micro-inlines.html', {'items': items})
        name = None
        if data['okved']:
            path = 'http://xn--b1aeqp1f.xn--p1ai/ajaxed/?kwd=%s' % data['okved']
            headers = {'User-Agent': 'python/rsoo.ru'}
            req = urllib2.Request(path, None, headers)
            resp = urllib2.urlopen(req)
            response_content = resp.read()

            doc = response_content
            soup = BeautifulSoup(''.join(doc))
            o = soup.findAll("dt", {"class": "headline"})[0]
            # okveds = json.loads(response_content)
            if o:
                name = strip_tags(o.prettify().decode('utf8')).replace(u'подробнее', '')
        return {'html': html, 'name': name}


    @allowed_action
    def get_stat(self, data, request):
        class_dict = {
            'Platforms': [ContainerPlatform],
            'Contracts': [ContractGarbage],
            'Points': [UnloadingPoint],
            'Containers': [Container],
            'Transporters': [Transporters],
        }
        if data.get('class', False):
            data_count = class_dict[data['class']]
        else:
            data_count = [ContainerPlatform, ContractGarbage, UnloadingPoint, Container, Transporters]
        stat_data = []
        form = RangeDate(data)
        if request.user.is_superuser and form.is_valid():
            orgs_cat = OrganizationCategory.objects.all()
            for item in orgs_cat:
                range_data = []
                delta = form.cleaned_data['date_to'] - form.cleaned_data['date_from']
                for day in range(delta.days + 1):
                    range_data.append({(form.cleaned_data['date_from'] + timedelta(days=day)).strftime('%d.%m.%y'): 0})
                users = User.objects.filter(id__in=Organization.objects.filter(category=item)
                                            .values_list('request_user', flat=True))
                for table in data_count:
                    c = table.objects\
                        .filter(
                            creator__in=users,
                            date__gte=form.cleaned_data['date_from'],
                            date__lte=(form.cleaned_data['date_to']+timedelta(days=1)))\
                        .distinct().extra({'create': "date(date)"}).values('create')\
                        .annotate(total=Count('id'))
                    for item_date in c:
                        for day in range_data:
                            f = item_date['create'].strftime('%d.%m.%y')
                            ins = day.get(f, 'not')
                            if ins != 'not':
                                day[f] = day[f] + item_date['total']
                                continue
                total = 0
                delta = form.cleaned_data['date_to'] - form.cleaned_data['date_from']
                for t in range(delta.days + 1):
                    total += range_data[t][(form.cleaned_data['date_from'] + timedelta(days=t)).strftime('%d.%m.%y')]
                stat_data.append({'id': item.id, 'name': item.name, 'days': range_data, 'total': total})
            return {'success': '200', 'stat': stat_data}
        return {'success': '400 forbidden'}