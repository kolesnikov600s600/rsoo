import json
from django.http.response import HttpResponseBadRequest, HttpResponse
from contents.models import File
from slugify import slugify
from django.core.files.uploadedfile import UploadedFile


def multiuploader(request):
    if request.method == 'POST':
        if request.FILES == None:
            return HttpResponseBadRequest('Must have files attached!')

        # getting file data for farther manipulations

        file = request.FILES[u'files[]']
        wrapped_file = UploadedFile(file)

        filename = wrapped_file.name
        file_size = wrapped_file.file.size

        # writing file manually into model
        # because we don't need form of any type.
        f = File()
        f.title = str(filename.encode('utf-8'))
        f.file = file
        f.creator = request.user
        f.save()

        file_delete_url = '/delete/'

        result = []

        result.append({"name": filename,
                       "size": file_size,
                       "url": f.file.url,
                       "id": f.pk,
                       "delete_url": file_delete_url+str(f.pk)+'/',
                       "delete_type":"POST"
                       })
        response_data = json.dumps(result)
        return HttpResponse(response_data, content_type='application/json')