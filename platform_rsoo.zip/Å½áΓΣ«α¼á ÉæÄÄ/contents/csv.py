from django.contrib.auth.models import User
from django.http import HttpResponse
from django.template import loader, Context
from contents.models import Organization, Transporters, ContainerPlatform, Container


__author__ = 'Ivan'


def orders_to_csv(request):
    response = HttpResponse()
    response['Content-Disposition'] = 'attachment; filename="orders.csv"'
    organizations = Organization.objects.filter()
    t = loader.get_template('csv/report.html')
    c = Context({
        'organizations': organizations,
    })
    response.write(t.render(c).encode('cp1251'))
    return response


def orders_to_csv2(request):
    response = HttpResponse()
    response['Content-Disposition'] = 'attachment; filename="orders.csv"'
    organizations = Organization.objects.filter(category__id=1)
    users = organizations.values_list('request_user__id', flat=True)
    qs = Transporters.objects.filter(creator__id__in=users).distinct()
    t = loader.get_template('csv/report2.html')
    c = Context({
        'transport': qs,
    })
    response.write(t.render(c).encode('cp1251'))
    return response


def orders_to_csv3(request):
    response = HttpResponse()
    response['Content-Disposition'] = 'attachment; filename="orders.csv"'
    uss = []
    users = User.objects.all()
    for u in users:
        if u.request_users.exists():
            if u.request_users.all()[0].category.id == 8:
                uss.append(u)
    t = loader.get_template('csv/report3.html')
    c = Context({
        'users': uss,
    })
    response.write(t.render(c).encode('cp1251'))
    return response


def platforms(request):
    response = HttpResponse()
    response['Content-Disposition'] = 'attachment; filename="orders.csv"'
    uss = []
    cp = ContainerPlatform.objects.all()
    c = Container.objects.all()
    t = loader.get_template('csv/report4.html')
    c = Context({
        'cp': cp,
        'c': c
    })
    response.write(t.render(c).encode('cp1251'))
    return response