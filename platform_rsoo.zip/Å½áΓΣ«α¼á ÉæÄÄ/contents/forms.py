# vim:fileencoding=utf-8
from django.contrib.auth.models import User
from django import forms
from django.forms.models import inlineformset_factory
from models import Transport, Staffing, ContainerPlatform, Container, Base, UnloadingPoint, ObjectsTreatment, \
    Transporters, Settlements, AdjustableWaste, Contract, OrganizationCategory, Waste, WasteComponent, FirmWastes, \
    Organization, Assigning, ContractGarbage, House


class TransportForm(forms.ModelForm):
    class Meta:
        model = Transport
        exclude = []
        widgets = {
            'model': forms.TextInput(attrs={'class': 'require change-input', 'data-change': 'change-model'}),
            'brand': forms.Select(attrs={'class': 'require change-input', 'data-change': 'change-brand'}),
            'number': forms.TextInput(attrs={'class': 'require change-input', 'data-change': 'change-number'}),
            'vin_number': forms.TextInput(attrs={'class': 'require change-input'}),
            'equipment': forms.TextInput(attrs={'class': 'require change-input'}),
            'year': forms.TextInput(attrs={'class': 'require change-input'}),
            'mileage': forms.TextInput(attrs={'class': 'require change-input'}),
            'status': forms.TextInput(attrs={'class': 'require change-input'}),
            'euro': forms.TextInput(attrs={'class': 'require change-input'}),
            'capacity': forms.TextInput(attrs={'class': 'require change-input'}),
            'carrying_capacity': forms.TextInput(attrs={'class': 'require change-input'}),
            'reasons_use': forms.TextInput(attrs={'class': 'require change-input'}),
            'intensity': forms.TextInput(attrs={'class': 'require change-input'}),
            'gps': forms.TextInput(attrs={'class': 'require change-input'}),
            'gps_model': forms.TextInput(attrs={'class': 'require change-input'}),
            'gps_firm': forms.TextInput(attrs={'class': 'require change-input'}),
            'creator': forms.HiddenInput()
        }


class StaffForm(forms.ModelForm):
    class Meta:
        model = Staffing
        exclude = []
        widgets = {
            'job': forms.TextInput(attrs={'class': 'require change-input', 'data-change': 'change-job'}),
            'qty_staff': forms.TextInput(
                attrs={'class': 'require change-input numbers', 'data-change': 'change-qty_staff',
                       'data-plural': u' штатный, штатных, штатных'}),
            'qty_out': forms.TextInput(attrs={'class': 'require change-input numbers', 'data-change': 'change-qty_out',
                                              'data-plural': u' внештатный, внештатных, внештатных'}),
            'money': forms.TextInput(attrs={'class': 'require change-input'}),
            'creator': forms.HiddenInput()
        }


class PlatformForm(forms.ModelForm):
    class Meta:
        model = ContainerPlatform
        exclude = ['incorrect']
        widgets = {
            'number': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-number'}),
            'address': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-address'}),
            'qty_container': forms.TextInput(attrs={'class': 'require'}),
            'capacity_container': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'lat': forms.TextInput(),
            'lon': forms.TextInput(),
            'creator': forms.HiddenInput()
        }


class PlatformFormCreate(forms.ModelForm):
    class Meta:
        model = ContainerPlatform
        exclude = ['incorrect']
        widgets = {
            'number': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-number'}),
            'address': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-address'}),
            'qty_container': forms.TextInput(attrs={'class': 'require'}),
            'capacity_container': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'lat': forms.TextInput(),
            'lon': forms.TextInput(),
            'creator': forms.HiddenInput()
        }


class ContainerForm(forms.ModelForm):
    class Meta:
        model = Container
        exclude = []
        widgets = {
            'number': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-number'}),
            'capacity': forms.NumberInput(
                attrs={'class': 'change-input require', 'placeholder': u'куб.м.', 'step': '0.1', 'min': 0, 'max': 10}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'creator': forms.HiddenInput(),
            'container': forms.HiddenInput()
        }


class ContainerFormCreate(forms.ModelForm):
    class Meta:
        model = Container
        exclude = []
        widgets = {
            'number': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-number'}),
            'capacity': forms.NumberInput(
                attrs={'class': 'change-input require', 'placeholder': u'куб.м.', 'step': '0.1', 'min': 0, 'max': 10}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'container': forms.HiddenInput(),
            'creator': forms.HiddenInput(),
        }


class BasesForm(forms.ModelForm):
    class Meta:
        model = Base
        exclude = []
        widgets = {
            'name': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-name'}),
            'address': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-address'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }


class PointForm(forms.ModelForm):
    class Meta:
        model = UnloadingPoint
        exclude = []
        widgets = {
            'address': forms.TextInput(attrs={'class': 'change-input require', 'data-change': 'change-address'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'date_doc': forms.DateInput(format='%d.%m.%Y', attrs={'class': 'calendar-wg'}),
            'deadline_doc': forms.DateInput(format='%d.%m.%Y', attrs={'class': 'calendar-wg'}),
            'limit_mesure': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-measure'}),
            'capacity_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_tariff_1', 'data-a': 'div'}),
            'tariff_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_capacity_1', 'data-a': 'div'}),
            'total_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_1', 'data-d2': '#id_tariff_1', 'data-a': 'multi'}),
            'capacity_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_tariff_2', 'data-a': 'div'}),
            'tariff_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_capacity_2', 'data-a': 'div'}),
            'total_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_2', 'data-d2': '#id_tariff_2', 'data-a': 'multi'}),
            'capacity_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_tariff_3', 'data-a': 'div'}),
            'tariff_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_capacity_3', 'data-a': 'div'}),
            'total_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_3', 'data-d2': '#id_tariff_3', 'data-a': 'multi'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }


class TreatmentForm(forms.ModelForm):
    class Meta:
        model = ObjectsTreatment
        exclude = ['draft', 'incorrect']
        widgets = {
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'address': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'type1': forms.CheckboxInput(attrs={'class': 's-check'}),
            'type2': forms.CheckboxInput(attrs={'class': 's-check'}),
            'type3': forms.CheckboxInput(attrs={'class': 's-check'}),
            'type4': forms.CheckboxInput(attrs={'class': 's-check'}),
            'type5': forms.CheckboxInput(attrs={'class': 's-check'}),
            'creator': forms.HiddenInput()
        }


class TransportersForm(forms.ModelForm):
    class Meta:
        model = Transporters
        exclude = ['draft']
        widgets = {
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'address': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }


class SettlementsForm(forms.ModelForm):
    class Meta:
        model = Settlements
        exclude = ['draft', 'incorrect']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'require'}),
            'address': forms.TextInput(attrs={'class': 'require'}),
            'okato': forms.TextInput(attrs={'class': 'require'}),
            'houses': forms.TextInput(attrs={'class': 'require'}),
            'people_summer': forms.TextInput(attrs={'class': 'require'}),
            'people_winter': forms.TextInput(attrs={'class': 'require'}),
            'type_object': forms.TextInput(attrs={'class': 'require'}),
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }


class WasteForm(forms.ModelForm):
    class Meta:
        model = AdjustableWaste
        exclude = ['draft']
        fields = ['address', 'org_1', 'org_1_inn', 'org_1_ogrn', 'category', 'email', 'phone', 'square', 'people',
                  'qty', 'comment', 'lat', 'lon', 'creator']
        widgets = {
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'address': forms.TextInput(attrs={'class': 'require'}),
            'category': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }


class BuildingsForm(forms.ModelForm):
    class Meta:
        model = AdjustableWaste
        exclude = []
        fields = ['address', 'building', 'number', 'reasons_use', 'org_2', 'org_2_inn', 'org_2_ogrn', 'agreement', 'date_agreement', 'category', 'tko',
                  'org_3', 'org_3_inn', 'org_3_ogrn', 'email', 'phone', 'square', 'people', 'qty', 'comment', 'lat',
                  'lon', 'creator', 'own', 'org_1']
        widgets = {
            'address': forms.TextInput(attrs={'class': 'require'}),
            'category': forms.TextInput(attrs={'class': 'require'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'org_3_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_3_inn'}),
            'org_3_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_3_ogrn'}),
            'phone': forms.HiddenInput(),
            'email': forms.HiddenInput(),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput(),
            'own': forms.HiddenInput(),
            'org_1': forms.HiddenInput(),
        }

    category = forms.CharField(label=u'Вид деятельности', widget=forms.TextInput(attrs={'class': 'require'}))
    own = forms.CharField(initial=1, widget=forms.HiddenInput())


class BuildingsFormUK(forms.ModelForm):
    class Meta:
        model = AdjustableWaste
        exclude = []
        fields = ['address', 'org_1', 'org_1_inn', 'org_1_ogrn', 'category', 'email', 'phone', 'square', 'qty', 'tko',
                  'agreement', 'date_agreement', 'org_3', 'org_3_inn', 'org_3_ogrn',
                  'comment', 'lat', 'lon', 'creator', 'own']
        widgets = {
            'address': forms.TextInput(attrs={'class': 'require'}),
            'category': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'org_3_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_3_inn'}),
            'org_3_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_3_ogrn'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }

    address = forms.CharField(label=u'Адрес дома', widget=forms.TextInput(attrs={'class': 'require'}))
    category = forms.CharField(label=u'Категория', widget=forms.TextInput(attrs={'class': 'require'}))
    org_3 = forms.CharField(label=u'Организация, осуществляющая вывоз отходов', required=False, widget=forms.TextInput())
    own = forms.CharField(initial=1, widget=forms.HiddenInput())


class BuildingsMicroForm(forms.ModelForm):
    class Meta:
        model = AdjustableWaste
        exclude = []
        fields = ['address', 'building', 'number', 'reasons_use', 'org_2', 'org_2_inn', 'org_2_ogrn', 'agreement', 'date_agreement',
                  'email', 'phone', 'category',  'square', 'people', 'qty', 'comment', 'lat', 'lon', 'creator',
                  'own', 'org_1']

        widgets = {
            'address': forms.TextInput(attrs={'class': 'require'}),
            'category': forms.TextInput(attrs={'class': 'require'}),
            'org_2_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_inn'}),
            'org_2_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_2_ogrn'}),
            'phone': forms.HiddenInput(),
            'email': forms.HiddenInput(),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput(),
            'own': forms.HiddenInput(),
            'org_1': forms.HiddenInput(),
        }

    category = forms.CharField(label=u'Назначение помещения', widget=forms.TextInput(attrs={'class': 'require'}))
    own = forms.CharField(initial=1, widget=forms.HiddenInput())


class ContractForm(forms.ModelForm):
    class Meta:
        model = Contract
        exclude = []
        widgets = {
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'measure': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-measure'}),
            'capacity_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_tariff_1', 'data-a': 'div'}),
            'tariff_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_capacity_1', 'data-a': 'div'}),
            'total_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_1', 'data-d2': '#id_tariff_1', 'data-a': 'multi'}),
            'capacity_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_tariff_2', 'data-a': 'div'}),
            'tariff_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_capacity_2', 'data-a': 'div'}),
            'total_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_2', 'data-d2': '#id_tariff_2', 'data-a': 'multi'}),
            'capacity_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_tariff_3', 'data-a': 'div'}),
            'tariff_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_capacity_3', 'data-a': 'div'}),
            'total_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_3', 'data-d2': '#id_tariff_3', 'data-a': 'multi'}),
            'number': forms.TextInput(attrs={'class': 'require'}),
            'fkko': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }

    contract_date = forms.DateInput(format='%d.%m.%Y', attrs={'class': 'require'})
    points = forms.CharField(required=False)
    lat = forms.CharField(required=False)
    lon = forms.CharField(required=False)

    def clean_points(self):
        return self.data['points']

    def clean_lat(self):
        return self.data['lat']

    def clean_lon(self):
        return self.data['lon']


class GarbageContractForm(forms.ModelForm):
    class Meta:
        model = ContractGarbage
        exclude = ['number_normalize', 'tariff']
        widgets = {
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'number': forms.TextInput(attrs={'class': 'require'}),
            'measure': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-measure'}),
            'capacity_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_tariff_1', 'data-a': 'div'}),
            'tariff_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_capacity_1', 'data-a': 'div'}),
            'total_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_1', 'data-d2': '#id_tariff_1', 'data-a': 'multi'}),
            'capacity_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_tariff_2', 'data-a': 'div'}),
            'tariff_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_capacity_2', 'data-a': 'div'}),
            'total_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_2', 'data-d2': '#id_tariff_2', 'data-a': 'multi'}),
            'capacity_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_tariff_3', 'data-a': 'div'}),
            'tariff_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_capacity_3', 'data-a': 'div'}),
            'total_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_3', 'data-d2': '#id_tariff_3', 'data-a': 'multi'}),
            'creator': forms.HiddenInput()
        }

    contract_date = forms.DateInput(format='%d.%m.%Y', attrs={'class': 'require'})
    points = forms.CharField(required=False)
    lat = forms.CharField(required=False)
    lon = forms.CharField(required=False)

    def clean_points(self):
        return self.data['points']

    def clean_lat(self):
        return self.data['lat']

    def clean_lon(self):
        return self.data['lon']


class GarbageContractFormUK(forms.ModelForm):
    class Meta:
        model = ContractGarbage
        fields = ['number', 'contract_date', 'org_1', 'org_1_inn', 'org_1_ogrn', 'tariff', 'houses',
                  'capacity_1', 'capacity_2', 'capacity_3', 'tariff_1', 'tariff_2', 'tariff_3', 'total_1', 'total_2', 'total_3',
                  'measure', 'periodicity', 'creator']
        widgets = {
            'org_1': forms.TextInput(attrs={'class': 'require'}),
            'org_1_inn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_inn'}),
            'org_1_ogrn': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-org_1_ogrn'}),
            'number': forms.TextInput(attrs={'class': 'require'}),
            'measure': forms.TextInput(attrs={'class': 'change-input', 'data-change': 'change-measure'}),
            'capacity_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_tariff_1', 'data-a': 'div'}),
            'tariff_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_1', 'data-d2': '#id_capacity_1', 'data-a': 'div'}),
            'total_1': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_1', 'data-d2': '#id_tariff_1', 'data-a': 'multi'}),
            'capacity_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_tariff_2', 'data-a': 'div'}),
            'tariff_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_2', 'data-d2': '#id_capacity_2', 'data-a': 'div'}),
            'total_2': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_2', 'data-d2': '#id_tariff_2', 'data-a': 'multi'}),
            'capacity_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_tariff_3', 'data-a': 'div'}),
            'tariff_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_total_3', 'data-d2': '#id_capacity_3', 'data-a': 'div'}),
            'total_3': forms.TextInput(attrs={'class': 'change-account', 'data-d1': '#id_capacity_3', 'data-d2': '#id_tariff_3', 'data-a': 'multi'}),
            'creator': forms.HiddenInput()
        }

    contract_date = forms.DateInput(format='%d.%m.%Y', attrs={'class': 'require'})
    org_1 = forms.CharField(required=False, label=u'Транспортировщик отходов')
    measure = forms.CharField(required=False, label=u'Единица измеренеия')

    def clean_points(self):
        return self.data['points']


class Registration(forms.Form):
    class Meta:
        exclude = []

    category = forms.ModelChoiceField(required=True, queryset=OrganizationCategory.objects.all(), label=u'Категория организации')
    name = forms.CharField(required=True, label=u'Наименование организации')
    inn = forms.CharField(required=True, label=u'ИНН')
    kpp = forms.CharField(required=True, label=u'КПП')
    ogrn = forms.CharField(required=True, label=u'ОГРН')
    okved = forms.CharField(required=False, label=u'ОКВЭД')
    address = forms.CharField(required=False, label=u'Юридический адрес')
    fio = forms.CharField(required=True, label=u'ФИО руководителя')
    email = forms.EmailField(required=True, label=u'Адрес электронной почты')
    phone = forms.CharField(required=True, label=u'Телефон')
    fio2 = forms.CharField(required=True, label=u'ФИО контактного лица')
    repeat = forms.CharField(required=False, label=u'ФИО контактного лица', widget=forms.HiddenInput())

    def clean_category(self):
        data = self.cleaned_data['category']
        if not data.id in [6, 4]:
            raise forms.ValidationError(u"Для данной категории организаций регистрация пока не открыта")
        return data

    def clean_email(self):
        data = self.cleaned_data['email']
        qs = User.objects.filter(username=data)
        if qs.exists():
            org = qs[0].request_users.all()[0]
            if org.inn != self.cleaned_data['inn'] and org.kpp != self.cleaned_data['kpp']:
                raise forms.ValidationError(u"С указанным адресом электронной почты уже зарегистрирована другая компания. Введите другой адрес электронной почты")
        return data


class MicroRegistration(Registration):
    class Meta:
        exclude = ['fio2']

    category = forms.ModelChoiceField(required=True, queryset=OrganizationCategory.objects.all(), initial=8, label=u'Категория организации', widget=forms.HiddenInput())
    name = forms.CharField(required=True, label=u'Введите название либо любой параметр из перечисленных ниже')
    contract = forms.BooleanField(label=u'Наличие прямого договора с транспортировщиком на вывоз отходов', required=False)
    fio2 = forms.CharField(required=False, label=u'ФИО контактного лица')
    kpp = forms.CharField(required=False, label=u'КПП')

    def clean_category(self):
        data = self.cleaned_data['category']
        if data.id != 8:
            raise forms.ValidationError(u"Для данной категории организаций регистрация пока не открыта")
        return data

    def clean_email(self):
        data = self.cleaned_data['email']
        qs = User.objects.filter(username=data)
        if qs.exists():
            raise forms.ValidationError(u"Указанный адрес уже используется в системе. Введите другой адрес электронной почты")
        return data


class WastesForm(forms.ModelForm):
    class Meta:
        model = Waste
        exclude = ['active']
        widgets = {
            'compositions': forms.CheckboxInput(attrs={'class': 'hider-checkbox', 'data-hider': '#hide-check-1'}),
            'passport': forms.CheckboxInput(attrs={'class': 'hider-checkbox', 'data-hider': '#hide-check-2'}),
            'fkko': forms.HiddenInput(),
            'creator': forms.HiddenInput()
        }


class WastesCheckForm(forms.ModelForm):
    class Meta:
        model = Waste
        fields = ['active']


class WastesComponentForm(forms.ModelForm):
    class Meta:
        model = WasteComponent
        exclude = []
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': u'Название компонента'}),
            'mass': forms.TextInput(attrs={'placeholder': u'Массовая доля'}),
        }


class FirmWastesForm(forms.ModelForm):
    class Meta:
        model = FirmWastes
        fields = ['firm', 'fkko', 'name', 'active']
        widgets = {
            'fkko': forms.HiddenInput(),
        }


class AssigningForm(forms.ModelForm):
    class Meta:
        model = Assigning
        exclude = []
        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly'}),
        }


class HouseForm(forms.ModelForm):
    class Meta:
        model = House
        exclude = ['draft']

        widgets = {
            'address': forms.TextInput(attrs={'class': 'require'}),
            'house_type': forms.TextInput(attrs={'class': 'require'}),
            'lat': forms.HiddenInput(),
            'lon': forms.HiddenInput(),
            'creator': forms.HiddenInput(),
        }


class FirmWastesOneForm(forms.ModelForm):
    class Meta:
        model = FirmWastes
        exclude = ['fkko', 'firm', 'active', 'name']
        widgets = {
            'waste_total_post': forms.TextInput(attrs={'readonly': True}),
            'waste_total_get': forms.TextInput(attrs={'readonly': True}),
            'waste_end_period': forms.TextInput(attrs={'readonly': True}),
        }






WasteFormSet = inlineformset_factory(Waste, WasteComponent, exclude=[], extra=1, form=WastesComponentForm)
FirmWasteFormSet = inlineformset_factory(AdjustableWaste, FirmWastes, exclude=[], extra=0, form=FirmWastesForm)
RegisterFormSet = inlineformset_factory(Organization, Assigning, exclude=[], extra=1, form=AssigningForm)



