__author__ = 'Ivan'
from django import forms


class RangeDate(forms.Form):
    date_from = forms.DateField()
    date_to = forms.DateField()
    