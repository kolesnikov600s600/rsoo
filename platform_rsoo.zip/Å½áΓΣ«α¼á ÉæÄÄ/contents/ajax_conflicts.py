# vim:fileencoding=utf-8
import time
from contents.models import Conflict, ContainerPlatform, Settlements, ObjectsTreatment
from django import forms
import datetime
from django.views.generic import View
from rsso.utils import JSONResponseMixin, allowed_action

__author__ = 'Ivan'


json_objects = {
    'platforms': {
        'class':  ContainerPlatform,
        'fields': ['number', 'address', 'mkd', 'lat', 'lon', 'type', 'surface', 'fences',
                   'qty_container', 'capacity_container', 'place_kgm', 'dispose', 'org_1', 'org_1_inn',
                   'org_1_ogrn', 'org_2', 'org_2_inn', 'org_2_ogrn']
    },
    'settlements': {
        'class':  Settlements,
        'fields': ['name', 'address', 'lat', 'lon', 'okato', 'type_object', 'person',
                   'email', 'phone', 'houses', 'people_summer', 'org_1', 'org_1_inn',
                   'org_1_ogrn', 'org_2', 'org_2_inn', 'org_2_ogrn', 'people_winter', 'square']
    },
    'treatments': {
        'class':  ObjectsTreatment,
        'fields': ['address', 'lat', 'lon', 'type1', 'type2', 'type3',
                   'email', 'phone', 'type4', 'type5', 'org_1', 'org_1_inn',
                   'org_1_ogrn']
    }
}


class ConflictForm(forms.ModelForm):
    class Meta:
        model = Conflict
        fields = ['active', 'solved_by']


class ContainerPlatformForm(forms.ModelForm):
    class Meta:
        model = ContainerPlatform
        fields = json_objects['platforms']['fields']


class SettlementsForm(forms.ModelForm):
    class Meta:
        model = Settlements
        fields = json_objects['settlements']['fields']


class ObjectsTreatmentForm(forms.ModelForm):
    class Meta:
        model = ObjectsTreatment
        fields = json_objects['treatments']['fields']


data_forms = {
    'platforms': ContainerPlatformForm,
    'settlements': SettlementsForm,
    'treatments': ObjectsTreatmentForm
}

def get_data(data):
    d = json_objects.get(data['class'])
    cl = d.get('class')
    o = cl.objects_all.get(id=data['id'])
    return d, cl, o


class AjaxConflicts(JSONResponseMixin, View):

    @allowed_action
    def get_actual_conflicts(self, data, request):
        active = False
        if data.get('solved', False):
            active = True
        if data.get('type', False):
            conflicts = Conflict.objects.filter(active=active, conflict_type=data['type'])
        else:
            conflicts = Conflict.objects.filter(active=active)
        arr = []
        for item in conflicts:
            records = item.get_conflicts()
            arr.append({
                'id': item.id,
                'name': u'Конфликт #%s' % item.id,
                'company_id': item.company.id,
                'company_name': item.company.name,
                'conflict_code': item.conflict_type,
                'conflict_name': item.get_conflict_type_display(),
                'solved': item.active,
                'conflict_obtained': time.mktime(item.conflict_obtained.timetuple()),
                'class_objects': records.get('class_objects'),
                'object_original_id':  getattr(getattr(records.get('qs'), 'obj1', None), 'id', None),
                'object_conflict_id':  getattr(getattr(records.get('qs'), 'obj2', None), 'id', None)
            })
        return arr

    @allowed_action
    def solved_conflict(self, data, request):
        if request.user.is_superuser:
            conflict = Conflict.objects.get(id=data['id'])
            conflict.active = True
            conflict.solved_time = datetime.datetime.now()
            conflict.solved_by = request.user
            conflict.save()
        return {'success': 200}

    @allowed_action
    def get_record_data(self, data, request):
        if request.user.is_superuser:
            d, cl, o = get_data(data)
            record = {}
            for i in d['fields']:
                record.update({i: getattr(o, i)})
            return record
        return {'success': 200}

    @allowed_action
    def save_record(self, data, request):
        if request.user.is_superuser:
            d, cl, o = get_data(data)
            form = data_forms.get(data['class'])(data, instance=o)
            form.is_valid()
            form.save()
        return {'success': 200}

    @allowed_action
    def delete_record(self, data, request):
        if request.user.is_superuser:
            d, cl, o = get_data(data)
            o.delete()
        return {'success': 200}

    @allowed_action
    def incorrect_record(self, data, request):
        if request.user.is_superuser:
            d, cl, o = get_data(data)
            o.incorrect = True
            o.save()
        return {'success': 200}
