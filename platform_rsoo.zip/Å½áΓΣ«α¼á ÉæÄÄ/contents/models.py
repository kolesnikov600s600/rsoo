# vim:fileencoding=utf-8
import math
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.db import models
from django.contrib.auth.models import User, UserManager
from multiselectfield import MultiSelectField
from pytils.numeral import get_plural
from rsso.utils import get_file_path
from django.db.models import Q


REQUEST_FORM = (
    ('form_1', u'Список организаций для рассылки запросов'),
    ('form_2', u'Сведения о жилом фонде'),
    ('form_3', u'Сведения о промышленных отходообразователях'),
    ('form_4', u'Сведения о контейнерных площадках'),
    ('form_5', u'Сведения о контейнерах'),
    ('form_6', u'Сведения о мусоропроводах'),
    ('form_7', u'Сведения о договорах на вывоз отходов'),
    ('form_8', u'Сведения о транспортных средствах'),
    ('form_9', u'Сведения о транспортных базах'),
    ('form_10', u'Сведения о маршрутах вывоза'),
    ('form_11', u'Сведения о штатном расписании'),
    ('form_12', u'Сведения о местах выгрузки отходов'),
    ('form_13', u'Сведения об отходах деятельности организации'),
    ('form_14', u'Нормативно-правовые акты'),
    ('form_15', u'Картографические материалы'),
    ('form_16', u'Объекты обращения для ОМСУ'),
    ('form_17', u'Транспортировщики для ОМСУ'),
    ('form_18', u'Поселения для ОМСУ'),
    ('form_19', u'Организации-отходообразователи для ОМСУ'),
    ('form_20', u'Площадки для ОМСУ'),
    ('form_21', u'Здания и помещения для ЮЛ'),
    ('form_22', u'Площадки для ЮЛ'),
    ('form_23', u'Договоры для ЮЛ'),
    ('form_24', u'Образуемые отходы для КО'),
    ('form_25', u'Здания и помещения для КО'),
    ('form_26', u'Площадки для КО'),
    ('form_27', u'Дома для УК'),
    ('form_28', u'Организации-отходообразователи для УК'),
    ('form_29', u'Площадки для УК'),
    ('form_30', u'Договоры на вывоз для УК'),
)

STATUS_WEB = (
    ('request_created', u'Запрос создан'),
    ('request_send', u'Запрос отправлен'),
    ('request_accept', u'Запрос принят'),
    ('form_fill', u'Заполнение форм'),
    ('form_filled', u'Формы заполнены'),
)

STATUS_DOC = (
    ('request_created', u'Запрос создан'),
    ('request_printed', u'Запрос распечатан'),
    ('request_send', u'Запрос отправлен'),
    ('get_response', u'Получен ответ'),
    ('response_processed', u'Ответ обработан'),
    ('no_request', u'Запрос не требуется'),
)


def get_nearby_points(obj, class_name, dist=0.3):
    lon = float(obj.lon)
    lat = float(obj.lat)
    lon1 = lon-dist/abs(math.cos(math.radians(lat))*111.0)
    lon2 = lon+dist/abs(math.cos(math.radians(lat))*111.0)
    lat1 = lat-(dist/111.0)
    lat2 = lat+(dist/111.0)
    points = class_name.objects.filter(Q(lat__range=(lat1, lat2)) & Q(lon__range=(lon1, lon2)))
    return points


class File(models.Model):
    title = models.CharField(max_length=60, blank=True, null=True)
    file = models.FileField(upload_to=get_file_path)
    creator = models.ForeignKey(User, related_name='file_creator', blank=True, null=True)

    def __unicode__(self):
        return self.file.name


class ProfileForm(models.Model):
    form_name = models.CharField(choices=REQUEST_FORM, max_length=255)
    user = models.ForeignKey(User, related_name='request_forms')

    def __unicode__(self):
        return self.user.get_full_name()


class Profile(models.Model):
    user = models.OneToOneField(User, related_name='profile')
    password = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=255, blank=True, null=True)
    sign = models.BooleanField(default=False)

    def __unicode__(self):
        return self.user.get_full_name()

    def wastes_active(self):
        return self.user.wastes_creator.filter(active=True)


class AddressAssign(models.Model):
    class Meta():
        verbose_name = u'Адрес по ИНН'
        verbose_name_plural = u'Адреса по ИНН'

    address = models.CharField(verbose_name=u'Адрес', max_length=255)
    inn = models.CharField(verbose_name=u'ИНН', max_length=255)
    name = models.CharField(verbose_name=u'Название', max_length=255, blank=True, null=True)
    branch = models.CharField(verbose_name=u'Вид деятельности', max_length=255, blank=True, null=True)
    volume = models.CharField(verbose_name=u'Объем потребления', max_length=255, blank=True, null=True)

    def __unicode__(self):
        return u'%s - %s' % (self.address, self.inn)


class OrganizationCategory(models.Model):
    class Meta():
        verbose_name = u'Категории для организации'
        verbose_name_plural = u'Категории для организации'
        ordering = ['sort']

    name = models.CharField(verbose_name=u'Название', max_length=255)
    sort = models.IntegerField(verbose_name=u'Приоритет', default=0)

    def __unicode__(self):
        return self.name


class Organization(models.Model):
    class Meta():
        verbose_name = u'Организация'
        verbose_name_plural = u'Организации'
        ordering = ['-date']

    name = models.CharField(verbose_name=u'Название', max_length=255)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    category = models.ForeignKey(OrganizationCategory, related_name='organizations', verbose_name=u'Категория')
    email = models.EmailField(verbose_name=u'E-mail')
    phone = models.CharField(verbose_name=u'Телефон', max_length=255)
    comment = models.CharField(verbose_name=u'Заметка для разработчика схемы', max_length=255, blank=True, null=True)
    inn = models.CharField(verbose_name=u'ИНН', max_length=255, blank=True, null=True)
    bin = models.CharField(verbose_name=u'ОГРН', max_length=255, blank=True, null=True)
    kpp = models.CharField(verbose_name=u'КПП', max_length=255, blank=True, null=True)
    okved = models.CharField(verbose_name=u'ОКВЭД', max_length=255, blank=True, null=True)
    director = models.CharField(verbose_name=u'ФИО директора', max_length=255, blank=True, null=True)
    address = models.TextField(verbose_name=u'Адрес', blank=True, null=True)
    creator = models.ForeignKey(User, related_name='organizations_creator')
    access = models.ManyToManyField(User, related_name='organizations_access')
    status_web = models.CharField(choices=STATUS_WEB, max_length=255, blank=True, null=True)
    status_doc = models.CharField(choices=STATUS_DOC, max_length=255, blank=True, null=True)
    request_user = models.ForeignKey(User, related_name='request_users', blank=True, null=True)
    request_web = models.BooleanField(verbose_name=u'Отправить электронный запрос', default=False)
    request_doc = models.BooleanField(verbose_name=u'Отправить бумажный запрос', default=False)
    request_send = models.BooleanField(verbose_name=u'Отправить запросы сразу после создания организации', default=False)
    registered = models.BooleanField(verbose_name=u'Зарегистрирована самостоятелльно', default=False)
    contract = models.BooleanField(verbose_name=u'Наличие прямого договора с транспортировщиком на вывоз отходов', default=False)

    def __unicode__(self):
        return self.name

    def get_request_user(self):
        if not self.request_user:
            qs = User.objects.filter(username=self.email)
            if qs.count() > 0:
                return qs[0]
            return None
        else:
            return self.request_user

    def get_status(self):
        class_name = ''
        if self.status_web == 'request_created' or self.status_doc == 'request_created':
            class_name = 'attempt'
        if self.status_web == 'request_send' or self.status_doc == 'request_printed':
            class_name = 'orange'
        if self.status_web == 'request_accept' or self.status_doc == 'request_send':
            class_name = 'error'
        if self.status_web == 'form_fill' or self.status_doc == 'get_response':
            class_name = 'blue'
        if self.status_web == 'form_filled' or self.status_doc == 'response_processed':
            class_name = 'success'
        return class_name

    def change_email(self):
        if self.request_user:
            if self.email != self.request_user.email:
                users = User.objects.filter(username=self.email)
                if users.exists():
                    self.request_user = users[0]
                    self.save()
                else:
                    self.request_user.email = self.email
                    self.request_user.username = self.email
                    self.request_user.save()

    def send_request(self, email=None, subject=None):
        password = ''
        users = User.objects.filter(username=self.email)
        if self.request_user:
            u = self.request_user
            if self.email != u.email and not users.exists():
                u.email = self.email
                u.username = self.email
                u.save()
        else:
            if users.exists():
                u = users[0]
                if not getattr(u, 'profile', False):
                    password = User.objects.make_random_password()
                    u.set_password(password)
                    Profile.objects.create(user=u, password=password, phone=self.phone)
                    u.save()
            else:
                password = User.objects.make_random_password()
                u = User.objects.create_user(self.email, self.email, password, **{'first_name': self.director})
                Profile.objects.create(user=u, password=password, phone=self.phone)
            self.request_user = u
        # self.access.add(u)
        ProfileForm.objects.filter(user=u).delete()
        for f in self.forms.all():
            ProfileForm.objects.create(user=u, form_name=f.form_name)
        if self.request_web:
            html = render_to_string('organizations/email-request.html', {'item': self, 'user': u, 'password': u.profile.password})
            if email and subject:
                msg = EmailMessage(subject, html, 'othody@xxxxxxxx.ru', email, headers={})
            else:
                msg = EmailMessage(u'Запрос на заполнение документов', html, 'othody@xxxxxxxx.ru', ['zloi.gremlin@gmail.com', '9080536@mail.ru'], headers={})
            msg.content_subtype = "html"
            msg.send()
            self.status_web = 'request_send'
            self.request_web = False
        doc = False
        if self.request_doc:
            self.status_doc = 'request_created'
            doc = {'name_doc': self.name}
            self.request_doc = False
        self.save()
        return {'send': True, 'document': doc}

    def create_wastes(self):
        if self.category.id == 8:
            u = self.get_request_user()
            okved = self.okved
            codes = [u'73310001724', u'47110101521', u'48120302524', u'73510001725', u'73510002725']

            for code in codes:
                active = False
                if code == u'73100000000':
                    active = True
                tko = FKKO.objects.get(code=code)
                ex = u.wastes_creator.filter(fkko=tko)
                if not ex.exists():
                    Waste.objects.create(
                        creator=u,
                        fkko=tko,
                        active=active
                    )
            types = self.assigment.all().values_list('name', flat=True)
            q = Q(fkko__isnull=False) & Q(Q(okved=okved, name__in=types) | Q(okved=okved, name__isnull=True) | Q(okved=okved, name='') | Q(okved__isnull=True, name__in=types) | Q(okved='', name__in=types))
            qs = RelatesWastes.objects.filter(q).distinct()
            for i in qs:
                ex = u.wastes_creator.filter(fkko=i.fkko)
                if not ex.exists():
                    Waste.objects.create(
                        creator=u,
                        fkko=i.fkko,
                        active=False
                    )



class RequestForm(models.Model):
    form_name = models.CharField(choices=REQUEST_FORM, max_length=255)
    deadline = models.IntegerField(verbose_name=u'Срок (дней)', default=3)
    comment = models.CharField(verbose_name=u'Комментарий', max_length=255, blank=True, null=True)
    organization = models.ForeignKey(Organization, related_name='forms')


class TransportBrand(models.Model):
    name = models.CharField(verbose_name=u'Название', max_length=255)

    def __unicode__(self):
        return self.name


class Transport(models.Model):
    class Meta():
        verbose_name = u'Транспорт'
        verbose_name_plural = u'Транспорт'
        ordering = ['-date']

    brand = models.ForeignKey(TransportBrand, verbose_name=u'Марка', related_name='transport')
    model = models.CharField(verbose_name=u'Модель', max_length=255)
    number = models.CharField(verbose_name=u'Государственный номер', max_length=9)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    vin_number = models.CharField(verbose_name=u'VIN-номер', max_length=17)
    equipment = models.CharField(verbose_name=u'Тип навесного оборудования', max_length=255)
    year = models.CharField(verbose_name=u'Год выпуска', max_length=255)
    mileage = models.CharField(verbose_name=u'Общий пробег', max_length=255)
    status = models.CharField(verbose_name=u'Техническое состояние', max_length=255)
    euro = models.CharField(verbose_name=u'Соответствие Евро-стандарту', max_length=255)
    capacity = models.CharField(verbose_name=u'Вместимость', max_length=255)
    carrying_capacity = models.CharField(verbose_name=u'Грузоподъемность', max_length=255)
    reasons_use = models.CharField(verbose_name=u'Основания для использования', max_length=255)
    intensity = models.CharField(verbose_name=u'Интенсивность использования', max_length=255)
    gps = models.CharField(verbose_name=u'Наличие блока мониторинга ТС', max_length=255)
    gps_model = models.CharField(verbose_name=u'Модель блока мониторинга ТС', max_length=255)
    gps_firm = models.CharField(verbose_name=u'Организация, обслуживающая блок мониторинга', max_length=255)
    creator = models.ForeignKey(User, related_name='transport_creator', blank=True, null=True)

    def __unicode__(self):
        return '%s %s' % (self.brand, self.model)

    def get_sub_name(self):
        return self.number


class Staffing(models.Model):
    class Meta():
        verbose_name = u'Штат'
        verbose_name_plural = u'Штат'
        ordering = ['-date']

    job = models.CharField(verbose_name=u'Должность', max_length=255)
    qty_staff = models.IntegerField(verbose_name=u'Количество штатных сотрудников')
    qty_out = models.IntegerField(verbose_name=u'Количество внештатных сотрудников')
    money = models.CharField(verbose_name=u'Средние затраты на содержание сотрудника (рублей в месяц)', max_length=255)
    comment = models.CharField(verbose_name=u'Комментарии (при желании)', max_length=255, blank=True, null=True)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='staff_creator', blank=True, null=True)

    def __unicode__(self):
        return self.job

    def get_sub_name(self):
        return "%s/%s" % (get_plural(self.qty_staff, [u'штатный', u'штатных', u'штатных']), get_plural(self.qty_out, [u'внештатный', u'внештатных', u'внештатных']))


class Instruction(models.Model):
    class Meta():
        verbose_name = u'Инструкция'
        verbose_name_plural = u'Инструкции'
        ordering = ['sort']

    name = models.CharField(verbose_name=u'Заголовок', max_length=255)
    text = models.TextField(verbose_name=u'Описание')
    sort = models.IntegerField(verbose_name=u'Приоритет', default=0)
    forms = MultiSelectField(choices=REQUEST_FORM, blank=True, null=True)

    def __unicode__(self):
        return self.name


class IncorrectManager(models.Manager):
    def get_queryset(self):
        return super(IncorrectManager, self).get_queryset().filter(incorrect=False)


class AllManager(models.Manager):
    def get_queryset(self):
        return super(AllManager, self).get_queryset()


class ContainerPlatform(models.Model):
    class Meta():
        verbose_name = u'Площадка'
        verbose_name_plural = u'Площадки'
        ordering = ['-date']

    number = models.CharField(verbose_name=u'Номер контейнерной площадки', max_length=255, blank=True, null=True)
    address = models.CharField(verbose_name=u'Адрес ближайшего дома', max_length=255)
    mkd = models.CharField(verbose_name=u'Совместное использование с МКД', max_length=255, blank=True, null=True)
    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    type = models.CharField(verbose_name=u'Вид площадки', max_length=255, blank=True, null=True)
    surface = models.CharField(verbose_name=u'Тип поверхности', max_length=255, blank=True, null=True)
    fences = models.CharField(verbose_name=u'Тип ограждения', max_length=255, blank=True, null=True)
    qty_container = models.IntegerField(verbose_name=u'Количество контейнеров', blank=True, null=True)
    capacity_container = models.CharField(verbose_name=u'Вместимость каждого контейнера', max_length=255, blank=True, null=True)
    place_kgm = models.CharField(verbose_name=u'Наличие места для КГМ', max_length=255, blank=True, null=True)
    dispose = models.CharField(verbose_name=u'Утилизируемость отходов', max_length=255, blank=True, null=True)
    org_1 = models.CharField(verbose_name=u'Организация, эксплуатирующая площадку', max_length=255, blank=True, null=True)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)
    org_2 = models.CharField(verbose_name=u'Организация-балансодержатель площадки', max_length=255, blank=True, null=True)
    org_2_inn = models.CharField(verbose_name=u'Организация 2 ИНН', max_length=255, blank=True, null=True)
    org_2_ogrn = models.CharField(verbose_name=u'Организация 2 ОГРН', max_length=255, blank=True, null=True)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='platform_creator', blank=True, null=True)
    comment = models.CharField(verbose_name=u'Комментарии (при желании)', max_length=255, blank=True, null=True)
    draft = models.BooleanField(default=False, verbose_name=u'Черновик')
    incorrect = models.BooleanField(default=False, verbose_name=u'Не верна')
    objects = IncorrectManager()
    objects_all = AllManager()

    def __unicode__(self):
        return u'Контейнерная площадка №%s' % self.number

    def get_contracts(self):
        if self.contract.count() > 0:
            return [int(item) for item in self.contract.prefetch_related('contract').values_list('pk', flat=True)]
        return []


class Container(models.Model):
    class Meta():
        verbose_name = u'Контейнер'
        verbose_name_plural = u'Контейнеры'
        ordering = ['number']

    number = models.CharField(verbose_name=u'Номер контейнера', max_length=4)
    material = models.CharField(verbose_name=u'Материал контейнера', max_length=255, blank=True, null=True)
    capacity = models.FloatField(verbose_name=u'Вместимость контейнера')
    org_1 = models.CharField(verbose_name=u'Организация-балансодержатель', max_length=255, blank=True, null=True)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)
    org_2 = models.CharField(verbose_name=u'Обслуживающая организация', max_length=255, blank=True, null=True)
    org_2_inn = models.CharField(verbose_name=u'Организация 2 ИНН', max_length=255, blank=True, null=True)
    org_2_ogrn = models.CharField(verbose_name=u'Организация 2 ОГРН', max_length=255, blank=True, null=True)
    container = models.ForeignKey(ContainerPlatform, related_name='containers', blank=True, null=True)
    dispose = models.CharField(verbose_name=u'Утилизируемость отходов', max_length=255, blank=True, null=True)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='container_creator', blank=True, null=True)

    def __unicode__(self):
        return u'Контейнер %s' % self.number

    def get_fill(self):
        return (float(self.capacity)/10.00)*100


class Base(models.Model):
    class Meta():
        verbose_name = u'База'
        verbose_name_plural = u'Базы'
        ordering = ['-date']

    name = models.CharField(verbose_name=u'Внутреннее наименование базы', max_length=255)
    address = models.CharField(verbose_name=u'Адрес базы', max_length=255)
    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    qty_cars = models.FloatField(verbose_name=u'Количество машино-мест', blank=True, null=True)
    area = models.CharField(verbose_name=u'Общая площадь', max_length=255, blank=True, null=True)
    service = models.CharField(verbose_name=u'Наличие условий для ремонта', max_length=255, blank=True, null=True)
    reasons_use = models.CharField(verbose_name=u'Основание для использования', max_length=255, blank=True, null=True)
    org_1 = models.CharField(verbose_name=u'Организация, эксплуатирующая площадку', max_length=255, blank=True, null=True)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)
    org_2 = models.CharField(verbose_name=u'Организация-балансодержатель базы', max_length=255, blank=True, null=True)
    org_2_inn = models.CharField(verbose_name=u'Организация 2 ИНН', max_length=255, blank=True, null=True)
    org_2_ogrn = models.CharField(verbose_name=u'Организация 2 ОГРН', max_length=255, blank=True, null=True)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='base_creator', blank=True, null=True)

    def __unicode__(self):
        return self.name

    def get_sub_name(self):
        return self.address


class UnloadingPoint(models.Model):
    class Meta():
        verbose_name = u'Пункт выгрузки'
        verbose_name_plural = u'Пункты выгрузки'
        ordering = ['-date']

    address = models.CharField(verbose_name=u'Адрес места выгрузки', max_length=255)
    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    org_1 = models.CharField(verbose_name=u'Наименование организации', max_length=255, blank=True, null=True)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)
    deadline_doc = models.DateField(verbose_name=u'Срок договора на выгрузку', blank=True, null=True)
    number_doc = models.CharField(verbose_name=u'Номер договора на выгрузку', max_length=255, blank=True, null=True)
    date_doc = models.DateField(verbose_name=u'Дата договора на выгрузку', blank=True, null=True)
    limit = models.CharField(verbose_name=u'Лимит выгрузки', max_length=255, blank=True, null=True)
    limit_mesure = models.CharField(verbose_name=u'Единица измерения', max_length=255, blank=True, null=True)

    capacity_1 = models.CharField(verbose_name=u'Объем отходов 1', max_length=255, blank=True, null=True)
    capacity_2 = models.CharField(verbose_name=u'Объем отходов 2', max_length=255, blank=True, null=True)
    capacity_3 = models.CharField(verbose_name=u'Объем отходов 3', max_length=255, blank=True, null=True)

    tariff_1 = models.CharField(verbose_name=u'Тариф 1', max_length=255, blank=True, null=True)
    tariff_2 = models.CharField(verbose_name=u'Тариф 2', max_length=255, blank=True, null=True)
    tariff_3 = models.CharField(verbose_name=u'Тариф 3', max_length=255, blank=True, null=True)

    total_1 = models.CharField(verbose_name=u'Сумма 1', max_length=255, blank=True, null=True)
    total_2 = models.CharField(verbose_name=u'Сумма 2', max_length=255, blank=True, null=True)
    total_3 = models.CharField(verbose_name=u'Сумма 3', max_length=255, blank=True, null=True)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='point_creator', blank=True, null=True)

    def __unicode__(self):
        return self.address

    def get_sub_name(self):
        return u''


class ObjectsTreatment(models.Model):
    class Meta():
        verbose_name = u'Объекты обращения для ОМСУ'
        verbose_name_plural = u'Объекты обращения для ОМСУ'
        ordering = ['-date']

    address = models.CharField(verbose_name=u'Адрес', max_length=255)

    org_1 = models.CharField(verbose_name=u'Организация', max_length=255)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)

    email = models.EmailField(verbose_name=u'E-mail', blank=True, null=True)
    phone = models.CharField(verbose_name=u'Телефон', max_length=255, blank=True, null=True)

    type1 = models.BooleanField(verbose_name=u'Обработка отходов', default=False)
    type2 = models.BooleanField(verbose_name=u'Утилизация отходов', default=False)
    type3 = models.BooleanField(verbose_name=u'Обезвреживание отходов', default=False)
    type4 = models.BooleanField(verbose_name=u'Хранение отходов', default=False)
    type5 = models.BooleanField(verbose_name=u'Захоронение отходов', default=False)

    comment = models.CharField(verbose_name=u'Комментарии (при желании)', max_length=255, blank=True, null=True)

    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='treatment_creator', blank=True, null=True)

    draft = models.BooleanField(default=False, verbose_name=u'Черновик')

    incorrect = models.BooleanField(default=False, verbose_name=u'Не верна')
    objects = IncorrectManager()
    objects_all = AllManager()

    def __unicode__(self):
        return self.org_1

    def get_sub_name(self):
        return self.address


class Transporters(models.Model):
    class Meta():
        verbose_name = u'Транспортировщики для ОМСУ'
        verbose_name_plural = u'Транспортировщики для ОМСУ'
        ordering = ['-date']

    org_1 = models.CharField(verbose_name=u'Организация', max_length=255)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)
    address = models.CharField(verbose_name=u'Адрес', max_length=255)

    email = models.EmailField(verbose_name=u'E-mail', blank=True, null=True)
    phone = models.CharField(verbose_name=u'Телефон', max_length=255, blank=True, null=True)

    comment = models.CharField(verbose_name=u'Комментарии (при желании)', max_length=255, blank=True, null=True)

    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='transporters_creator', blank=True, null=True)

    draft = models.BooleanField(default=False, verbose_name=u'Черновик')

    def __unicode__(self):
        return self.org_1

    def get_sub_name(self):
        return self.address


class Settlements(models.Model):
    class Meta():
        verbose_name = u'Поселения для ОМСУ'
        verbose_name_plural = u'Поселения для ОМСУ'
        ordering = ['-date']

    name = models.CharField(verbose_name=u'Название', max_length=255)
    address = models.CharField(verbose_name=u'Адрес', max_length=255)
    okato = models.CharField(verbose_name=u'ОКАТО или ОКТМО', max_length=255)
    type_object = models.CharField(verbose_name=u'Тип объекта', max_length=255)

    org_1 = models.CharField(verbose_name=u'Лицо, осуществляющее управление объектом', help_text=u'УК, ТСЖ, ЖСК, администрация, иное', max_length=255)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)

    person = models.CharField(verbose_name=u'ФИО контактного лица', max_length=255, blank=True, null=True)

    email = models.EmailField(verbose_name=u'E-mail', blank=True, null=True)
    phone = models.CharField(verbose_name=u'Телефон', max_length=255, blank=True, null=True)

    houses = models.CharField(verbose_name=u'Количество домов', max_length=255)
    people_summer = models.CharField(verbose_name=u'Количество проживающих Весна-лето', max_length=255)
    people_winter = models.CharField(verbose_name=u'Количество проживающих Осень-зима', max_length=255)
    square = models.CharField(verbose_name=u'Общая площадь домов', max_length=255, blank=True, null=True)

    org_2 = models.CharField(verbose_name=u'Транспортировщик отходов', max_length=255, blank=True, null=True)
    org_2_inn = models.CharField(verbose_name=u'Организация 2 ИНН', max_length=255, blank=True, null=True)
    org_2_ogrn = models.CharField(verbose_name=u'Организация 2 ОГРН', max_length=255, blank=True, null=True)

    comment = models.CharField(verbose_name=u'Комментарии (при желании)', max_length=255, blank=True, null=True)

    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='settlements_creator', blank=True, null=True)

    draft = models.BooleanField(default=False, verbose_name=u'Черновик')

    incorrect = models.BooleanField(default=False, verbose_name=u'Не верна')
    objects = IncorrectManager()
    objects_all = AllManager()

    def __unicode__(self):
        return self.name

    def get_sub_name(self):
        return self.address


class AdjustableWaste(models.Model):
    class Meta():
        verbose_name = u'Организации-отходообразователи для ОМСУ'
        verbose_name_plural = u'Организации-отходообразователи для ОМСУ'
        ordering = ['-date']

    address = models.CharField(verbose_name=u'Адрес', max_length=255)
    org_1 = models.CharField(verbose_name=u'Организация', max_length=255, blank=True, null=True)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)

    building = models.CharField(verbose_name=u'Здание или помещение', blank=True, null=True, max_length=255)
    number = models.CharField(verbose_name=u'Номер офиса/торговой точки', max_length=255, blank=True, null=True)
    reasons_use = models.CharField(verbose_name=u'Основание для использования', max_length=255, blank=True, null=True)
    org_2 = models.CharField(verbose_name=u'Собственник/арендодатель', max_length=255, blank=True, null=True)
    org_2_inn = models.CharField(verbose_name=u'Организация 2 ИНН', max_length=255, blank=True, null=True)
    org_2_ogrn = models.CharField(verbose_name=u'Организация 2 ОГРН', max_length=255, blank=True, null=True)
    agreement = models.CharField(verbose_name=u'Номер договора аренды', blank=True, null=True, max_length=255)
    date_agreement = models.CharField(verbose_name=u'Дата договора аренды', blank=True, null=True, max_length=255)

    category = models.CharField(verbose_name=u'Категория организации', max_length=255)

    tko = models.CharField(verbose_name=u'Вывоз ТКО осуществляется', blank=True, null=True, max_length=255)

    org_3 = models.CharField(verbose_name=u'Транспортировщик ТКО', max_length=255, blank=True, null=True)
    org_3_inn = models.CharField(verbose_name=u'Организация 3 ИНН', max_length=255, blank=True, null=True)
    org_3_ogrn = models.CharField(verbose_name=u'Организация 3 ОГРН', max_length=255, blank=True, null=True)

    email = models.EmailField(verbose_name=u'E-mail', blank=True, null=True)
    phone = models.CharField(verbose_name=u'Телефон', max_length=255, blank=True, null=True)

    square = models.CharField(verbose_name=u'Площадь помещения (кв.м.)', max_length=255, blank=True, null=True)
    people = models.CharField(verbose_name=u'Количество сотрудников', max_length=255, blank=True, null=True)
    qty = models.CharField(max_length=255, blank=True, null=True)

    comment = models.CharField(verbose_name=u'Комментарии (при желании)', max_length=255, blank=True, null=True)

    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='waste_creator', blank=True, null=True)
    own = models.BooleanField(default=False)

    draft = models.BooleanField(default=False, verbose_name=u'Черновик')

    def __unicode__(self):
        if not self.own:
            if self.org_1:
                return self.org_1
            else:
                return self.address
        else:
            return self.category

    def get_sub_name(self):
        return self.address

    def get_contracts(self):
        if self.contract.count() > 0:
            return [int(item) for item in self.contract.prefetch_related('contract').values_list('pk', flat=True)]
        if self.garbage_contracts.count() > 0:
            return [int(item) for item in self.garbage_contracts.prefetch_related('garbage_contracts').values_list('pk', flat=True)]
        return []


class House(models.Model):
    class Meta():
        verbose_name = u'Дом'
        verbose_name_plural = u'Дома'
        ordering = ['-date']

    address = models.CharField(verbose_name=u'Адрес дома', max_length=255)
    house_type = models.CharField(verbose_name=u'Тип дома', blank=True, null=True, max_length=255, default=u'МКД')
    qty_chute = models.CharField(verbose_name=u'Количество мусоропроводов', blank=True, null=True, max_length=255)
    qty_people = models.CharField(verbose_name=u'Количество проживающих', blank=True, null=True, max_length=255)

    square_1 = models.CharField(verbose_name=u'Площадь жилая (кв.м.)', max_length=255, blank=True, null=True)
    square_2 = models.CharField(verbose_name=u'Площадь нежилая (кв.м.)', max_length=255, blank=True, null=True)
    square_3 = models.CharField(verbose_name=u'Площадь всего (кв.м.)', max_length=255, blank=True, null=True)

    norm = models.CharField(verbose_name=u'Норматив образования ТКО', max_length=255, blank=True, null=True)
    norm_measure = models.CharField(verbose_name=u'Единица измерения', max_length=255, blank=True, null=True)

    fact = models.CharField(verbose_name=u'Фактическое кол-во ТКО за 2015', max_length=255, blank=True, null=True)
    fact_measure = models.CharField(verbose_name=u'Ед. измерения', max_length=255, blank=True, null=True)

    lat = models.DecimalField(verbose_name=u'Широта', max_digits=9, decimal_places=6)
    lon = models.DecimalField(verbose_name=u'Долгота', max_digits=9, decimal_places=6)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='house_creator', blank=True, null=True)

    draft = models.BooleanField(default=False, verbose_name=u'Черновик')

    def __unicode__(self):
        return self.address

    def get_sub_name(self):
        return self.house_type

    def get_contracts(self):
        if self.garbage_contracts.count() > 0:
            return [int(item) for item in self.garbage_contracts.prefetch_related('garbage_contracts').values_list('pk', flat=True)]
        return []


class FKKO(models.Model):
    class Meta():
        verbose_name = u'Классификатор'
        verbose_name_plural = u'Классификатор'
        ordering = ['-code']

    code = models.CharField(verbose_name=u'Код', max_length=255)
    name = models.CharField(verbose_name=u'Наименование', max_length=255)
    hazard_class = models.CharField(verbose_name=u'Класс', max_length=255)
    form = models.CharField(verbose_name=u'Агрегатное состояние и физическая форма', max_length=255)

    def __unicode__(self):
        return self.code


class Contract(models.Model):
    class Meta():
        verbose_name = u'Договор'
        verbose_name_plural = u'Договора'
        ordering = ['-date']

    org_1 = models.CharField(verbose_name=u'Организация', max_length=255)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)

    number = models.CharField(verbose_name=u'Номер договора', max_length=255)
    contract_date = models.DateField(verbose_name=u'Дата договора',)

    fkko = models.ForeignKey(FKKO, verbose_name=u'Вид отходов по ФККО', related_name='contract', blank=True, null=True)
    hazard_class = models.CharField(verbose_name=u'Класс опасности', max_length=255, blank=True, null=True)

    periodicity = models.CharField(verbose_name=u'Частота вывоза отходов в неделю', max_length=255, blank=True, null=True)
    measure = models.CharField(verbose_name=u'Единица измеренеия в договоре', max_length=255, blank=True, null=True)

    capacity_1 = models.CharField(verbose_name=u'Объем отходов 1', max_length=255, blank=True, null=True)
    capacity_2 = models.CharField(verbose_name=u'Объем отходов 2', max_length=255, blank=True, null=True)
    capacity_3 = models.CharField(verbose_name=u'Объем отходов 3', max_length=255, blank=True, null=True)

    tariff_1 = models.CharField(verbose_name=u'Тариф 1', max_length=255, blank=True, null=True)
    tariff_2 = models.CharField(verbose_name=u'Тариф 2', max_length=255, blank=True, null=True)
    tariff_3 = models.CharField(verbose_name=u'Тариф 3', max_length=255, blank=True, null=True)

    total_1 = models.CharField(verbose_name=u'Сумма 1', max_length=255, blank=True, null=True)
    total_2 = models.CharField(verbose_name=u'Сумма 2', max_length=255, blank=True, null=True)
    total_3 = models.CharField(verbose_name=u'Сумма 3', max_length=255, blank=True, null=True)

    file = models.ManyToManyField(File, verbose_name=u'Файлы', related_name='contracts', blank=True)
    platforms = models.ManyToManyField(ContainerPlatform, verbose_name=u'Платформы', related_name='contract', blank=True)
    firms = models.ManyToManyField(AdjustableWaste, verbose_name=u'Организации', related_name='contract', blank=True)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='contract_creator', blank=True, null=True)

    def __unicode__(self):
        return u'Договор %s от %s' % (self.number, self.contract_date.strftime('%d.%m.%Y'))

    def get_sub_name(self):
        return u'с %s' % self.org_1


class ContractGarbage(models.Model):
    class Meta():
        verbose_name = u'Договор на вывоз мусора'
        verbose_name_plural = u'Договора на вывоз мусора'
        ordering = ['-date']

    number = models.CharField(verbose_name=u'Номер договора', max_length=255)
    number_normalize = models.CharField(verbose_name=u'Номер договора', max_length=255, blank=True, null=True)
    contract_date = models.DateField(verbose_name=u'Дата договора',)

    org_1 = models.CharField(verbose_name=u'Заказчик', max_length=255)
    org_1_inn = models.CharField(verbose_name=u'Организация 1 ИНН', max_length=255, blank=True, null=True)
    org_1_ogrn = models.CharField(verbose_name=u'Организация 1 ОГРН', max_length=255, blank=True, null=True)

    tariff = models.CharField(verbose_name=u'Тариф', max_length=255, blank=True, null=True)
    measure = models.CharField(verbose_name=u'Единица измеренеия в договоре', max_length=255, blank=True, null=True)

    capacity_1 = models.CharField(verbose_name=u'Объем отходов 1', max_length=255, blank=True, null=True)
    capacity_2 = models.CharField(verbose_name=u'Объем отходов 2', max_length=255, blank=True, null=True)
    capacity_3 = models.CharField(verbose_name=u'Объем отходов 3', max_length=255, blank=True, null=True)

    tariff_1 = models.CharField(verbose_name=u'Тариф 1', max_length=255, blank=True, null=True)
    tariff_2 = models.CharField(verbose_name=u'Тариф 2', max_length=255, blank=True, null=True)
    tariff_3 = models.CharField(verbose_name=u'Тариф 3', max_length=255, blank=True, null=True)

    total_1 = models.CharField(verbose_name=u'Сумма 1', max_length=255, blank=True, null=True)
    total_2 = models.CharField(verbose_name=u'Сумма 2', max_length=255, blank=True, null=True)
    total_3 = models.CharField(verbose_name=u'Сумма 3', max_length=255, blank=True, null=True)

    periodicity = models.CharField(verbose_name=u'Частота вывоза', max_length=255, blank=True, null=True)
    point = models.ForeignKey(UnloadingPoint, verbose_name=u'Место выгрузки отходов ', related_name='unpoints', blank=True, null=True)

    file = models.ManyToManyField(File, verbose_name=u'Файлы', related_name='garbage_contracts', blank=True)
    firms = models.ManyToManyField(AdjustableWaste, verbose_name=u'Организации', related_name='garbage_contracts', blank=True)
    houses = models.ManyToManyField(House, verbose_name=u'Организации', related_name='garbage_contracts', blank=True)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='contract_garbage_creator', blank=True, null=True)

    def __unicode__(self):
        return u'Договор %s от %s' % (self.number, self.contract_date.strftime('%d.%m.%Y'))

    def get_sub_name(self):
        return u'с %s' % self.org_1


class Waste(models.Model):
    class Meta():
        verbose_name = u'Отходы'
        verbose_name_plural = u'Отходы'
        ordering = ['-date']

    fkko = models.ForeignKey(FKKO, verbose_name=u'Вид отходов по ФККО', related_name='wastes')

    compositions = models.BooleanField(default=False, verbose_name=u'Известен компонентный состав отходов')
    appearance = models.CharField(verbose_name=u'Агрегатное состояние и физическая форма', max_length=255, blank=True, null=True)

    passport = models.BooleanField(default=False, verbose_name=u'Разработан паспорт отхода')
    approved = models.BooleanField(default=False, verbose_name=u'Утвержден')
    agreed = models.BooleanField(default=False, verbose_name=u'Согласован')
    date_approved = models.DateField(verbose_name=u'Дата утверждения', blank=True, null=True)
    process_name = models.CharField(verbose_name=u'Наименование технологического процесса', max_length=255, blank=True, null=True)
    product = models.CharField(verbose_name=u'Исходный товар (продукция)', max_length=255, blank=True, null=True)

    active = models.BooleanField(verbose_name=u'Активность', default=True)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='wastes_creator', blank=True, null=True)

    draft = models.BooleanField(default=False, verbose_name=u'Черновик')

    def __unicode__(self):
        return self.fkko.name

    def get_sub_name(self):
        return self.fkko.code

    def get_active_property(self):
        return True


class WasteComponent(models.Model):
    class Meta():
        verbose_name = u'Компонент отходов'
        verbose_name_plural = u'Компоненты отходов'
        ordering = ['date']

    waste = models.ForeignKey(Waste, verbose_name=u'Отход', related_name='wastes')

    name = models.CharField(verbose_name=u'Название компонента', max_length=255, blank=True, null=True)
    mass = models.CharField(verbose_name=u'Массовая доля', max_length=255, blank=True, null=True)

    active = models.BooleanField(verbose_name=u'Активность', default=False)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)

    def __unicode__(self):
        return u'%s - %s' % (self.name, self.waste.fkko.name)

    def get_sub_name(self):
        return self.fkko.code


class FirmWastes(models.Model):
    class Meta():
        verbose_name = u'Отходы организации'
        verbose_name_plural = u'Отходы организации'
        ordering = ['date']

    firm = models.ForeignKey(AdjustableWaste, verbose_name=u'Компания', related_name='wastes')
    fkko = models.ForeignKey(FKKO, verbose_name=u'Вид отходов по ФККО', related_name='firm_wastes')

    name = models.CharField(verbose_name=u'Объем отходов за 2015 год', max_length=255, blank=True, null=True)

    waste_processed = models.CharField(verbose_name=u'Обработано', max_length=255, blank=True, null=True)
    waste_recycled = models.CharField(verbose_name=u'Утилизировано', max_length=255, blank=True, null=True)
    waste_neutralized = models.CharField(verbose_name=u'Обезврежено', max_length=255, blank=True, null=True)
    waste_storage = models.CharField(verbose_name=u'Хранение', max_length=255, blank=True, null=True)
    waste_landfill = models.CharField(verbose_name=u'Захоронение', max_length=255, blank=True, null=True)
    waste_total_post = models.CharField(verbose_name=u'Всего передано отходов', max_length=255, blank=True, null=True)
    waste_total_get = models.CharField(verbose_name=u'Всего получено отходов', max_length=255, blank=True, null=True)
    waste_end_period = models.CharField(verbose_name=u'Остаток на конец периода', max_length=255, blank=True, null=True)

    active = models.BooleanField(verbose_name=u'Активность', default=False)

    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)

    def __unicode__(self):
        return u'%s' % self.firm.category

    def get_sub_name(self):
        return u'%s / %s <i class="volyear">%s т.</i>' % (self.fkko.name, self.fkko.code, self.name)


class RelatesWastes(models.Model):
    class Meta():
        verbose_name = u'Привязки'
        verbose_name_plural = u'Привязки'

    name = models.CharField(verbose_name=u'Тип организации', blank=True, null=True, max_length=255)
    okved = models.CharField(verbose_name=u'ОКВЭД', max_length=255, blank=True, null=True)
    fkko = models.ForeignKey(FKKO, verbose_name=u'Вид отходов по ФККО', related_name='relate_wastes', blank=True, null=True)

    def __unicode__(self):
        if self.name:
            return self.name
        if self.okved:
            return self.okved
        if self.fkko:
            return self.fkko.code
        return self.id


class Assigning(models.Model):
    class Meta():
        verbose_name = u'Типы помещений'
        verbose_name_plural = u'Типы помещений'

    name = models.CharField(verbose_name=u'Название', max_length=255, blank=True, null=True)
    firm = models.ForeignKey(Organization, verbose_name=u'Организация', related_name='assigment')
    active = models.BooleanField(verbose_name=u'Активность', default=False)

    def __unicode__(self):
        return u'%s - %s' % (self.name, self.firm.name)


class SignedDocuments(models.Model):
    class Meta():
        verbose_name = u'Подписанные документы'
        verbose_name_plural = u'Подписанные документы'

    stribog = models.CharField(verbose_name=u'Хэш', max_length=255)
    date = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    creator = models.ForeignKey(User, related_name='document_creator')

    def __unicode__(self):
        return u'%s - %s' % (self.stribog, self.creator)


CONFLICT_TYPES = (
    ('double_data', u'Одинаковые данные из разных источников'),
    ('similar_data', u'Схожие данные из разных источников'),
    ('no_data', u'Не хватает данных'),
)


class Conflict(models.Model):
    class Meta():
        verbose_name = u'Конфликт'
        verbose_name_plural = u'Конфликты'

    company = models.ForeignKey(Organization, related_name='conflicts', verbose_name=u'Организация')
    conflict_type = models.CharField(verbose_name=u'Тип конфликта', max_length=255, choices=CONFLICT_TYPES)
    active = models.BooleanField(verbose_name=u'Конфликт разрешен', default=False)
    conflict_obtained = models.DateTimeField(verbose_name=u'Дата', auto_now_add=True)
    solved_time = models.DateTimeField(verbose_name=u'Дата решения', blank=True, null=True)
    solved_by = models.ForeignKey(User, related_name='solved_conflicts', blank=True, null=True)

    def __unicode__(self):
        return u'%s - %s' % (self.company.name, self.conflict_type)

    def get_conflicts(self):
        objects = [['conflicts_platforms', 'platforms'], ['conflicts_settles', 'settlements'], ['conflicts_treats', 'treatments']]
        for i in objects:
            if getattr(self, i[0]).all().exists():
                return {'qs': getattr(self, i[0]).all()[0], 'class_objects': i[1]}
        return {'qs': None, 'class_objects': ''}


class ConflictContainer(models.Model):
    class Meta():
        verbose_name = u'Конфликт: Площадки'
        verbose_name_plural = u'Конфликты: Площадки'

    conflict = models.ForeignKey(Conflict, related_name='conflicts_platforms', verbose_name=u'Конфликт')
    obj1 = models.ForeignKey(ContainerPlatform, related_name='conflicts_platforms1', verbose_name=u'Объект 1', blank=True, null=True)
    obj2 = models.ForeignKey(ContainerPlatform, related_name='conflicts_platforms2', verbose_name=u'Объект 2', blank=True, null=True)


class ConflictSettle(models.Model):
    class Meta():
        verbose_name = u'Конфликт: Поселения'
        verbose_name_plural = u'Конфликты: Поселения'

    conflict = models.ForeignKey(Conflict, related_name='conflicts_settles', verbose_name=u'Конфликт')
    obj1 = models.ForeignKey(Settlements, related_name='conflicts_settle1', verbose_name=u'Объект 1', blank=True, null=True)
    obj2 = models.ForeignKey(Settlements, related_name='conflicts_settle2', verbose_name=u'Объект 2', blank=True, null=True)


class ConflictTreat(models.Model):
    class Meta():
        verbose_name = u'Конфликт: Выгрузки'
        verbose_name_plural = u'Конфликты: Выгрузки'

    conflict = models.ForeignKey(Conflict, related_name='conflicts_treats', verbose_name=u'Конфликт')
    obj1 = models.ForeignKey(ObjectsTreatment, related_name='conflicts_treat1', verbose_name=u'Объект 1', blank=True, null=True)
    obj2 = models.ForeignKey(ObjectsTreatment, related_name='conflicts_treat2', verbose_name=u'Объект 2', blank=True, null=True)


class Municipality(models.Model):
    class Meta():
        verbose_name = u'Муниципалитет'
        verbose_name_plural = u'Муниципалитеты'

    name = models.CharField(verbose_name=u'Название', max_length=255)


class MunicipalityAssign(models.Model):
    class Meta():
        verbose_name = u'Конфликт: Выгрузки'
        verbose_name_plural = u'Конфликты: Выгрузки'

    municipality = models.ForeignKey(Municipality, related_name='firms', verbose_name=u'Муниципалитет')
    firm = models.ForeignKey(Transporters, related_name='municipally')

    def __unicode__(self):
        return u'%s - %s' % (self.municipality.name, self.firm.org_1)
