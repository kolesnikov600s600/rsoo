from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver
from contents.models import ContractGarbage
from slugify import slugify


@receiver(post_save, sender=ContractGarbage)
def create_contract_name(sender, instance, **kwargs):
    norm = slugify(instance.number.lower()).replace('-', '')
    if not instance.number_normalize or norm != instance.number_normalize:
        instance.number_normalize = norm
        instance.save()