# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0045_auto_20160220_0913'),
    ]

    operations = [
        migrations.AlterField(
            model_name='contract',
            name='file',
            field=models.ManyToManyField(related_name='contracts', verbose_name='\u0424\u0430\u0439\u043b\u044b', to='contents.File', blank=True),
        ),
    ]
