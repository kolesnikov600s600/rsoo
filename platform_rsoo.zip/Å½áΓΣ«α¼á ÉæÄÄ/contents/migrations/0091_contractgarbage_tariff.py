# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0090_contractgarbage_houses'),
    ]

    operations = [
        migrations.AddField(
            model_name='contractgarbage',
            name='tariff',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444', blank=True),
        ),
    ]
