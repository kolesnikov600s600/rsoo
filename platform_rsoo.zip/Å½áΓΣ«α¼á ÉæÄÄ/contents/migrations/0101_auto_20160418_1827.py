# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0100_containerplatform_incorrect'),
    ]

    operations = [
        migrations.AddField(
            model_name='objectstreatment',
            name='incorrect',
            field=models.BooleanField(default=False, verbose_name='\u041d\u0435 \u0432\u0435\u0440\u043d\u0430'),
        ),
        migrations.AddField(
            model_name='settlements',
            name='incorrect',
            field=models.BooleanField(default=False, verbose_name='\u041d\u0435 \u0432\u0435\u0440\u043d\u0430'),
        ),
    ]
