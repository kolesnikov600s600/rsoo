# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0070_auto_20160319_1704'),
    ]

    operations = [
        migrations.AddField(
            model_name='assigning',
            name='active',
            field=models.BooleanField(default=False, verbose_name='\u0410\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c'),
        ),
    ]
