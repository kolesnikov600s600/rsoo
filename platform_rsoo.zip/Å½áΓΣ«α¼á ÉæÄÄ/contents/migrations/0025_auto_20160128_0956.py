# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0024_unloadingpoint'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='unloadingpoint',
            name='name',
        ),
        migrations.AlterField(
            model_name='base',
            name='org_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f, \u044d\u043a\u0441\u043f\u043b\u0443\u0430\u0442\u0438\u0440\u0443\u044e\u0449\u0430\u044f \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0443', blank=True),
        ),
        migrations.AlterField(
            model_name='base',
            name='org_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f-\u0431\u0430\u043b\u0430\u043d\u0441\u043e\u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043b\u044c \u0431\u0430\u0437\u044b', blank=True),
        ),
        migrations.AlterField(
            model_name='containerplatform',
            name='org_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f, \u044d\u043a\u0441\u043f\u043b\u0443\u0430\u0442\u0438\u0440\u0443\u044e\u0449\u0430\u044f \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0443', blank=True),
        ),
        migrations.AlterField(
            model_name='containerplatform',
            name='org_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f-\u0431\u0430\u043b\u0430\u043d\u0441\u043e\u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043b\u044c \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438', blank=True),
        ),
        migrations.AlterField(
            model_name='transport',
            name='mileage',
            field=models.CharField(max_length=255, verbose_name='\u041e\u0431\u0449\u0438\u0439 \u043f\u0440\u043e\u0431\u0435\u0433'),
        ),
    ]
