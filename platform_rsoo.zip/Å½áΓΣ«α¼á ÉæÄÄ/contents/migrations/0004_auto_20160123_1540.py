# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0003_auto_20160122_2342'),
    ]

    operations = [
        migrations.AddField(
            model_name='organization',
            name='request_doc',
            field=models.BooleanField(default=False, verbose_name='\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u0431\u0443\u043c\u0430\u0436\u043d\u044b\u0439 \u0437\u0430\u043f\u0440\u043e\u0441'),
        ),
        migrations.AddField(
            model_name='organization',
            name='request_send',
            field=models.BooleanField(default=False, verbose_name='\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u0437\u0430\u043f\u0440\u043e\u0441\u044b \u0441\u0440\u0430\u0437\u0443 \u043f\u043e\u0441\u043b\u0435 \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u044f \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438'),
        ),
        migrations.AddField(
            model_name='organization',
            name='request_web',
            field=models.BooleanField(default=False, verbose_name='\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u044d\u043b\u0435\u043a\u0442\u0440\u043e\u043d\u043d\u044b\u0439 \u0437\u0430\u043f\u0440\u043e\u0441'),
        ),
    ]
