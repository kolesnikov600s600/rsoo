# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0018_auto_20160127_0108'),
    ]

    operations = [
        migrations.AlterField(
            model_name='container',
            name='capacity',
            field=models.FloatField(verbose_name='\u0412\u043c\u0435\u0441\u0442\u0438\u043c\u043e\u0441\u0442\u044c \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430'),
        ),
    ]
