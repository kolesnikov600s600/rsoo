# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0071_assigning_active'),
    ]

    operations = [
        migrations.CreateModel(
            name='SignedDocuments',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('stribog', models.CharField(max_length=255, verbose_name='\u0425\u044d\u0448')),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('creator', models.ForeignKey(related_name='document_creator', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': '\u0422\u0438\u043f\u044b \u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0439',
                'verbose_name_plural': '\u0422\u0438\u043f\u044b \u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0439',
            },
        ),
    ]
