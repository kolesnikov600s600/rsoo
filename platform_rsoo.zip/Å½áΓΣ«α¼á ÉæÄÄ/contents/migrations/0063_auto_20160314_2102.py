# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0062_wastecomponent_active'),
    ]

    operations = [
        migrations.RenameField(
            model_name='wastecomponent',
            old_name='address',
            new_name='mass',
        ),
    ]
