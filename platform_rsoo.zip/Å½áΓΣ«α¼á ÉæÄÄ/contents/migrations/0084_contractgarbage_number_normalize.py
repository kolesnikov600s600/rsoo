# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0083_auto_20160405_1105'),
    ]

    operations = [
        migrations.AddField(
            model_name='contractgarbage',
            name='number_normalize',
            field=models.CharField(default=None, max_length=255, verbose_name='\u041d\u043e\u043c\u0435\u0440 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430'),
            preserve_default=False,
        ),
    ]
