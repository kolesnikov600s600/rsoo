# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0077_auto_20160330_1201'),
    ]

    operations = [
        migrations.AddField(
            model_name='unloadingpoint',
            name='limit_mesure',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0415\u0434\u0438\u043d\u0438\u0446\u0430 \u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u044f', blank=True),
        ),
        migrations.AlterField(
            model_name='unloadingpoint',
            name='address',
            field=models.CharField(max_length=255, verbose_name='\u0410\u0434\u0440\u0435\u0441 \u043c\u0435\u0441\u0442\u0430 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0438'),
        ),
        migrations.AlterField(
            model_name='unloadingpoint',
            name='date_doc',
            field=models.DateField(null=True, verbose_name='\u0414\u0430\u0442\u0430 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u043d\u0430 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0443', blank=True),
        ),
        migrations.AlterField(
            model_name='unloadingpoint',
            name='deadline_doc',
            field=models.DateField(null=True, verbose_name='\u0421\u0440\u043e\u043a \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u043d\u0430 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0443', blank=True),
        ),
    ]
