# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0089_adjustablewaste_measure'),
    ]

    operations = [
        migrations.AddField(
            model_name='contractgarbage',
            name='houses',
            field=models.ManyToManyField(related_name='garbage_contracts', verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438', to='contents.House', blank=True),
        ),
    ]
