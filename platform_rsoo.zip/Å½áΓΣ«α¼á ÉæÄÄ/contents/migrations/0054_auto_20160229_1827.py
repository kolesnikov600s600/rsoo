# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0053_auto_20160225_1833'),
    ]

    operations = [
        migrations.AddField(
            model_name='organization',
            name='okved',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u041a\u0412\u042d\u0414', blank=True),
        ),
        migrations.AddField(
            model_name='organization',
            name='registered',
            field=models.BooleanField(default=False, verbose_name='\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043e\u0432\u0430\u043d\u0430 \u0441\u0430\u043c\u043e\u0441\u0442\u043e\u044f\u0442\u0435\u043b\u043b\u044c\u043d\u043e'),
        ),
    ]
