# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0009_auto_20160125_1105'),
    ]

    operations = [
        migrations.AlterField(
            model_name='transport',
            name='number',
            field=models.CharField(max_length=9, verbose_name='\u0413\u043e\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0439 \u043d\u043e\u043c\u0435\u0440'),
        ),
        migrations.AlterField(
            model_name='transport',
            name='vin_number',
            field=models.CharField(max_length=17, verbose_name='VIN-\u043d\u043e\u043c\u0435\u0440'),
        ),
    ]
