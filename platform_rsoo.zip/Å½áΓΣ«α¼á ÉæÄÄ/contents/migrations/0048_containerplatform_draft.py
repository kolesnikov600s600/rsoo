# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0047_auto_20160222_2107'),
    ]

    operations = [
        migrations.AddField(
            model_name='containerplatform',
            name='draft',
            field=models.BooleanField(default=False, verbose_name='\u0427\u0435\u0440\u043d\u043e\u0432\u0438\u043a'),
        ),
    ]
