# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0097_auto_20160418_1532'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='conflictsettle',
            options={'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442: \u041f\u043e\u0441\u0435\u043b\u0435\u043d\u0438\u044f', 'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b: \u041f\u043e\u0441\u0435\u043b\u0435\u043d\u0438\u044f'},
        ),
        migrations.AlterField(
            model_name='conflict',
            name='solved_by',
            field=models.ForeignKey(related_name='solved_conflicts', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
    ]
