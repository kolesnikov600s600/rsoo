# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0040_auto_20160218_1003'),
    ]

    operations = [
        migrations.CreateModel(
            name='Contract',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('org_1', models.CharField(max_length=255, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f')),
                ('org_1_inn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u0418\u041d\u041d', blank=True)),
                ('org_1_ogrn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u041e\u0413\u0420\u041d', blank=True)),
                ('number', models.CharField(max_length=255, verbose_name='\u041d\u043e\u043c\u0435\u0440 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430')),
                ('contract_date', models.DateTimeField(verbose_name='\u0414\u0430\u0442\u0430 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430')),
                ('hazard_class', models.CharField(max_length=255, null=True, verbose_name='\u041a\u043b\u0430\u0441\u0441 \u043e\u043f\u0430\u0441\u043d\u043e\u0441\u0442\u0438', blank=True)),
                ('periodicity', models.CharField(max_length=255, null=True, verbose_name='\u0427\u0430\u0441\u0442\u043e\u0442\u0430 \u0432\u044b\u0432\u043e\u0437\u0430 \u043e\u0442\u0445\u043e\u0434\u043e\u0432', blank=True)),
                ('measure', models.CharField(max_length=255, null=True, verbose_name='\u0415\u0434\u0438\u043d\u0438\u0446\u0430 \u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0435\u0438\u044f \u0432 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0435', blank=True)),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('creator', models.ForeignKey(related_name='contract_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u0414\u043e\u0433\u043e\u0432\u043e\u0440',
                'verbose_name_plural': '\u0414\u043e\u0433\u043e\u0432\u043e\u0440\u0430',
            },
        ),
        migrations.CreateModel(
            name='FKKO',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('code', models.CharField(max_length=255, verbose_name='\u041a\u043e\u0434')),
                ('name', models.CharField(max_length=255, verbose_name='\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435')),
                ('hazard_class', models.CharField(max_length=255, verbose_name='\u041a\u043b\u0430\u0441\u0441')),
                ('form', models.CharField(max_length=255, verbose_name='\u0410\u0433\u0440\u0435\u0433\u0430\u0442\u043d\u043e\u0435 \u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0438 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043a\u0430\u044f \u0444\u043e\u0440\u043c\u0430')),
            ],
            options={
                'ordering': ['-code'],
                'verbose_name': '\u041a\u043b\u0430\u0441\u0441\u0438\u0444\u0438\u043a\u0430\u0442\u043e\u0440',
                'verbose_name_plural': '\u041a\u043b\u0430\u0441\u0441\u0438\u0444\u0438\u043a\u0430\u0442\u043e\u0440',
            },
        ),
        migrations.AddField(
            model_name='contract',
            name='fkko',
            field=models.ForeignKey(related_name='contract', verbose_name='\u0412\u0438\u0434 \u043e\u0442\u0445\u043e\u0434\u043e\u0432 \u043f\u043e \u0424\u041a\u041a\u041e', blank=True, to='contents.FKKO', null=True),
        ),
    ]
