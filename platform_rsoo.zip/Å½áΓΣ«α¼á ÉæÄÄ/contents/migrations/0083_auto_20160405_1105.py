# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0082_auto_20160405_1057'),
    ]

    operations = [
        migrations.AddField(
            model_name='unloadingpoint',
            name='capacity_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043e\u0442\u0445\u043e\u0434\u043e\u0432 1', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='capacity_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043e\u0442\u0445\u043e\u0434\u043e\u0432 2', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='capacity_3',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043e\u0442\u0445\u043e\u0434\u043e\u0432 3', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='measure',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0415\u0434\u0438\u043d\u0438\u0446\u0430 \u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0435\u0438\u044f \u0432 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0435', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='tariff_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444 1', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='tariff_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444 2', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='tariff_3',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444 3', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='total_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u0443\u043c\u043c\u0430 1', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='total_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u0443\u043c\u043c\u0430 2', blank=True),
        ),
        migrations.AddField(
            model_name='unloadingpoint',
            name='total_3',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u0443\u043c\u043c\u0430 3', blank=True),
        ),
    ]
