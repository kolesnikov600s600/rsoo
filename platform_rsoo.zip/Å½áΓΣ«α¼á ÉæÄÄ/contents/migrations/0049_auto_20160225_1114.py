# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import rsso.utils


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0048_containerplatform_draft'),
    ]

    operations = [
        migrations.AlterField(
            model_name='file',
            name='file',
            field=models.FileField(upload_to=rsso.utils.get_file_path),
        ),
    ]
