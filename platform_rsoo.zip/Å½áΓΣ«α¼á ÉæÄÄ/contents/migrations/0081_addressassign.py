# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0080_auto_20160330_1518'),
    ]

    operations = [
        migrations.CreateModel(
            name='AddressAssign',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('address', models.CharField(max_length=255, verbose_name='\u0410\u0434\u0440\u0435\u0441')),
                ('inn', models.CharField(max_length=255, verbose_name='\u0418\u041d\u041d')),
                ('name', models.CharField(max_length=255, null=True, verbose_name='\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435', blank=True)),
                ('branch', models.CharField(max_length=255, null=True, verbose_name='\u0412\u0438\u0434 \u0434\u0435\u044f\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u0438', blank=True)),
                ('volume', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043f\u043e\u0442\u0440\u0435\u0431\u043b\u0435\u043d\u0438\u044f', blank=True)),
            ],
            options={
                'verbose_name': '\u0410\u0434\u0440\u0435\u0441 \u043f\u043e \u0418\u041d\u041d',
                'verbose_name_plural': '\u0410\u0434\u0440\u0435\u0441\u0430 \u043f\u043e \u0418\u041d\u041d',
            },
        ),
    ]
