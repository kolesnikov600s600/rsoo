# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0042_auto_20160219_0959'),
    ]

    operations = [
        migrations.AddField(
            model_name='contract',
            name='capacity_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043e\u0442\u0445\u043e\u0434\u043e\u0432 1', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='capacity_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043e\u0442\u0445\u043e\u0434\u043e\u0432 2', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='capacity_3',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u044a\u0435\u043c \u043e\u0442\u0445\u043e\u0434\u043e\u0432 3', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='tariff_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444 1', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='tariff_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444 2', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='tariff_3',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444 3', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='total_1',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u0443\u043c\u043c\u0430 1', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='total_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u0443\u043c\u043c\u0430 2', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='total_3',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u0443\u043c\u043c\u0430 3', blank=True),
        ),
    ]
