# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0095_conflict_conflictcontainer_conflictpoints'),
    ]

    operations = [
        migrations.CreateModel(
            name='ConflictSettle',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('conflict', models.ForeignKey(related_name='conflicts_settles', verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442', to='contents.Conflict')),
                ('obj1', models.ForeignKey(related_name='conflicts_settle1', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 1', to='contents.Settlements')),
                ('obj2', models.ForeignKey(related_name='conflicts_settle2', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 2', blank=True, to='contents.Settlements', null=True)),
            ],
            options={
                'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
                'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
            },
        ),
        migrations.CreateModel(
            name='ConflictTreat',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('conflict', models.ForeignKey(related_name='conflicts_treats', verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442', to='contents.Conflict')),
                ('obj1', models.ForeignKey(related_name='conflicts_treat1', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 1', to='contents.Settlements')),
                ('obj2', models.ForeignKey(related_name='conflicts_treat2', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 2', blank=True, to='contents.Settlements', null=True)),
            ],
            options={
                'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
                'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
            },
        ),
        migrations.RemoveField(
            model_name='conflictpoints',
            name='conflict',
        ),
        migrations.RemoveField(
            model_name='conflictpoints',
            name='point1',
        ),
        migrations.RemoveField(
            model_name='conflictpoints',
            name='point2',
        ),
        migrations.RemoveField(
            model_name='conflictcontainer',
            name='platform1',
        ),
        migrations.RemoveField(
            model_name='conflictcontainer',
            name='platform2',
        ),
        migrations.AddField(
            model_name='conflictcontainer',
            name='obj1',
            field=models.ForeignKey(related_name='conflicts_platforms1', default=None, verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 1', to='contents.ContainerPlatform'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='conflictcontainer',
            name='obj2',
            field=models.ForeignKey(related_name='conflicts_platforms2', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 2', blank=True, to='contents.ContainerPlatform', null=True),
        ),
        migrations.DeleteModel(
            name='ConflictPoints',
        ),
    ]
