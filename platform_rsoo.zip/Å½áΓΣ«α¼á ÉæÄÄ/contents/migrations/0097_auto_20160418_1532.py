# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0096_auto_20160418_1443'),
    ]

    operations = [
        migrations.AlterField(
            model_name='conflicttreat',
            name='obj1',
            field=models.ForeignKey(related_name='conflicts_treat1', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 1', to='contents.ObjectsTreatment'),
        ),
        migrations.AlterField(
            model_name='conflicttreat',
            name='obj2',
            field=models.ForeignKey(related_name='conflicts_treat2', verbose_name='\u041e\u0431\u044a\u0435\u043a\u0442 2', blank=True, to='contents.ObjectsTreatment', null=True),
        ),
    ]
