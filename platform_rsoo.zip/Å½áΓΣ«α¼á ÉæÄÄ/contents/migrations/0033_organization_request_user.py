# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0032_auto_20160209_1509'),
    ]

    operations = [
        migrations.AddField(
            model_name='organization',
            name='request_user',
            field=models.ForeignKey(related_name='request_users', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
    ]
