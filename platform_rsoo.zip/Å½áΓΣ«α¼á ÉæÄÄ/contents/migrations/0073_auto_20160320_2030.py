# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0072_signeddocuments'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='signeddocuments',
            options={'verbose_name': '\u041f\u043e\u0434\u043f\u0438\u0441\u0430\u043d\u043d\u044b\u0435 \u0434\u043e\u043a\u0443\u043c\u0435\u043d\u0442\u044b', 'verbose_name_plural': '\u041f\u043e\u0434\u043f\u0438\u0441\u0430\u043d\u043d\u044b\u0435 \u0434\u043e\u043a\u0443\u043c\u0435\u043d\u0442\u044b'},
        ),
        migrations.AddField(
            model_name='profile',
            name='sign',
            field=models.BooleanField(default=False),
        ),
    ]
