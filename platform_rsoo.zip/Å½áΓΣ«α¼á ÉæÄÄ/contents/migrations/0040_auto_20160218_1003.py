# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0039_adjustablewaste_own'),
    ]

    operations = [
        migrations.AddField(
            model_name='container',
            name='dispose',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0423\u0442\u0438\u043b\u0438\u0437\u0438\u0440\u0443\u0435\u043c\u043e\u0441\u0442\u044c \u043e\u0442\u0445\u043e\u0434\u043e\u0432', blank=True),
        ),
        migrations.AddField(
            model_name='containerplatform',
            name='dispose',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0423\u0442\u0438\u043b\u0438\u0437\u0438\u0440\u0443\u0435\u043c\u043e\u0441\u0442\u044c \u043e\u0442\u0445\u043e\u0434\u043e\u0432', blank=True),
        ),
        migrations.AddField(
            model_name='containerplatform',
            name='mkd',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0421\u043e\u0432\u043c\u0435\u0441\u0442\u043d\u043e\u0435 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435 \u0441 \u041c\u041a\u0414', blank=True),
        ),
    ]
