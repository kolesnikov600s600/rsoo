# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0063_auto_20160314_2102'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='wastecomponent',
            options={'ordering': ['date'], 'verbose_name': '\u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442 \u043e\u0442\u0445\u043e\u0434\u043e\u0432', 'verbose_name_plural': '\u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u044b \u043e\u0442\u0445\u043e\u0434\u043e\u0432'},
        ),
    ]
