# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0054_auto_20160229_1827'),
    ]

    operations = [
        migrations.AddField(
            model_name='organization',
            name='kpp',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041a\u041f\u041f', blank=True),
        ),
    ]
