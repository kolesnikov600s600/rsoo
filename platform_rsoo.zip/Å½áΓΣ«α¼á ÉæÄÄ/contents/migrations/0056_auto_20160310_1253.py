# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0055_organization_kpp'),
    ]

    operations = [
        migrations.AlterField(
            model_name='contract',
            name='periodicity',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0427\u0430\u0441\u0442\u043e\u0442\u0430 \u0432\u044b\u0432\u043e\u0437\u0430 \u043e\u0442\u0445\u043e\u0434\u043e\u0432 \u0432 \u043d\u0435\u0434\u0435\u043b\u044e', blank=True),
        ),
    ]
