# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0056_auto_20160310_1253'),
    ]

    operations = [
        migrations.CreateModel(
            name='Waste',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('compositions', models.BooleanField(default=False, verbose_name='\u0418\u0437\u0432\u0435\u0441\u0442\u0435\u043d \u043a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u043d\u044b\u0439 \u0441\u043e\u0441\u0442\u0430\u0432 \u043e\u0442\u0445\u043e\u0434\u043e\u0432')),
                ('appearance', models.CharField(max_length=255, null=True, verbose_name='\u0410\u0433\u0440\u0435\u0433\u0430\u0442\u043d\u043e\u0435 \u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0438 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043a\u0430\u044f \u0444\u043e\u0440\u043c\u0430', blank=True)),
                ('passport', models.BooleanField(default=False, verbose_name='\u0420\u0430\u0437\u0440\u0430\u0431\u043e\u0442\u0430\u043d \u043f\u0430\u0441\u043f\u043e\u0440\u0442 \u043e\u0442\u0445\u043e\u0434\u0430')),
                ('approved', models.BooleanField(default=False, verbose_name='\u0423\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043d')),
                ('agreed', models.BooleanField(default=False, verbose_name='\u0421\u043e\u0433\u043b\u0430\u0441\u043e\u0432\u0430\u043d')),
                ('date_approved', models.DateField(null=True, verbose_name='\u0421\u043e\u0433\u043b\u0430\u0441\u043e\u0432\u0430\u043d', blank=True)),
                ('process_name', models.CharField(max_length=255, null=True, verbose_name='\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435 \u0442\u0435\u0445\u043d\u043e\u043b\u043e\u0433\u0438\u0447\u0435\u0441\u043a\u043e\u0433\u043e \u043f\u0440\u043e\u0446\u0435\u0441\u0441\u0430', blank=True)),
                ('product', models.CharField(max_length=255, null=True, verbose_name='\u0418\u0441\u0445\u043e\u0434\u043d\u044b\u0439 \u0442\u043e\u0432\u0430\u0440 (\u043f\u0440\u043e\u0434\u0443\u043a\u0446\u0438\u044f)', blank=True)),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('draft', models.BooleanField(default=False, verbose_name='\u0427\u0435\u0440\u043d\u043e\u0432\u0438\u043a')),
                ('creator', models.ForeignKey(related_name='wastes_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
                ('fkko', models.ForeignKey(related_name='wastes', verbose_name='\u0412\u0438\u0434 \u043e\u0442\u0445\u043e\u0434\u043e\u0432 \u043f\u043e \u0424\u041a\u041a\u041e', blank=True, to='contents.FKKO', null=True)),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u041e\u0442\u0445\u043e\u0434\u044b',
                'verbose_name_plural': '\u041e\u0442\u0445\u043e\u0434\u044b',
            },
        ),
        migrations.CreateModel(
            name='WasteComponent',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, verbose_name='\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u0430')),
                ('address', models.CharField(max_length=255, verbose_name='\u041c\u0430\u0441\u0441\u043e\u0432\u0430\u044f \u0434\u043e\u043b\u044f')),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('creator', models.ForeignKey(related_name='waste_component_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
                ('waste', models.ForeignKey(related_name='wastes', verbose_name='\u041e\u0442\u0445\u043e\u0434', to='contents.Waste')),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442 \u043e\u0442\u0445\u043e\u0434\u043e\u0432',
                'verbose_name_plural': '\u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u044b \u043e\u0442\u0445\u043e\u0434\u043e\u0432',
            },
        ),
    ]
