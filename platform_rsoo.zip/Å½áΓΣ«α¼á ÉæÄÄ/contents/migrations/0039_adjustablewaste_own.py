# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0038_auto_20160217_1553'),
    ]

    operations = [
        migrations.AddField(
            model_name='adjustablewaste',
            name='own',
            field=models.BooleanField(default=False),
        ),
    ]
