# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0078_auto_20160330_1212'),
    ]

    operations = [
        migrations.CreateModel(
            name='ContractGarbage',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('number', models.CharField(max_length=255, verbose_name='\u041d\u043e\u043c\u0435\u0440 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430')),
                ('contract_date', models.DateField(verbose_name='\u0414\u0430\u0442\u0430 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430')),
                ('org_1', models.CharField(max_length=255, verbose_name='\u0417\u0430\u043a\u0430\u0437\u0447\u0438\u043a')),
                ('org_1_inn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u0418\u041d\u041d', blank=True)),
                ('org_1_ogrn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u041e\u0413\u0420\u041d', blank=True)),
                ('tariff', models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444', blank=True)),
                ('tariff_measure', models.CharField(max_length=255, null=True, verbose_name='\u0415\u0434\u0438\u043d\u0438\u0446\u0430 \u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u044f', blank=True)),
                ('periodicity', models.CharField(max_length=255, null=True, verbose_name='\u0427\u0430\u0441\u0442\u043e\u0442\u0430 \u0432\u044b\u0432\u043e\u0437\u0430', blank=True)),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('creator', models.ForeignKey(related_name='contract_garbage_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
                ('file', models.ManyToManyField(related_name='garbage_contracts', verbose_name='\u0424\u0430\u0439\u043b\u044b', to='contents.File', blank=True)),
                ('firms', models.ManyToManyField(related_name='garbage_contracts', verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438', to='contents.AdjustableWaste', blank=True)),
                ('point', models.ForeignKey(related_name='unpoints', verbose_name='\u041c\u0435\u0441\u0442\u043e \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0438 \u043e\u0442\u0445\u043e\u0434\u043e\u0432 ', blank=True, to='contents.UnloadingPoint')),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u0414\u043e\u0433\u043e\u0432\u043e\u0440 \u043d\u0430 \u0432\u044b\u0432\u043e\u0437 \u043c\u0443\u0441\u043e\u0440\u0430',
                'verbose_name_plural': '\u0414\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u043d\u0430 \u0432\u044b\u0432\u043e\u0437 \u043c\u0443\u0441\u043e\u0440\u0430',
            },
        ),
    ]
