# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0076_auto_20160328_1355'),
    ]

    operations = [
        migrations.AlterField(
            model_name='staffing',
            name='money',
            field=models.CharField(max_length=255, verbose_name='\u0421\u0440\u0435\u0434\u043d\u0438\u0435 \u0437\u0430\u0442\u0440\u0430\u0442\u044b \u043d\u0430 \u0441\u043e\u0434\u0435\u0440\u0436\u0430\u043d\u0438\u0435 \u0441\u043e\u0442\u0440\u0443\u0434\u043d\u0438\u043a\u0430 (\u0440\u0443\u0431\u043b\u0435\u0439 \u0432 \u043c\u0435\u0441\u044f\u0446)'),
        ),
    ]
