# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0007_auto_20160125_0935'),
    ]

    operations = [
        migrations.AddField(
            model_name='transport',
            name='euro',
            field=models.CharField(default='test_euro', max_length=255, verbose_name='\u0421\u043e\u043e\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u0415\u0432\u0440\u043e-\u0441\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u0443'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='transport',
            name='intensity',
            field=models.CharField(default='intent_1', max_length=255, verbose_name='\u0418\u043d\u0442\u0435\u043d\u0441\u0438\u0432\u043d\u043e\u0441\u0442\u044c \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f'),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='transport',
            name='creator',
            field=models.ForeignKey(related_name='transport_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
    ]
