# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0094_auto_20160412_1750'),
    ]

    operations = [
        migrations.CreateModel(
            name='Conflict',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('conflict_type', models.CharField(max_length=255, verbose_name='\u0422\u0438\u043f \u043a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u0430', choices=[(b'double_data', '\u041e\u0434\u0438\u043d\u0430\u043a\u043e\u0432\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 \u0438\u0437 \u0440\u0430\u0437\u043d\u044b\u0445 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432'), (b'similar_data', '\u0421\u0445\u043e\u0436\u0438\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 \u0438\u0437 \u0440\u0430\u0437\u043d\u044b\u0445 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432'), (b'no_data', '\u041d\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u0434\u0430\u043d\u043d\u044b\u0445')])),
                ('active', models.BooleanField(default=False, verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d')),
                ('conflict_obtained', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('solved_time', models.DateTimeField(null=True, verbose_name='\u0414\u0430\u0442\u0430 \u0440\u0435\u0448\u0435\u043d\u0438\u044f', blank=True)),
                ('company', models.ForeignKey(related_name='conflicts', verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f', to='contents.Organization')),
                ('solved_by', models.ForeignKey(related_name='solved_conflicts', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442',
                'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b',
            },
        ),
        migrations.CreateModel(
            name='ConflictContainer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('conflict', models.ForeignKey(related_name='conflicts_platforms', verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442', to='contents.Conflict')),
                ('platform1', models.ForeignKey(related_name='conflicts_platforms1', verbose_name='\u041f\u043b\u043e\u0449\u0430\u0434\u043a\u0430 \u043a\u043e\u043c\u043f\u0430\u043d\u0438\u0438', to='contents.ContainerPlatform')),
                ('platform2', models.ForeignKey(related_name='conflicts_platforms2', verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435', to='contents.ContainerPlatform')),
            ],
            options={
                'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442: \u041f\u043b\u043e\u0449\u0430\u0434\u043a\u0438',
                'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b: \u041f\u043b\u043e\u0449\u0430\u0434\u043a\u0438',
            },
        ),
        migrations.CreateModel(
            name='ConflictPoints',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('conflict', models.ForeignKey(related_name='conflicts_points', verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442', to='contents.Conflict')),
                ('point1', models.ForeignKey(related_name='conflicts_points1', verbose_name='\u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0430 \u043a\u043e\u043c\u043f\u0430\u043d\u0438\u0438', to='contents.UnloadingPoint')),
                ('point2', models.ForeignKey(related_name='conflicts_points2', verbose_name='\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435', to='contents.UnloadingPoint')),
            ],
            options={
                'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
                'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
            },
        ),
    ]
