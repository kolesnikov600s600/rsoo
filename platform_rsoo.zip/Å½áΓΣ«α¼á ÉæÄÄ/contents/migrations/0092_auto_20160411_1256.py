# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0091_contractgarbage_tariff'),
    ]

    operations = [
        migrations.AddField(
            model_name='containerplatform',
            name='comment',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041a\u043e\u043c\u043c\u0435\u043d\u0442\u0430\u0440\u0438\u0438 (\u043f\u0440\u0438 \u0436\u0435\u043b\u0430\u043d\u0438\u0438)', blank=True),
        ),
        migrations.AlterField(
            model_name='house',
            name='fact_measure',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0415\u0434. \u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u044f', blank=True),
        ),
    ]
