# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0030_auto_20160207_1624'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='container',
            options={'ordering': ['number'], 'verbose_name': '\u041a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440', 'verbose_name_plural': '\u041a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u044b'},
        ),
        migrations.AlterField(
            model_name='adjustablewaste',
            name='qty',
            field=models.CharField(max_length=255, null=True, blank=True),
        ),
    ]
