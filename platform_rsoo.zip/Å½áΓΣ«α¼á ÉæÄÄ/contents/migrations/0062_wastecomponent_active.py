# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0061_auto_20160314_1857'),
    ]

    operations = [
        migrations.AddField(
            model_name='wastecomponent',
            name='active',
            field=models.BooleanField(default=False, verbose_name='\u0410\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c'),
        ),
    ]
