# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0028_auto_20160207_1421'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='container',
            name='type',
        ),
        migrations.AddField(
            model_name='container',
            name='material',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041c\u0430\u0442\u0435\u0440\u0438\u0430\u043b \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430', blank=True),
        ),
    ]
