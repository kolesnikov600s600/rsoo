# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0057_waste_wastecomponent'),
    ]

    operations = [
        migrations.AlterField(
            model_name='waste',
            name='fkko',
            field=models.ForeignKey(related_name='wastes', verbose_name='\u0412\u0438\u0434 \u043e\u0442\u0445\u043e\u0434\u043e\u0432 \u043f\u043e \u0424\u041a\u041a\u041e', to='contents.FKKO'),
        ),
    ]
