# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0092_auto_20160411_1256'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='capacity_1',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='capacity_2',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='capacity_3',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='measure',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='tariff_1',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='tariff_2',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='tariff_3',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='total_1',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='total_2',
        ),
        migrations.RemoveField(
            model_name='adjustablewaste',
            name='total_3',
        ),
    ]
