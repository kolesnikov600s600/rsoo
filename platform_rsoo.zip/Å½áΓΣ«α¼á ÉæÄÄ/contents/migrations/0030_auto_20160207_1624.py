# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0029_auto_20160207_1613'),
    ]

    operations = [
        migrations.AddField(
            model_name='container',
            name='org_2',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0431\u0441\u043b\u0443\u0436\u0438\u0432\u0430\u044e\u0449\u0430\u044f \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f', blank=True),
        ),
        migrations.AddField(
            model_name='container',
            name='org_2_inn',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 2 \u0418\u041d\u041d', blank=True),
        ),
        migrations.AddField(
            model_name='container',
            name='org_2_ogrn',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 2 \u041e\u0413\u0420\u041d', blank=True),
        ),
        migrations.AddField(
            model_name='containerplatform',
            name='capacity_container',
            field=models.CharField(max_length=255, null=True, verbose_name='\u0412\u043c\u0435\u0441\u0442\u0438\u043c\u043e\u0441\u0442\u044c \u043a\u0430\u0436\u0434\u043e\u0433\u043e \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430', blank=True),
        ),
        migrations.AddField(
            model_name='containerplatform',
            name='qty_container',
            field=models.IntegerField(null=True, verbose_name='\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u043e\u0432', blank=True),
        ),
    ]
