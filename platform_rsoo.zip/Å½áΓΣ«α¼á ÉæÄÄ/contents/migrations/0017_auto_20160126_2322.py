# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0016_auto_20160126_1612'),
    ]

    operations = [
        migrations.CreateModel(
            name='Container',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('number', models.CharField(max_length=4, verbose_name='\u041d\u043e\u043c\u0435\u0440 \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430')),
                ('type', models.CharField(max_length=255, null=True, verbose_name='\u0422\u0438\u043f \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430', blank=True)),
                ('capacity', models.FloatField(verbose_name='\u0412\u043c\u0435\u0441\u0442\u0438\u043c\u043e\u0441\u0442\u044c \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430')),
                ('org_1', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f-\u0431\u0430\u043b\u0430\u043d\u0441\u043e\u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043b\u044c', blank=True)),
                ('org_1_inn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u0418\u041d\u041d', blank=True)),
                ('org_1_ogrn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u041e\u0413\u0420\u041d', blank=True)),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u041a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440',
                'verbose_name_plural': '\u041a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u044b',
            },
        ),
        migrations.AlterModelOptions(
            name='containerplatform',
            options={'ordering': ['-date'], 'verbose_name': '\u041f\u043b\u043e\u0449\u0430\u0434\u043a\u0430', 'verbose_name_plural': '\u041f\u043b\u043e\u0449\u0430\u0434\u043a\u0438'},
        ),
        migrations.AddField(
            model_name='container',
            name='container',
            field=models.ForeignKey(related_name='containers', to='contents.ContainerPlatform'),
        ),
        migrations.AddField(
            model_name='container',
            name='creator',
            field=models.ForeignKey(related_name='container_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
    ]
