# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0006_auto_20160123_1629'),
    ]

    operations = [
        migrations.CreateModel(
            name='Transport',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('model', models.CharField(max_length=255, verbose_name='\u041c\u043e\u0434\u0435\u043b\u044c')),
                ('number', models.CharField(max_length=255, verbose_name='\u0413\u043e\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0439 \u043d\u043e\u043c\u0435\u0440')),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('vin_number', models.CharField(max_length=255, verbose_name='VIN-\u043d\u043e\u043c\u0435\u0440')),
                ('equipment', models.CharField(max_length=255, verbose_name='\u0422\u0438\u043f \u043d\u0430\u0432\u0435\u0441\u043d\u043e\u0433\u043e \u043e\u0431\u043e\u0440\u0443\u0434\u043e\u0432\u0430\u043d\u0438\u044f')),
                ('year', models.CharField(max_length=255, verbose_name='\u0413\u043e\u0434 \u0432\u044b\u043f\u0443\u0441\u043a\u0430')),
                ('mileage', models.CharField(max_length=255, verbose_name='\u0421\u0440\u0435\u0434\u043d\u0435\u0433\u043e\u0434\u043e\u0432\u043e\u0439 \u043f\u0440\u043e\u0431\u0435\u0433')),
                ('status', models.CharField(max_length=255, verbose_name='\u0422\u0435\u0445\u043d\u0438\u0447\u0435\u0441\u043a\u043e\u0435 \u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435')),
                ('capacity', models.CharField(max_length=255, verbose_name='\u0412\u043c\u0435\u0441\u0442\u0438\u043c\u043e\u0441\u0442\u044c')),
                ('carrying_capacity', models.CharField(max_length=255, verbose_name='\u0413\u0440\u0443\u0437\u043e\u043f\u043e\u0434\u044a\u0435\u043c\u043d\u043e\u0441\u0442\u044c')),
                ('reasons_use', models.CharField(max_length=255, verbose_name='\u041e\u0441\u043d\u043e\u0432\u0430\u043d\u0438\u044f \u0434\u043b\u044f \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f')),
                ('gps', models.CharField(max_length=255, verbose_name='\u041d\u0430\u043b\u0438\u0447\u0438\u0435 \u0431\u043b\u043e\u043a\u0430 \u043c\u043e\u043d\u0438\u0442\u043e\u0440\u0438\u043d\u0433\u0430 \u0422\u0421')),
                ('gps_model', models.CharField(max_length=255, verbose_name='\u041c\u043e\u0434\u0435\u043b\u044c \u0431\u043b\u043e\u043a\u0430 \u043c\u043e\u043d\u0438\u0442\u043e\u0440\u0438\u043d\u0433\u0430 \u0422\u0421')),
                ('gps_firm', models.CharField(max_length=255, verbose_name='\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438, \u043e\u0431\u0441\u043b\u0443\u0436\u0438\u0432\u0430\u044e\u0449\u0435\u0439 \u0431\u043b\u043e\u043a \u043c\u043e\u043d\u0438\u0442\u043e\u0440\u0438\u043d\u0433\u0430 \u0422\u0421')),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u0422\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442',
                'verbose_name_plural': '\u0422\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442',
            },
        ),
        migrations.CreateModel(
            name='TransportBrand',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, verbose_name='\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435')),
            ],
        ),
        migrations.AddField(
            model_name='transport',
            name='brand',
            field=models.ForeignKey(related_name='transport', verbose_name='\u041c\u0430\u0440\u043a\u0430', to='contents.TransportBrand'),
        ),
        migrations.AddField(
            model_name='transport',
            name='creator',
            field=models.ForeignKey(related_name='transport_creator', to=settings.AUTH_USER_MODEL),
        ),
    ]
