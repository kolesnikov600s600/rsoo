# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0046_auto_20160220_0913'),
    ]

    operations = [
        migrations.AddField(
            model_name='contract',
            name='firms',
            field=models.ManyToManyField(related_name='contract', verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438', to='contents.AdjustableWaste', blank=True),
        ),
        migrations.AddField(
            model_name='contract',
            name='platforms',
            field=models.ManyToManyField(related_name='contract', verbose_name='\u041f\u043b\u0430\u0442\u0444\u043e\u0440\u043c\u044b', to='contents.ContainerPlatform', blank=True),
        ),
    ]
