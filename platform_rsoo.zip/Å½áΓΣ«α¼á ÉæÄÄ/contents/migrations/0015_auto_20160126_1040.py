# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0014_containerplatform'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='containerplatform',
            name='sort',
        ),
        migrations.RemoveField(
            model_name='containerplatform',
            name='text',
        ),
    ]
