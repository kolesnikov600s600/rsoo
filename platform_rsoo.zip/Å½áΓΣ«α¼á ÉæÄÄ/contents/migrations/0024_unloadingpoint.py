# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('contents', '0023_base'),
    ]

    operations = [
        migrations.CreateModel(
            name='UnloadingPoint',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, verbose_name='\u041d\u0430\u0441\u0435\u043b\u0435\u043d\u043d\u044b\u0439 \u043f\u0443\u043d\u043a\u0442')),
                ('address', models.CharField(max_length=255, verbose_name='\u0410\u0434\u0440\u0435\u0441 \u0431\u0430\u0437\u044b')),
                ('lat', models.CharField(max_length=255, verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430')),
                ('lon', models.CharField(max_length=255, verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430')),
                ('org_1', models.CharField(max_length=255, null=True, verbose_name='\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438', blank=True)),
                ('org_1_inn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u0418\u041d\u041d', blank=True)),
                ('org_1_ogrn', models.CharField(max_length=255, null=True, verbose_name='\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f 1 \u041e\u0413\u0420\u041d', blank=True)),
                ('deadline_doc', models.CharField(max_length=255, null=True, verbose_name='\u0421\u0440\u043e\u043a \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u043d\u0430 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0443', blank=True)),
                ('number_doc', models.CharField(max_length=255, null=True, verbose_name='\u041d\u043e\u043c\u0435\u0440 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u043d\u0430 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0443', blank=True)),
                ('date_doc', models.CharField(max_length=255, null=True, verbose_name='\u0414\u0430\u0442\u0430 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u043d\u0430 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0443', blank=True)),
                ('limit', models.CharField(max_length=255, null=True, verbose_name='\u041b\u0438\u043c\u0438\u0442 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0438', blank=True)),
                ('tariff_type', models.CharField(max_length=255, null=True, verbose_name='\u0422\u0438\u043f \u0442\u0430\u0440\u0438\u0444\u0430', blank=True)),
                ('tariff', models.CharField(max_length=255, null=True, verbose_name='\u0422\u0430\u0440\u0438\u0444', blank=True)),
                ('date', models.DateTimeField(auto_now_add=True, verbose_name='\u0414\u0430\u0442\u0430')),
                ('creator', models.ForeignKey(related_name='point_creator', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
            options={
                'ordering': ['-date'],
                'verbose_name': '\u041f\u0443\u043d\u043a\u0442 \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
                'verbose_name_plural': '\u041f\u0443\u043d\u043a\u0442\u044b \u0432\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
            },
        ),
    ]
