# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0019_auto_20160127_0109'),
    ]

    operations = [
        migrations.AlterField(
            model_name='container',
            name='container',
            field=models.ForeignKey(related_name='containers', blank=True, to='contents.ContainerPlatform', null=True),
        ),
    ]
