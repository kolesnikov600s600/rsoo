# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0075_auto_20160328_1313'),
    ]

    operations = [
        migrations.AlterField(
            model_name='adjustablewaste',
            name='lat',
            field=models.DecimalField(verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='adjustablewaste',
            name='lon',
            field=models.DecimalField(verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='base',
            name='lat',
            field=models.DecimalField(verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='base',
            name='lon',
            field=models.DecimalField(verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='objectstreatment',
            name='lat',
            field=models.DecimalField(verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='objectstreatment',
            name='lon',
            field=models.DecimalField(verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='settlements',
            name='lat',
            field=models.DecimalField(verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='settlements',
            name='lon',
            field=models.DecimalField(verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='transporters',
            name='lat',
            field=models.DecimalField(verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='transporters',
            name='lon',
            field=models.DecimalField(verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='unloadingpoint',
            name='lat',
            field=models.DecimalField(verbose_name='\u0428\u0438\u0440\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
        migrations.AlterField(
            model_name='unloadingpoint',
            name='lon',
            field=models.DecimalField(verbose_name='\u0414\u043e\u043b\u0433\u043e\u0442\u0430', max_digits=9, decimal_places=6),
        ),
    ]
