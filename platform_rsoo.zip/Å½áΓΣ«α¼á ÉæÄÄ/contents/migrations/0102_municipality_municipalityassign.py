# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0101_auto_20160418_1827'),
    ]

    operations = [
        migrations.CreateModel(
            name='Municipality',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, verbose_name='\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435')),
            ],
            options={
                'verbose_name': '\u041c\u0443\u043d\u0438\u0446\u0438\u043f\u0430\u043b\u0438\u0442\u0435\u0442',
                'verbose_name_plural': '\u041c\u0443\u043d\u0438\u0446\u0438\u043f\u0430\u043b\u0438\u0442\u0435\u0442\u044b',
            },
        ),
        migrations.CreateModel(
            name='MunicipalityAssign',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('firm', models.ForeignKey(related_name='municipally', to='contents.Transporters')),
                ('municipality', models.ForeignKey(related_name='firms', verbose_name='\u041c\u0443\u043d\u0438\u0446\u0438\u043f\u0430\u043b\u0438\u0442\u0435\u0442', to='contents.Municipality')),
            ],
            options={
                'verbose_name': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
                'verbose_name_plural': '\u041a\u043e\u043d\u0444\u043b\u0438\u043a\u0442\u044b: \u0412\u044b\u0433\u0440\u0443\u0437\u043a\u0438',
            },
        ),
    ]
