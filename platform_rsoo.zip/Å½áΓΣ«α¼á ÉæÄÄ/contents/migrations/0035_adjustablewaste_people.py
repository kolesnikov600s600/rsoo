# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('contents', '0034_profile_password'),
    ]

    operations = [
        migrations.AddField(
            model_name='adjustablewaste',
            name='people',
            field=models.CharField(max_length=255, null=True, verbose_name='\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u0441\u043e\u0442\u0440\u0443\u0434\u043d\u0438\u043a\u043e\u0432', blank=True),
        ),
    ]
