# vim:fileencoding=utf-8
import csv
from datetime import datetime
from decimal import Decimal
from contents.models import ContainerPlatform
import os
from django.core.management.base import NoArgsCommand
from rsso.settings import STATIC_ROOT


class Command(NoArgsCommand):
    def handle(self, **options):
        reader = csv.reader(open(os.path.join(STATIC_ROOT, 'points.csv')), delimiter=';')

        for row in reader:
            n = ContainerPlatform.objects.create(number=row[2], address=row[3], lat=row[0], lon=row[1])
            print(n.id)

