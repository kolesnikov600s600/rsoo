# vim:fileencoding=utf-8
import csv
from datetime import datetime
from decimal import Decimal
from contents.views import CREATE_ORG_FORMS
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
import os
from django.core.management.base import NoArgsCommand
from rsso.settings import STATIC_ROOT
from contents.models import Conflict, ContainerPlatform, Settlements, ObjectsTreatment, Organization, ConflictContainer, \
    ConflictSettle, ConflictTreat

check_models = [
    {
        'model': ContainerPlatform,
        'inline': ConflictContainer,
        'fields': ['number', 'address', 'mkd', 'lat', 'lon', 'type', 'surface', 'fences',
                   'qty_container', 'capacity_container', 'place_kgm', 'dispose', 'org_1', 'org_1_inn',
                   'org_1_ogrn', 'org_2', 'org_2_inn', 'org_2_ogrn']
    },
    {
        'model': Settlements,
        'inline': ConflictSettle,
        'fields': ['name', 'address', 'lat', 'lon', 'okato', 'type_object', 'person',
                   'email', 'phone', 'houses', 'people_summer', 'org_1', 'org_1_inn',
                   'org_1_ogrn', 'org_2', 'org_2_inn', 'org_2_ogrn', 'people_winter', 'square']
    },
    {
        'model': ObjectsTreatment,
        'inline': ConflictTreat,
        'fields': ['address', 'lat', 'lon', 'type1', 'type2', 'type3',
                   'email', 'phone', 'type4', 'type5', 'org_1', 'org_1_inn',
                   'org_1_ogrn']
    }
]

class Command(NoArgsCommand):
    def handle(self, **options):
        for model in check_models:
            inl = model['inline']
            ml = model['model']
            fields = model['fields']
            qs = ml.objects.all()
            originals = qs
            for item in originals:
                try:
                    company = item.creator.request_users.all()[0]
                except:
                    company = False
                    print item.creator
                if company:
                    for obj in qs:
                        if obj != item:
                            if obj.address == item.address:
                                if not inl.objects.filter(obj1=item, obj2=obj).exists() and not inl.objects.filter(obj2=item, obj1=obj).exists():
                                    if ml != ContainerPlatform:
                                        conflict = Conflict.objects.create(company=company, conflict_type='double_data')
                                        inl.objects.create(conflict=conflict, obj1=item, obj2=obj)
                                    elif item.creator != obj.creator:
                                        conflict = Conflict.objects.create(company=company, conflict_type='double_data')
                                        inl.objects.create(conflict=conflict, obj1=item, obj2=obj)
                            else:
                                if item.creator != obj.creator:
                                    flag = True
                                    for field in fields:
                                        if field != 'address':
                                            if getattr(item, field, False) != getattr(obj, field, False):
                                                flag = False
                                    if flag:
                                        if not inl.objects.filter(obj1=item, obj2=obj).exists() and not inl.objects.filter(obj2=item, obj1=obj).exists():
                                            conflict = Conflict.objects.create(company=company, conflict_type='similar_data')
                                            inl.objects.create(conflict=conflict, obj1=item, obj2=obj)
                    flag_data = False
                    for field in fields:
                        if not getattr(item, field, False) or getattr(item, field, False) == '':
                            flag_data = True
                    if flag_data:
                        if not inl.objects.filter(obj1=item, obj2__isnull=True).exists():
                            conflict = Conflict.objects.create(company=company, conflict_type='no_data')
                            inl.objects.create(conflict=conflict, obj1=item)

