# vim:fileencoding=utf-8
import csv
from datetime import datetime
from decimal import Decimal
from contents.views import CREATE_ORG_FORMS
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from contents.models import ContainerPlatform, Transporters, OrganizationCategory, Organization, Profile, RequestForm, \
    ProfileForm
import os
from django.core.management.base import NoArgsCommand
from rsso.settings import STATIC_ROOT, MEDIA_ROOT


class Command(NoArgsCommand):
    def handle(self, **options):
        reader = csv.reader(open(os.path.join(STATIC_ROOT, 'transporters.csv')), delimiter=';')
        errors = []
        admin = User.objects.filter(is_superuser=True)[0]
        for company in reader:
            flag = True
            if User.objects.filter(email=company[2]).exists():
                flag = False
                company.append(u'Email уже есть в системе'.encode('cp1251'))
            if Organization.objects.filter(inn=company[1]).exists():
                flag = False
                company.append(u'Организация с таким ИНН уже есть в системе'.encode('cp1251'))
            if flag:
                phone = u'+7 (000) 000-00-00'
                password = User.objects.make_random_password()
                u = User.objects.create_user(company[2], company[2], password)
                Profile.objects.create(user=u, password=password, phone=phone)
                item_data = {
                    'name': company[0].decode('cp1251'),
                    'category': OrganizationCategory.objects.get(id=4),
                    'email': company[2],
                    'phone': phone,
                    'inn': company[1],
                    'kpp': company[3],
                    'bin': company[4],
                    'creator': admin,
                    'request_user': u
                }
                item = Organization.objects.create(**item_data)
                for i in CREATE_ORG_FORMS['4']:
                    f = RequestForm.objects.create(
                        form_name=i,
                        deadline=3,
                        organization=item
                    )
                    ProfileForm.objects.create(user=u, form_name=i)
                html = render_to_string('organizations/email-request-transport.html', {'item': item, 'password': password, 'username': u.username})
                msg = EmailMessage(u'Запрос от Комиссии по Ижевской бласти',
                                   html,
                                   'xxxxx@xxxxxx.ru',
                                   [company[2]], headers={})
                msg.content_subtype = "html"

                msg.attach('doc.pdf',  open(os.path.join(STATIC_ROOT, 'doc.pdf'), "rb").read())
                msg.attach('forms-TK.xls',  open(os.path.join(STATIC_ROOT, 'forms-TK.xls'), "rb").read())
                msg.send()
                company.append(u'Запрос Отправлен'.encode('cp1251'))
                print item.id
            errors.append(company)
        name_file = "report-%s.csv" % datetime.now().strftime("%d-%m-%Y-%H-%M")
        file = (os.path.join(MEDIA_ROOT, name_file))
        writer = csv.writer(open(file, "wb"), delimiter=';')
        for err in errors:
            writer.writerow(err)

