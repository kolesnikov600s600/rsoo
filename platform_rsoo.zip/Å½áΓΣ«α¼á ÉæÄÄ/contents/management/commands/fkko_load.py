# vim:fileencoding=utf-8
import csv
from datetime import datetime
from decimal import Decimal
from contents.models import FKKO
import os
from django.core.management.base import NoArgsCommand
from rsso.settings import STATIC_ROOT


class Command(NoArgsCommand):
    def handle(self, **options):
        reader = csv.reader(open(os.path.join(STATIC_ROOT, 'fkko.csv')), delimiter=';')

        for row in reader:
            n = FKKO.objects.create(code=row[0].replace(' ', ''), name=row[1].decode('cp1251'), hazard_class=row[2].decode('cp1251'), form=row[3].decode('cp1251'))
            print(n.id)