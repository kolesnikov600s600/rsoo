# vim:fileencoding=utf-8
import csv
from datetime import datetime
from decimal import Decimal
from contents.views import CREATE_ORG_FORMS
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from contents.models import ContainerPlatform, Transporters, OrganizationCategory, Organization, Profile, RequestForm, \
    ProfileForm
import os
from django.core.management.base import NoArgsCommand
from rsso.settings import STATIC_ROOT


class Command(NoArgsCommand):
    def handle(self, **options):

        companies = Transporters.objects.filter(email__isnull=False).exclude(email='')
        admin = User.objects.filter(is_superuser=True)[0]
        for company in companies:
            if not User.objects.filter(email=company.email).exists():
                phone = company.phone
                if not company.phone:
                    phone = u'+7 (000) 000-00-00'
                password = User.objects.make_random_password()
                u = User.objects.create_user(company.email, company.email, password)
                Profile.objects.create(user=u, password=password, phone=phone)
                item_data = {
                    'name': company.org_1,
                    'category': OrganizationCategory.objects.get(id=4),
                    'email': company.email,
                    'phone': phone,
                    'inn': company.org_1_inn,
                    'bin': company.org_1_ogrn,
                    'address': company.address,
                    'creator': admin,
                    'request_user': u
                }
                item = Organization.objects.create(**item_data)

                for i in CREATE_ORG_FORMS['4']:
                    f = RequestForm.objects.create(
                        form_name=i,
                        deadline=3,
                        organization=item
                    )
                    ProfileForm.objects.create(user=u, form_name=i)

                html = render_to_string('organizations/email-request-transport.html', {'item': item, 'password': password, 'username': u.username})
                msg = EmailMessage(u'Запрос от Комиссии по экологии Ижевской области',
                                   html,
                                   'xxxxxxx@xxxxx.ru',
                                   [company.email], headers={})
                msg.content_subtype = "html"

                msg.attach('doc.pdf',  open(os.path.join(STATIC_ROOT, 'doc.pdf'), "rb").read())
                msg.attach('forms-TK.xls',  open(os.path.join(STATIC_ROOT, 'forms-TK.xls'), "rb").read())

                msg.send()

                print item.id


