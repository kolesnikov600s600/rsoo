# vim:fileencoding=utf-8
import csv
from datetime import datetime
from decimal import Decimal
from contents.models import AddressAssign
import os
from django.core.management.base import NoArgsCommand
from rsso.settings import STATIC_ROOT


class Command(NoArgsCommand):
    def handle(self, **options):
        reader = csv.reader(open(os.path.join(STATIC_ROOT, 'address.csv')), delimiter=';')

        for row in reader:
            n = AddressAssign.objects.create(
                address=row[2].decode('cp1251'),
                inn=row[1].decode('cp1251'),
                name=row[0].decode('cp1251'),
                volume=row[4].decode('cp1251'),
                branch=row[3].decode('cp1251')
            )
            print(n.id)