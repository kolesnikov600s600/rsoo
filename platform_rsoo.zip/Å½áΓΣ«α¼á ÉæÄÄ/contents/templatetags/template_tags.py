# vim:fileencoding=utf-8
from datetime import datetime
import math
import random
from django.db.models import Q
from django.template import Template, Context
from django.template.loader import render_to_string
from django import template
import re
import time


register = template.Library()


def render_field(val, arg):
    t = Template(val)
    c = Context({'item': arg})
    return t.render(c)


def getforms(val):
    return val.request_forms.values_list('form_name', flat=True)


def minus(value, arg):
    return value - int(arg)


def plus(value, arg):
    return int(value) + int(arg)


def multiply(value, arg):
    return int(value) * int(arg)


def split(values, arg):
    n = values.split(arg)
    return n


def replace_unicode(value):
    import re

    r = re.sub(r'&([A-Za-z]+);', '', value)
    return r


def parse_int(value):
    return int(value)


def get_date(value):
    return datetime.strptime(value, '%a, %d %b %Y %H:%M:%S %Z')


def files(values):
    n = int(math.ceil(float(values) / 2))
    return n


def parse_str(value):
    return str(value)


def price_format(value):
    decimal_points = 3
    separator = u' '
    value = str(value)
    if len(value) <= decimal_points:
        return value
    parts = []
    while value:
        parts.append(value[-decimal_points:])
        value = value[:-decimal_points]
    parts.reverse()
    return separator.join(parts)


def to_class_name(value):
    return value.__class__.__name__


def sizes(value, arg):
    e = random.randint(int(arg.split(',')[0]), int(arg.split(',')[1]))
    return e


def get_million(value):
    return int((int(value)/1000000))


def parse_float(value):
    e, f = str(value).split('.')
    if int(f) > 0:
        return value
    return int(e)


def get_extension(value):
    f = str(value).split('.')
    return f[-1]


def get_arr_el(arr, id):
    return arr[id]


def is_entry(value, arg):
    if re.findall(arg, value) != 0:
        return True
    return False


def replace(value, param):
    f, e = param.split('#')
    value = str(value).replace(f, e)
    return value


def die_ie(value):
    arr = ['MSIE 8', 'MSIE 7', 'MSIE 6']
    if len([i for i in arr if i in value]) > 0:
        return False
    return True


def get_point(current, point):
    if current <= point:
        return int(current)
    return int(point)


def get_row(l, p):
    try:
        return l[p]
    except:
        return ''


register.filter('get_row', get_row)
register.filter('get_point', get_point)
register.filter('die_ie', die_ie)
register.filter('replace', replace)
register.filter('is_entry', is_entry)
register.filter('get_extension', get_extension)
register.filter('get_arr_el', get_arr_el)
register.filter('parse_float', parse_float)
register.filter('get_million', get_million)
register.filter('sizes', sizes)
register.filter('to_class_name', to_class_name)
register.filter('price', price_format)
register.filter('files', files)
register.filter('parse_date', get_date)
register.filter('str', parse_str)
register.filter('parse_int', parse_int)
register.filter('replace_unicode', replace_unicode)
register.filter('split', split)
register.filter('multiply', multiply)
register.filter('plus', plus)
register.filter('minus', minus)
register.filter('get_forms_user', getforms)
register.filter('render_field', render_field)
